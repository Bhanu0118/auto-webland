package ap.webland.web

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import ap.webland.core.Act
import ap.webland.core.Json
import ap.webland.core.Macro
import ap.webland.core.Meaning
import ap.webland.core.Step
import ap.webland.core.Target
import ap.webland.core.Wait

/**
 * Watching the surveyor do one record, and writing down what they did.
 *
 * The recorder listens to the page rather than to the screen, which is
 * what makes a recording survive a tablet being held differently or a
 * row of the form moving down. For every box touched it keeps several
 * ways of finding it again - the id the portal gave it, its form name, a
 * path through the page, the label beside it, the words on it - so that
 * if the portal changes one of those the rest still work.
 *
 * A password is watched being typed and is NOT written down. The step
 * says a secret belongs there; the surveyor types it at the moment of
 * replay and it is never stored, logged or exported.
 *
 * Nothing the page sends is trusted. It arrives as text, is parsed by
 * this app's own JSON reader, and has to pass the same gate as a step
 * out of a file before it becomes a step.
 */
class Recorder(
    private val web: WebView,
    private val onStep: (Step) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile var recording: Boolean = false
        private set

    private val bridge = object {
        @JavascriptInterface
        fun step(json: String) {
            if (!recording) return
            val step = parse(json) ?: return
            main.post { onStep(step) }
        }

        @JavascriptInterface
        fun note(text: String) {
            if (!recording) return
            main.post {
                onStep(Step(act = Act.COMMENT, value = text.take(200)))
            }
        }
    }

    fun start() {
        recording = true
        main.post {
            web.addJavascriptInterface(bridge, BRIDGE)
            inject()
        }
    }

    fun stop() {
        recording = false
        main.post {
            web.evaluateJavascript("window.__bwaRec=false;", null)
            try {
                web.removeJavascriptInterface(BRIDGE)
            } catch (e: Exception) {
                // nothing to remove; that is fine
            }
        }
    }

    /** Called again after every page load, because a new page has no listeners. */
    fun inject() {
        if (!recording) return
        main.post { web.evaluateJavascript(SCRIPT, null) }
    }

    private fun parse(json: String): Step? {
        return try {
            val raw = Json.parse(json)
            val act = when (raw.str("action")) {
                "click" -> Act.CLICK
                "type" -> Act.TYPE
                "select" -> Act.SELECT
                "check" -> Act.CHECK
                "uncheck" -> Act.UNCHECK
                else -> return null
            }
            val target = Target.of(raw["target"])
            if (target.isEmpty) return null
            val secret = raw.bool("secret", false)
            val words = raw.str("text")
            val meaning = if (act == Act.CLICK) Meaning.ofText(words) else Meaning.NONE
            Step(
                act = act,
                target = target,
                value = if (secret) Macro.SECRET_MARK else raw.str("value"),
                meaning = meaning,
                wait = if (meaning.writes) Wait.SAVE_CONFIRMATION else Wait.VISIBLE,
                timeoutMs = if (meaning.writes) 45_000 else 15_000,
                secret = secret,
                note = if (secret) "the password is asked for when this runs" else "",
            )
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val BRIDGE = "BWA"

        /**
         * The listeners, injected into the page.
         *
         * They are attached in the capture phase so that a click on a
         * button is seen even when the portal's own handler stops it
         * going any further.
         */
        private val SCRIPT = """
(function(){
 if(window.__bwaRec===true) return;
 window.__bwaRec=true;
 function tidy(s){return (s||'').replace(/\s+/g,' ').trim();}
 function cssPath(el){
  try{
   var parts=[];var node=el;var depth=0;
   while(node && node.nodeType===1 && depth<6){
    var part=node.nodeName.toLowerCase();
    if(node.id){parts.unshift(part+'#'+node.id);break;}
    var parent=node.parentNode;
    if(parent){
     var same=[];var kids=parent.children;
     for(var i=0;i<kids.length;i++){
      if(kids[i].nodeName===node.nodeName) same.push(kids[i]);}
     if(same.length>1) part+=':nth-of-type('+(same.indexOf(node)+1)+')';}
    parts.unshift(part);node=parent;depth++;}
   return parts.join(' > ');
  }catch(e){return '';}}
 function labelOf(el){
  try{
   if(el.id){
    var l=document.querySelector('label[for="'+el.id+'"]');
    if(l) return tidy(l.innerText);}
   var p=el.parentNode;var hops=0;
   while(p && hops<3){
    if(p.nodeName==='TD'||p.nodeName==='TH'){
     var prev=p.previousElementSibling;
     if(prev) return tidy(prev.innerText).substring(0,60);}
    if(p.nodeName==='LABEL') return tidy(p.innerText).substring(0,60);
    p=p.parentNode;hops++;}
   return '';
  }catch(e){return '';}}
 function describe(el){
  var t={};
  if(el.id) t.id=el.id;
  if(el.name) t.name=el.name;
  var css=cssPath(el); if(css) t.css=css;
  var lab=labelOf(el); if(lab) t.label=lab;
  var words=tidy(el.innerText||el.value||'');
  if(words && words.length<60) t.text=words;
  if(el.getAttribute){
   var aria=el.getAttribute('aria-label'); if(aria) t.aria=aria;
   var ph=el.getAttribute('placeholder'); if(ph) t.placeholder=ph;}
  t.tag=(el.nodeName||'').toLowerCase();
  if(el.id && el.id.indexOf('_')>=0) t.id_tail=el.id.split('_').pop();
  return t;}
 function send(action,el,value,secret){
  try{
   var payload={action:action,target:describe(el),
    value:secret? '' : (value||''),
    text:tidy(el.innerText||el.value||'').substring(0,60),
    secret: secret? true : false};
   BWA.step(JSON.stringify(payload));
  }catch(e){}}
 function wanted(el){
  if(!el||!el.nodeName) return false;
  var tag=el.nodeName.toLowerCase();
  return tag==='a'||tag==='button'||tag==='input'||tag==='select'||
         tag==='textarea'||tag==='label'||tag==='span'||tag==='td';}
 document.addEventListener('click',function(e){
  if(window.__bwaRec!==true) return;
  var el=e.target;
  if(!wanted(el)) return;
  var type=(el.type||'').toLowerCase();
  if(type==='checkbox'||type==='radio'){
   send(el.checked?'check':'uncheck',el,'');return;}
  if(el.nodeName.toLowerCase()==='select') return;
  send('click',el,'');
 },true);
 document.addEventListener('change',function(e){
  if(window.__bwaRec!==true) return;
  var el=e.target;if(!el||!el.nodeName) return;
  var tag=el.nodeName.toLowerCase();
  var type=(el.type||'').toLowerCase();
  if(tag==='select'){
   var text=el.selectedIndex>=0? el.options[el.selectedIndex].text : '';
   send('select',el,tidy(text));return;}
  if(type==='checkbox'||type==='radio'){
   send(el.checked?'check':'uncheck',el,'');return;}
  if(tag==='input'||tag==='textarea'){
   send('type',el,el.value,type==='password');}
 },true);
})();
"""
    }
}
