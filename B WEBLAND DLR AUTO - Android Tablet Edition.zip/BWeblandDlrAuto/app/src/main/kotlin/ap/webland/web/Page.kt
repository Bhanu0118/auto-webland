package ap.webland.web

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import ap.webland.core.Json
import ap.webland.core.PageHost
import ap.webland.core.Selector
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The portal, inside a WebView, answering the questions the macro
 * engine asks.
 *
 * The engine in the core module knows nothing about Android. It asks
 * "does this box exist", "put this in it", "what does it hold now" - and
 * this class answers by running a small piece of JavaScript in the page.
 * The JavaScript is written here, in full, every time; nothing is ever
 * taken from a macro file and run. That is the whole reason the two
 * halves are kept apart.
 *
 * Three details are worth knowing.
 *
 * Every call blocks until the page answers, because the engine is a
 * plain sequence of steps and reads much better that way. So the engine
 * must NOT be run on the main thread - `Runner` puts it on a background
 * one, and each question is posted to the main thread and waited for.
 *
 * The portal's own confirm boxes are answered by the app. The surveyor
 * asked for that explicitly: a run of three thousand records cannot stop
 * for an OK. What the box said is kept, though, and handed to the engine
 * as part of what the portal is saying, because "Record already exists"
 * in a confirm box means exactly what it means in a label.
 *
 * The page is searched in its frames as well as its main document. The
 * Webland pages put the Add Record form inside a frame on some screens
 * and not on others, and a macro written on one must work on the other.
 */
class PortalPage(private val web: WebView) : PageHost {

    private val main = Handler(Looper.getMainLooper())
    private val lines = ArrayList<String>()
    /** what a confirm or alert box last said */
    @Volatile private var dialogSaid: String = ""
    @Volatile private var lastUrl: String = ""
    @Volatile var shotFolder: File? = null

    val log: List<String> get() = synchronized(lines) { lines.toList() }

    // ------------------------------------------------------------ setup
    @SuppressLint("SetJavaScriptEnabled")
    fun prepare(desktopPage: Boolean, onPageDone: (String) -> Unit) {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
            if (desktopPage) {
                // The macros were recorded against the desktop page, and
                // the box ids come from it. Asking for that page is the
                // difference between a macro working and a macro looking
                // for boxes that are not there.
                userAgentString = DESKTOP_AGENT
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                lastUrl = url ?: ""
                say("page: ${url ?: ""}")
                onPageDone(url ?: "")
            }

            override fun onReceivedError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                error: android.webkit.WebResourceError?,
            ) {
                if (request?.isForMainFrame == true) {
                    say("the page did not load: ${error?.description ?: ""}")
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: JsResult?,
            ): Boolean {
                dialogSaid = message ?: ""
                say("the portal said: ${message ?: ""}")
                result?.confirm()
                return true
            }

            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: JsResult?,
            ): Boolean {
                dialogSaid = message ?: ""
                say("the portal asked: ${message ?: ""} - answered OK")
                result?.confirm()
                return true
            }

            override fun onJsBeforeUnload(
                view: WebView?, url: String?, message: String?, result: JsResult?,
            ): Boolean {
                result?.confirm()
                return true
            }
        }
    }

    fun load(url: String) {
        main.post {
            dialogSaid = ""
            web.loadUrl(url)
        }
    }

    /** True once a real page is up: not about:blank, not an error. */
    fun isOpen(): Boolean {
        val url = currentUrl()
        return url.startsWith("http://") || url.startsWith("https://")
    }

    fun currentUrl(): String {
        val fromView = onMain { web.url ?: "" }
        return if (fromView.isNotBlank()) fromView else lastUrl
    }

    fun forget() {
        main.post {
            CookieManager.getInstance().removeAllCookies(null)
            web.clearHistory()
            web.clearCache(true)
            web.loadUrl("about:blank")
        }
    }

    private fun say(line: String) {
        synchronized(lines) {
            lines.add(line)
            if (lines.size > 4000) lines.subList(0, 1000).clear()
        }
    }

    // ----------------------------------------------------- the questions
    override fun exists(sel: Selector): Boolean = ask(sel, "exists") == "1"

    override fun visible(sel: Selector): Boolean = ask(sel, "visible") == "1"

    override fun optionCount(sel: Selector): Int =
        ask(sel, "options").trim().toIntOrNull() ?: 0

    override fun click(sel: Selector): Boolean = ask(sel, "click") == "1"

    override fun type(sel: Selector, text: String): Boolean =
        ask(sel, "type", text) == "1"

    override fun select(sel: Selector, label: String): Boolean =
        ask(sel, "select", label) == "1"

    override fun readBack(sel: Selector): String = ask(sel, "read")

    override fun pageText(): String = js(pageTextScript())

    /**
     * Whatever the portal is telling us right now. A confirm box counts:
     * the app answered it, but what it said is still the portal talking.
     */
    override fun pageMessage(): String {
        val fromPage = js(messageScript())
        val fromDialog = dialogSaid
        return listOf(fromDialog, fromPage).filter { it.isNotBlank() }
            .joinToString(" | ").take(300)
    }

    override fun url(): String = currentUrl()

    override fun open(url: String) {
        if (url.startsWith("http://") || url.startsWith("https://")) load(url)
        else say("an address that is not http or https was not opened: $url")
    }

    override fun refresh() {
        main.post { web.reload() }
    }

    override fun frame(name: String) {
        // Frames are searched automatically, so there is nothing to
        // switch to. Said out loud rather than ignored.
        say("frames are searched already; \"$name\" needs no switching")
    }

    override fun hasPasswordBox(): Boolean =
        js("(function(){try{return document.querySelectorAll('input[type=password]')" +
            ".length>0?1:0;}catch(e){return 0;}})();").trim() == "1"

    // ------------------------------------------------------- the sign-in
    /**
     * Put the saved sign-in into the portal's own sign-in page.
     *
     * Nothing about this call is logged - not the value, not that it
     * happened with a value in it - because the page log is shown on
     * screen and kept in memory. The script is built with the two values
     * as JSON strings, so a password holding a quote or a backslash
     * cannot change what the script does.
     *
     * A captcha or a one-time code is never filled. Those are the portal
     * checking that a person is there, and a person is.
     *
     * Returns what happened: FILLED when both boxes were filled,
     * PASSWORD_ONLY when the username box could not be told apart,
     * NO_FORM when there is no sign-in form on the page.
     */
    fun fillSignIn(username: String, password: String): SignInResult {
        if (password.isEmpty()) return SignInResult.NO_FORM
        val script = "(function(){" + SIGN_IN_HELPERS +
            "var u=" + Json.quote(username) + ";" +
            "var p=" + Json.quote(password) + ";" +
            FILL_BODY + "})();"
        val answer = js(script)
        say(when (answer) {
            "1" -> "the sign-in was filled in"
            "2" -> "the password box was filled; the username box could not be " +
                "told apart, so type it yourself"
            else -> "no sign-in form was found on this page"
        })
        return when (answer) {
            "1" -> SignInResult.FILLED
            "2" -> SignInResult.PASSWORD_ONLY
            else -> SignInResult.NO_FORM
        }
    }

    /**
     * What is in the sign-in boxes right now, so it can be remembered.
     *
     * Only ever called because the surveyor tapped "Remember this
     * sign-in". The answer goes straight into the keystore-backed vault
     * and nowhere else.
     */
    fun readSignIn(): Pair<String, String>? {
        val answer = js("(function(){" + SIGN_IN_HELPERS + READ_BODY_SIGNIN + "})();")
        if (answer.isBlank()) return null
        return try {
            val parsed = Json.parse(answer)
            val user = parsed.str("u")
            val pass = parsed.str("p")
            if (pass.isEmpty()) null else user to pass
        } catch (e: Exception) {
            null
        }
    }

    /** Is a sign-in page showing? */
    fun isSignInPage(): Boolean = hasPasswordBox()

    /** Keep the session across a restart, which is what cookies are for. */
    fun keepSession() {
        try {
            CookieManager.getInstance().flush()
        } catch (e: Exception) {
            say("the session cookies could not be written down")
        }
    }

    enum class SignInResult { FILLED, PASSWORD_ONLY, NO_FORM }

    override fun screenshot(tag: String): String {
        val folder = shotFolder ?: return ""
        return try {
            val file = File(folder, "${System.currentTimeMillis()}_$tag.png")
            val bitmap = onMain {
                val w = web.width.coerceAtLeast(1)
                val h = web.height.coerceAtLeast(1)
                val bm = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
                web.draw(Canvas(bm))
                bm
            }
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 70, it) }
            bitmap.recycle()
            file.absolutePath
        } catch (e: Exception) {
            say("a picture of the page could not be taken: ${e.message}")
            ""
        }
    }

    override fun sleep(ms: Long) {
        try {
            Thread.sleep(ms.coerceIn(0, 60_000))
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    override fun now(): Long = System.currentTimeMillis()

    override fun log(line: String) = say(line)

    // ------------------------------------------------- talking to the page
    /**
     * One question about one box.
     *
     * The script is built here from a fixed shape with the selector and
     * the value put in as JSON strings, so a value with a quote in it -
     * a Telugu name, a path with a backslash - cannot change what the
     * script does.
     */
    private fun ask(sel: Selector, what: String, value: String = ""): String {
        val script = buildString {
            append("(function(){")
            append(FIND)
            append("var el=find(")
            append(Json.quote(sel.kind)).append(',')
            append(Json.quote(sel.value)).append(");")
            append("if(!el) return '';")
            append("var V=").append(Json.quote(value)).append(";")
            append(
                when (what) {
                    "exists" -> "return '1';"
                    "visible" ->
                        "var r=el.getBoundingClientRect();" +
                            "var s=window.getComputedStyle(el);" +
                            "return (r.width>0&&r.height>0&&s.visibility!=='hidden'" +
                            "&&s.display!=='none')?'1':'0';"
                    "options" ->
                        "return el.options? String(el.options.length) : '0';"
                    "click" ->
                        "try{el.scrollIntoView({block:'center'});}catch(e){}" +
                            "try{el.focus();}catch(e){}" +
                            "try{el.click();}catch(e){return '0';}return '1';"
                    "type" ->
                        "try{el.scrollIntoView({block:'center'});}catch(e){}" +
                            "try{el.focus();}catch(e){}" +
                            "try{el.value=V;" +
                            "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                            "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                            "}catch(e){return '0';}return '1';"
                    "select" -> SELECT_BODY
                    "read" -> READ_BODY
                    else -> "return '';"
                }
            )
            append("})();")
        }
        return js(script)
    }

    /** Run a script and wait for its answer. Never on the main thread. */
    private fun js(script: String, timeoutMs: Long = 6_000): String {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            // Answering here would deadlock. Say so rather than hang.
            say("a page question was asked on the main thread and skipped")
            return ""
        }
        val latch = CountDownLatch(1)
        var raw = ""
        main.post {
            try {
                web.evaluateJavascript(script) { value ->
                    raw = value ?: ""
                    latch.countDown()
                }
            } catch (e: Exception) {
                raw = ""
                latch.countDown()
            }
        }
        val answered = latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        if (!answered) {
            say("the page did not answer in ${timeoutMs / 1000} seconds")
            return ""
        }
        return decode(raw)
    }

    /** evaluateJavascript hands back JSON, so "x" arrives as "\"x\"". */
    private fun decode(raw: String): String {
        if (raw.isEmpty() || raw == "null") return ""
        return try {
            when (val v = Json.parse(raw)) {
                is Json.Str -> v.value
                is Json.Num -> Json.numberText(v.value)
                is Json.Bool -> if (v.value) "1" else "0"
                else -> ""
            }
        } catch (e: Exception) {
            raw.trim('"')
        }
    }

    private fun <T> onMain(body: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return body()
        val latch = CountDownLatch(1)
        var out: T? = null
        var failed: Exception? = null
        main.post {
            try {
                out = body()
            } catch (e: Exception) {
                failed = e
            } finally {
                latch.countDown()
            }
        }
        latch.await(5, TimeUnit.SECONDS)
        failed?.let { throw it }
        @Suppress("UNCHECKED_CAST")
        return out as T
    }

    private fun pageTextScript(): String =
        "(function(){try{var t=(document.body&&document.body.innerText)||'';" +
            "var f=window.frames;for(var i=0;i<f.length;i++){try{" +
            "t+=' '+(f[i].document.body.innerText||'');}catch(e){}}" +
            "return t.substring(0,4000);}catch(e){return '';}})();"

    /**
     * The same places the Windows application looks for a message, in
     * the same order. These are the ids and classes Webland actually
     * uses; a message that turns up somewhere else is caught by the page
     * text instead.
     */
    private fun messageScript(): String =
        "(function(){" + DOCS + "var sel=[\"span[id*='lblmsg' i]\"," +
            "\"span[id*='lblMessage' i]\",\"span[id*='lblError' i]\"," +
            "\"span[id*='lblstatus' i]\",\"div[class*='error' i]\"," +
            "\"div[class*='alert' i]\",\"span[style*='color' i]\"];" +
            "var out=[];for(var d=0;d<docs.length;d++){" +
            "for(var s=0;s<sel.length;s++){try{" +
            "var n=docs[d].querySelectorAll(sel[s]);" +
            "for(var i=0;i<n.length&&i<4;i++){" +
            "var t=(n[i].innerText||n[i].textContent||'').trim();" +
            "if(t&&t.length<300&&out.indexOf(t)<0)out.push(t);}" +
            "}catch(e){}}}return out.join(' | ').substring(0,300);})();"

    companion object {
        const val DESKTOP_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"

        /** Every document this page has: itself, and its same-origin frames. */
        private const val DOCS =
            "var docs=[document];try{var fr=window.frames;" +
                "for(var q=0;q<fr.length;q++){try{if(fr[q].document)" +
                "docs.push(fr[q].document);}catch(e){}}}catch(e){}"

        /**
         * Finding a box, the way the recorder describes one: by its id,
         * its form name, a CSS path, an XPath, the words on a link or
         * button, or the label beside it. Every document is searched.
         */
        private const val FIND = DOCS + """
function one(doc,kind,value){
 try{
  if(kind==='id') return doc.getElementById(value);
  if(kind==='name'){var n=doc.getElementsByName(value);return n.length?n[0]:null;}
  if(kind==='css') return doc.querySelector(value);
  if(kind==='value') return doc.querySelector('[value="'+value+'"]');
  if(kind==='xpath'){var r=doc.evaluate(value,doc,null,9,null);return r.singleNodeValue;}
  if(kind==='linktext'||kind==='link'||kind==='partiallinktext'){
   var a=doc.querySelectorAll('a,button,input[type=submit],input[type=button]');
   for(var i=0;i<a.length;i++){
    var t=(a[i].innerText||a[i].textContent||a[i].value||'').trim();
    if(kind==='partiallinktext'? t.indexOf(value)>=0 : t===value) return a[i];}
   return null;}
  if(kind==='text'){
   var e=doc.querySelectorAll('a,button,span,td,th,label,div,input');
   for(var j=0;j<e.length;j++){
    var s=(e[j].innerText||e[j].textContent||e[j].value||'').trim();
    if(s===value) return e[j];}
   return null;}
  if(kind==='label'){
   var l=doc.getElementsByTagName('label');
   for(var k=0;k<l.length;k++){
    if((l[k].innerText||'').trim()===value){
     var f=l[k].htmlFor;
     if(f){var g=doc.getElementById(f); if(g) return g;}
     var inner=l[k].querySelector('input,select,textarea');
     if(inner) return inner;}}
   var cells=doc.querySelectorAll('td,th');
   for(var m=0;m<cells.length;m++){
    if((cells[m].innerText||'').trim()===value){
     var row=cells[m].parentNode;
     var box=row? row.querySelector('input,select,textarea') : null;
     if(box) return box;}}
   return null;}
 }catch(e){return null;}
 return null;}
function find(kind,value){
 for(var d=0;d<docs.length;d++){var el=one(docs[d],kind,value); if(el) return el;}
 return null;}
"""

        /**
         * Choosing from a list by the words showing in it.
         *
         * The words are compared with their spacing tidied, because the
         * portal's own options sometimes carry a stray space, and a
         * dropdown that silently stays unset is the failure this whole
         * app exists to catch. If the word is not in the list, this says
         * so rather than picking something near it.
         */
        private const val SELECT_BODY = """
if(!el.options) return '0';
function tidy(s){return (s||'').replace(/\s+/g,' ').trim();}
var want=tidy(V);
for(var i=0;i<el.options.length;i++){
 if(tidy(el.options[i].text)===want){
  if(el.selectedIndex!==i){
   el.selectedIndex=i;
   try{el.dispatchEvent(new Event('input',{bubbles:true}));}catch(e){}
   try{el.dispatchEvent(new Event('change',{bubbles:true}));}catch(e){}
  }
  return '1';}}
return '0';
"""

        /**
         * Finding a sign-in form, in any of the page's documents.
         *
         * The username box is the last ordinary text box before the
         * password box in the page's own order, which is what a sign-in
         * form looks like whoever built it. A box whose name or
         * placeholder says captcha, otp, pin or cvv is passed over
         * everywhere here - as the field to fill and as the field to
         * read.
         */
        private const val SIGN_IN_HELPERS = DOCS + """
function offLimits(el){
 try{
  var n=((el.name||'')+' '+(el.id||'')+' '+
         (el.getAttribute('placeholder')||'')+' '+
         (el.getAttribute('aria-label')||'')).toLowerCase();
  return /captcha|otp|\bpin\b|cvv/.test(n);
 }catch(e){return true;}}
function signInForm(){
 for(var d=0;d<docs.length;d++){
  var doc=docs[d];
  var pw=null;
  try{
   var holders=doc.querySelectorAll('input[type=password]');
   for(var i=0;i<holders.length;i++){
    if(!offLimits(holders[i])){pw=holders[i];break;}}
  }catch(e){}
  if(!pw) continue;
  var user=null;
  try{
   var all=doc.querySelectorAll('input');
   for(var j=0;j<all.length;j++){
    if(all[j]===pw) break;
    var t=(all[j].type||'text').toLowerCase();
    if((t==='text'||t==='email'||t==='tel')&&!offLimits(all[j])) user=all[j];}
  }catch(e){}
  return {user:user, pw:pw};}
 return null;}
function put(el,value){
 try{
  el.focus();
  el.value=value;
  el.dispatchEvent(new Event('input',{bubbles:true}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
  return true;
 }catch(e){return false;}}
"""

        private const val FILL_BODY = """
var form=signInForm();
if(!form) return '0';
var okPassword=put(form.pw,p);
var okUser=(form.user&&u)? put(form.user,u) : false;
if(!okPassword) return '0';
return okUser? '1' : '2';
"""

        private const val READ_BODY_SIGNIN = """
var form=signInForm();
if(!form||!form.pw||!form.pw.value) return '';
return JSON.stringify({u:(form.user? (form.user.value||'') : ''),
                       p:form.pw.value});
"""

        /** What the box holds: a tick is "CHECKED", a list is its words. */
        private const val READ_BODY = """
try{
 if(el.options){
  return el.selectedIndex>=0? (el.options[el.selectedIndex].text||'') : '';}
 var t=(el.type||'').toLowerCase();
 if(t==='radio'||t==='checkbox') return el.checked? 'CHECKED' : '';
 if(typeof el.value!=='undefined' && el.value!==null) return String(el.value);
 return (el.innerText||el.textContent||'');
}catch(e){return '';}
"""
    }
}

/** Keeps the WebView out of a layout's way when a screen is torn down. */
fun WebView.detach() {
    (parent as? ViewGroup)?.removeView(this)
}
