package ap.webland.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * The portal sign-in, kept on the tablet.
 *
 * The surveyor asked for the username and password to be remembered
 * after signing in, so the whole file is about doing that in the one way
 * that is defensible.
 *
 * The password is NOT written into the settings file. It is encrypted
 * with AES-GCM under a key that is generated inside the tablet's own
 * keystore and never leaves it - on most tablets that means the key sits
 * in hardware and cannot be read out at all, even with the tablet opened
 * up. What the settings file holds is the encrypted bytes, which are
 * useless anywhere else: copy them to another tablet, or pull them off
 * this one, and there is no key to open them with.
 *
 * What this does NOT protect against, and the manual says so plainly:
 * anybody who can unlock this tablet can press "Fill sign-in" and be
 * signed in as the officer. That is exactly as true of the password
 * manager in any browser. The tablet's own lock screen is the lock on
 * this door, so it has to be set.
 *
 * Three rules hold everywhere else in the app:
 *   - the password is never put in the log, a report, an audit row, a
 *     recording or an export;
 *   - it is never read back out of a box to be compared, because a
 *     mismatch message would then carry it;
 *   - it is never typed into anything but a password box on the portal's
 *     own sign-in page, and never into a captcha or an OTP field.
 */
class Secret(context: Context) {

    private val box = context.getSharedPreferences("bwebland.signin",
        Context.MODE_PRIVATE)

    data class SignIn(val username: String, val password: String)

    val saved: Boolean get() = box.contains(USER) && box.contains(PASS)

    /** The username on its own, for showing on screen. */
    fun username(): String = read(USER) ?: ""

    fun signIn(): SignIn? {
        val user = read(USER) ?: return null
        val pass = read(PASS) ?: return null
        return SignIn(user, pass)
    }

    /**
     * Keep this sign-in. Called only when the surveyor asks for it -
     * from the Settings page, or by tapping "Remember this sign-in"
     * after typing it into the portal.
     */
    fun remember(username: String, password: String): Boolean {
        if (username.isBlank() || password.isEmpty()) return false
        return try {
            write(USER, username.trim())
            write(PASS, password)
            true
        } catch (e: Exception) {
            // A tablet whose keystore refuses is a tablet that does not
            // save the password. It is not a tablet that saves it in the
            // clear instead.
            forget()
            false
        }
    }

    /** Forget it, and throw the key away with it. */
    fun forget() {
        box.edit().remove(USER).remove(PASS).apply()
        try {
            KeyStore.getInstance(STORE).apply { load(null) }.deleteEntry(ALIAS)
        } catch (e: Exception) {
            // nothing to delete, which is the state we wanted anyway
        }
    }

    // ------------------------------------------------------------ inside
    private fun write(name: String, value: String) {
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val sealed = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val encoder = Base64.getEncoder()
        box.edit().putString(name,
            encoder.encodeToString(cipher.iv) + ":" +
                encoder.encodeToString(sealed)).apply()
    }

    private fun read(name: String): String? {
        val held = box.getString(name, null) ?: return null
        return try {
            val parts = held.split(":")
            if (parts.size != 2) return null
            val decoder = Base64.getDecoder()
            val iv = decoder.decode(parts[0])
            val sealed = decoder.decode(parts[1])
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, iv))
            String(cipher.doFinal(sealed), Charsets.UTF_8)
        } catch (e: Exception) {
            // The key is gone, or the bytes were tampered with - GCM
            // refuses either way. Nothing is guessed; the sign-in is
            // simply not there and has to be typed again.
            null
        }
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance(STORE).apply { load(null) }
        val existing = store.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey
        val maker = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, STORE)
        maker.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                // Deliberately not tied to a fresh unlock: a run of three
                // thousand records cannot stop to re-authenticate, and the
                // tablet's lock screen is already the gate. Said plainly
                // in the manual rather than left to be assumed.
                .setRandomizedEncryptionRequired(true)
                .build())
        return maker.generateKey()
    }

    companion object {
        private const val STORE = "AndroidKeyStore"
        private const val ALIAS = "bwebland.signin.v1"
        private const val TRANSFORM = "AES/GCM/NoPadding"
        private const val TAG_BITS = 128
        private const val USER = "u"
        private const val PASS = "p"

        /**
         * Boxes this app will never fill for you.
         *
         * A captcha or an OTP is the portal checking that a person is
         * there. Filling one would be defeating that check, which this
         * app does not do - the surveyor types those.
         */
        val NEVER_FILLED = listOf("captcha", "otp", "pin", "cvv")
    }
}
