package ap.webland

import android.app.Application
import androidx.room.Room
import ap.webland.data.Exports
import ap.webland.data.FileKit
import ap.webland.data.Prefs
import ap.webland.data.Repo
import ap.webland.data.Secret
import ap.webland.data.Store

/**
 * The one copy of everything the app keeps.
 *
 * The database is opened here and nowhere else, so there is never a
 * second connection writing to the same records, and the repository is
 * built once so that every screen is looking at the same project.
 */
class BWeblandApp : Application() {

    lateinit var store: Store
        private set
    lateinit var repo: Repo
        private set
    lateinit var prefs: Prefs
        private set
    lateinit var files: FileKit
        private set
    lateinit var exports: Exports
        private set

    /** The portal sign-in, encrypted under a key in the tablet's keystore. */
    lateinit var secret: Secret
        private set

    override fun onCreate() {
        super.onCreate()
        store = Room.databaseBuilder(this, Store::class.java, "bwebland.db")
            // No destructive fallback: a land register is not something
            // to drop and rebuild because a column changed. A migration
            // gets written when the schema moves.
            .build()
        repo = Repo(store.dao())
        prefs = Prefs(this)
        files = FileKit(this)
        exports = Exports(files)
        secret = Secret(this)
    }

    companion object {
        const val VERSION = "18.0"
        const val MADE_BY = "Bhanu Pratap, Village Surveyor, Andhra Pradesh"
    }
}
