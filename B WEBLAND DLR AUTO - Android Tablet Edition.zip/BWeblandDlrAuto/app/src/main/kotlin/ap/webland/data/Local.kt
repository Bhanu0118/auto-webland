package ap.webland.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import ap.webland.core.Csv
import ap.webland.core.Sheet
import ap.webland.core.Table
import ap.webland.core.Xlsx
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * What the tablet remembers about how the surveyor likes to work, and
 * how files get in and out.
 *
 * Android does not hand an app the storage card any more, and that is a
 * good thing here: every file this app reads was chosen by the surveyor
 * in the system's own picker, so there is no folder it can wander into
 * and nothing it can overwrite by accident. The cost is that a file is a
 * `Uri` rather than a path, and that a spreadsheet has to be opened more
 * than once - which is why `streamer` hands back a fresh stream each
 * time rather than one stream to share.
 */
class Prefs(context: Context) {
    private val p = context.getSharedPreferences("bwebland", Context.MODE_PRIVATE)

    var telugu: Boolean
        get() = p.getBoolean("telugu", true)
        set(v) = p.edit().putBoolean("telugu", v).apply()

    /** "light", "dark" or "system" */
    var theme: String
        get() = p.getString("theme", "system") ?: "system"
        set(v) = p.edit().putString("theme", v).apply()

    var decimals: Int
        get() = p.getInt("decimals", 3)
        set(v) = p.edit().putInt("decimals", v.coerceIn(0, 6)).apply()

    /** 0 careful, 1 steady, 2 brisk - the same three the laptop has */
    var speed: Int
        get() = p.getInt("speed", 1)
        set(v) = p.edit().putInt("speed", v.coerceIn(0, 2)).apply()

    var portalUrl: String
        get() = p.getString("portal", ap.webland.core.PortalWords.START_URL)
            ?: ap.webland.core.PortalWords.START_URL
        set(v) = p.edit().putString("portal", v).apply()

    /** the PDF the Add Record form wants attached */
    var pdfUri: String
        get() = p.getString("pdf", "") ?: ""
        set(v) = p.edit().putString("pdf", v).apply()

    /** who is working, for the audit trail. Never a password. */
    var officer: String
        get() = p.getString("officer", "") ?: ""
        set(v) = p.edit().putString("officer", v).apply()

    var projectId: Long
        get() = p.getLong("project", 0L)
        set(v) = p.edit().putLong("project", v).apply()

    /**
     * Fill the saved sign-in as soon as the portal's own sign-in page
     * opens. Off until the surveyor turns it on, because a password
     * typed into a page by itself should be something that was asked
     * for.
     */
    var autoFillSignIn: Boolean
        get() = p.getBoolean("autofill", false)
        set(v) = p.edit().putBoolean("autofill", v).apply()

    /** How long a step may wait, from the chosen pace. */
    fun timeoutMs(): Long = when (speed) {
        0 -> 20_000
        2 -> 8_000
        else -> 12_000
    }

    fun paceScale(): Double = when (speed) {
        0 -> 1.7
        2 -> 0.72
        else -> 1.0
    }
}

/** Reading and writing the files the surveyor points at. */
class FileKit(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** The name the picker showed, which is the name a person recognises. */
    fun nameOf(uri: Uri): String {
        resolver.query(uri, null, null, null, null)?.use { c ->
            val at = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (at >= 0 && c.moveToFirst()) return c.getString(at) ?: uri.lastPathSegment
                ?: "file"
        }
        return uri.lastPathSegment ?: "file"
    }

    fun sizeOf(uri: Uri): Long {
        resolver.query(uri, null, null, null, null)?.use { c ->
            val at = c.getColumnIndex(OpenableColumns.SIZE)
            if (at >= 0 && c.moveToFirst()) return c.getLong(at)
        }
        return -1
    }

    /** Hold on to a chosen file across restarts. */
    fun remember(uri: Uri) {
        try {
            resolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // the picker did not offer it; the uri still works this session
        }
    }

    fun text(uri: Uri, limitBytes: Int = 16 * 1024 * 1024): String {
        resolver.openInputStream(uri).use { stream ->
            if (stream == null) throw java.io.IOException("That file could not be opened.")
            val bytes = stream.readBytes()
            if (bytes.size > limitBytes)
                throw java.io.IOException("That file is larger than this app reads.")
            return String(bytes, Charsets.UTF_8)
        }
    }

    fun bytes(uri: Uri): ByteArray =
        resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw java.io.IOException("That file could not be opened.")

    /** A fresh stream every time, which is what the zip reader needs. */
    fun streamer(uri: Uri): () -> InputStream = {
        resolver.openInputStream(uri)
            ?: throw java.io.IOException("That file could not be opened.")
    }

    enum class Kind { XLSX, CSV, BWA, UIVISION_JSON, KML, GEOJSON, ZIP, PDF, OTHER }

    fun kindOf(name: String): Kind {
        val low = name.lowercase()
        return when {
            low.endsWith(".xlsx") || low.endsWith(".xlsm") ||
                low.endsWith(".xltx") -> Kind.XLSX
            low.endsWith(".csv") || low.endsWith(".tsv") -> Kind.CSV
            low.endsWith(".bwa") -> Kind.BWA
            low.endsWith(".json") || low.endsWith(".geojson") ->
                if (low.endsWith(".geojson")) Kind.GEOJSON else Kind.UIVISION_JSON
            low.endsWith(".kml") -> Kind.KML
            low.endsWith(".zip") || low.endsWith(".kmz") -> Kind.ZIP
            low.endsWith(".pdf") -> Kind.PDF
            else -> Kind.OTHER
        }
    }

    /** A spreadsheet or a CSV, whichever it is, as one table. */
    fun table(uri: Uri, sheet: Int = 0): Table {
        val name = nameOf(uri)
        return when (kindOf(name)) {
            Kind.XLSX -> Xlsx.read(streamer(uri), sheet)
            Kind.CSV -> Table.of(Csv.parse(text(uri)))
            else -> throw java.io.IOException(
                "\"$name\" is not a workbook or a CSV.")
        }
    }

    fun sheetNames(uri: Uri): List<String> =
        if (kindOf(nameOf(uri)) == Kind.XLSX) Xlsx.sheetNames(streamer(uri))
        else listOf(nameOf(uri))

    /** The .dbf inside a shapefile zip: attributes, never geometry. */
    fun dbfInZip(uri: Uri): Pair<String, ByteArray>? {
        ZipInputStream(streamer(uri)()).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name.lowercase().endsWith(".dbf")) {
                    return e.name to zip.readBytes()
                }
                e = zip.nextEntry
            }
        }
        return null
    }

    /** Every KML inside a zip or kmz, by name. */
    fun kmlInZip(uri: Uri): Pair<String, String>? {
        ZipInputStream(streamer(uri)()).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name.lowercase().endsWith(".kml")) {
                    return e.name to String(zip.readBytes(), Charsets.UTF_8)
                }
                e = zip.nextEntry
            }
        }
        return null
    }

    // --------------------------------------------------------- writing
    /** Where everything the app writes for the surveyor goes. */
    fun exportDir(): File =
        File(context.filesDir, "exports").apply { mkdirs() }

    fun exportFile(name: String): File = File(exportDir(), name)

    fun shotDir(): File = File(context.filesDir, "shots").apply { mkdirs() }

    /** A workbook of several sheets, into the app's own export folder. */
    fun writeWorkbook(fileName: String, sheets: List<Sheet>): File {
        val file = File(exportDir(), safeName(fileName, ".xlsx"))
        file.outputStream().use { Xlsx.write(it, sheets) }
        return file
    }

    fun writeCsv(fileName: String, sheet: Sheet): File {
        val file = File(exportDir(), safeName(fileName, ".csv"))
        file.writeText(Csv.write(sheet.asCells()), Charsets.UTF_8)
        return file
    }

    fun writeText(fileName: String, body: String): File {
        val file = File(exportDir(), fileName)
        file.writeText(body, Charsets.UTF_8)
        return file
    }

    fun exported(): List<File> =
        exportDir().listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    /** Copy something the app made into a place the surveyor picked. */
    fun copyTo(target: Uri, source: File) {
        resolver.openOutputStream(target, "w")?.use { out ->
            source.inputStream().use { it.copyTo(out) }
        } ?: throw java.io.IOException("That place could not be written to.")
    }

    fun shareUri(file: File): Uri =
        androidx.core.content.FileProvider.getUriForFile(
            context, context.packageName + ".files", file)

    private fun safeName(name: String, ext: String): String {
        val keep = name.filter { it.isLetterOrDigit() || it in " _-." }
            .trim().ifBlank { "export" }
        return if (keep.lowercase().endsWith(ext)) keep else keep + ext
    }
}
