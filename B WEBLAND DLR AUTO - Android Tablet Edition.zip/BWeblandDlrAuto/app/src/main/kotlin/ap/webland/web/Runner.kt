package ap.webland.web

import ap.webland.core.BwaRunner
import ap.webland.core.Finding
import ap.webland.core.Level
import ap.webland.core.Macro
import ap.webland.core.RowResult
import ap.webland.core.RowState
import ap.webland.core.Table
import ap.webland.core.UiVision
import ap.webland.core.UvMacro
import ap.webland.core.UvProgram
import ap.webland.core.UvRunner
import ap.webland.core.Validate
import ap.webland.data.MacroRow
import ap.webland.data.Prefs
import ap.webland.data.Repo
import ap.webland.data.RunRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Running an automation against the portal, and saving where it got to
 * after every single record.
 *
 * The engine blocks while it waits for the page, so none of this may
 * happen on the main thread - every entry point here moves to a
 * background one first. The WebView itself still lives on the main
 * thread and is spoken to through `PortalPage`, which posts each
 * question across and waits for the answer.
 *
 * Checkpointing after each record is the difference between a flat
 * battery costing one record and costing a morning. It is also what
 * makes "carry on from where it stopped" honest: the run knows the next
 * row it has not attempted, so nothing is entered twice.
 */
class AutomationRunner(
    private val repo: Repo,
    private val page: PortalPage,
    private val prefs: Prefs,
) {
    private val stopAsked = AtomicBoolean(false)
    private val pauseAsked = AtomicBoolean(false)

    @Volatile var busy: Boolean = false
        private set

    fun stop() { stopAsked.set(true) }
    fun pause() { pauseAsked.set(true) }
    fun unpause() { pauseAsked.set(false) }
    val paused: Boolean get() = pauseAsked.get()

    private fun stopped(): Boolean {
        while (pauseAsked.get() && !stopAsked.get()) {
            try {
                Thread.sleep(250)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                return true
            }
        }
        return stopAsked.get()
    }

    /** What is wrong before anything is entered. Nothing is run here. */
    suspend fun check(macro: MacroRow, table: Table?): List<Finding> =
        withContext(Dispatchers.Default) {
            try {
                if (macro.kind == "BWA") {
                    Validate.check(Macro.read(macro.body), table,
                        browserOpen = page.isOpen())
                } else {
                    Validate.check(UiVision.compile(UvMacro.read(macro.body)), table,
                        browserOpen = page.isOpen())
                }
            } catch (e: Exception) {
                listOf(Finding(Level.STOP, "file",
                    "That macro could not be read",
                    (e.message ?: e.toString()).take(200),
                    fix = "Choose the file again, or import it once more."))
            }
        }

    /** One record, for the Test-one-record button. Never a whole file. */
    suspend fun testOne(
        macro: MacroRow,
        table: Table,
        rowIndex: Int,
        password: String = "",
    ): RowResult = withContext(Dispatchers.Default) {
        stopAsked.set(false)
        pauseAsked.set(false)
        busy = true
        try {
            if (macro.kind == "BWA") {
                BwaRunner(Macro.read(macro.body), page, table, password,
                    decimals = prefs.decimals, stopped = ::stopped)
                    .runRow(rowIndex, table.lineOf(rowIndex))
            } else {
                UvRunner(program(macro), page, table,
                    decimals = prefs.decimals, stopped = ::stopped)
                    .runRow(rowIndex, table.lineOf(rowIndex))
            }
        } finally {
            busy = false
        }
    }

    /**
     * A range of rows.
     *
     * `onRow` is called on a background thread after every record, with
     * the run row as it now stands in the database. Returning false from
     * it stops the run.
     */
    suspend fun runRange(
        run: RunRow,
        macro: MacroRow,
        table: Table,
        from: Int,
        to: Int,
        password: String = "",
        onRow: suspend (RowResult, RunRow) -> Boolean,
    ): RunRow = withContext(Dispatchers.Default) {
        stopAsked.set(false)
        pauseAsked.set(false)
        busy = true
        var current = run
        try {
            val keep: (RowResult) -> Boolean = { result ->
                // the row's own line, then the next one to attempt
                current = kotlinx.coroutines.runBlocking {
                    repo.checkpoint(current, result, nextAfter(table, result.rowNumber))
                }
                kotlinx.coroutines.runBlocking { onRow(result, current) }
            }
            if (macro.kind == "BWA") {
                BwaRunner(Macro.read(macro.body), page, table, password,
                    decimals = prefs.decimals, stopped = ::stopped)
                    .run(from, to, keep)
            } else {
                UvRunner(program(macro), page, table,
                    decimals = prefs.decimals, stopped = ::stopped)
                    .run(from, to, keep)
            }
            val state = if (stopAsked.get()) "STOPPED" else "FINISHED"
            repo.endRun(current, state)
        } finally {
            busy = false
        }
    }

    /**
     * The rows that failed, and only those.
     *
     * A record whose save was never confirmed is NEEDS_REVIEW, and this
     * does not touch it. That is the whole point of keeping the two
     * apart: pressing Add again on a record that may already be in the
     * register is how a village ends up with two of it.
     */
    suspend fun retryFailed(
        run: RunRow,
        macro: MacroRow,
        table: Table,
        password: String = "",
        onRow: suspend (RowResult, RunRow) -> Boolean,
    ): RunRow = withContext(Dispatchers.Default) {
        val lines = repo.rowsToRetry(run.projectId)
        if (lines.isEmpty()) return@withContext run
        stopAsked.set(false)
        pauseAsked.set(false)
        busy = true
        var current = run
        try {
            val keep: (RowResult) -> Boolean = { result ->
                current = kotlinx.coroutines.runBlocking {
                    repo.checkpoint(current, result, current.nextRow)
                }
                kotlinx.coroutines.runBlocking { onRow(result, current) }
            }
            if (macro.kind == "BWA") {
                BwaRunner(Macro.read(macro.body), page, table, password,
                    decimals = prefs.decimals, stopped = ::stopped)
                    .runThese(lines, keep)
            } else {
                val runner = UvRunner(program(macro), page, table,
                    decimals = prefs.decimals, stopped = ::stopped)
                val byLine = HashMap<Int, Int>()
                for (i in 0 until table.count()) byLine[table.lineOf(i)] = i
                for (line in lines) {
                    if (stopped()) break
                    val index = byLine[line] ?: continue
                    if (!keep(runner.runRow(index, line))) break
                }
            }
            repo.endRun(current, if (stopAsked.get()) "STOPPED" else "FINISHED")
        } finally {
            busy = false
        }
    }

    /** One record entered from a recording built here, not from a file. */
    suspend fun testFlow(
        auto: ap.webland.core.Automation,
        table: Table,
        rowIndex: Int = 0,
        password: String = "",
    ): RowResult = withContext(Dispatchers.Default) {
        stopAsked.set(false)
        pauseAsked.set(false)
        busy = true
        try {
            BwaRunner(auto, page, table, password, decimals = prefs.decimals,
                stopped = ::stopped).runRow(rowIndex, table.lineOf(rowIndex))
        } finally {
            busy = false
        }
    }

    /**
     * A whole project entered by the kind of land each record is.
     *
     * This is the classification-wise run without a macro for every
     * classification. The form for a kind of land is built once from the
     * land-nature table and used for every record of that kind, so a
     * workbook holding wet, dry, poramboke and d-patta together goes in
     * in one pass, each record through its own chain.
     *
     * A record that has not been told what kind of land it is does NOT
     * get a guess. It is marked and left for the surveyor, because the
     * chain decides what the register will say about that plot.
     */
    suspend fun runRecords(
        run: RunRow,
        records: List<ap.webland.data.RecordRow>,
        pdfPath: String = "",
        onRow: suspend (RowResult, RunRow) -> Boolean,
    ): RunRow = withContext(Dispatchers.Default) {
        stopAsked.set(false)
        pauseAsked.set(false)
        busy = true
        var current = run
        val built = HashMap<String, ap.webland.core.Automation>()
        try {
            var inARow = 0
            for (record in records) {
                if (stopped()) break
                val preset = ap.webland.core.Presets.byId(record.presetId)
                val result: RowResult
                if (preset == null) {
                    result = RowResult(record.rowNumber, RowState.FAILED,
                        ap.webland.core.Codes.FIELD_MISMATCH,
                        "no kind of land has been chosen for this record")
                } else {
                    val auto = built.getOrPut(preset.id) {
                        ap.webland.core.AddFlow.build(preset, pdfPath = pdfPath)
                    }
                    val one = ap.webland.core.AddFlow.oneRow(
                        lpm = record.lpm,
                        extent = record.extent,
                        syno = record.surveyNo,
                        subdiv = record.subDivision,
                        khata = record.khata,
                        name = record.pattadarName,
                        relation = record.relationName,
                        lineNumber = record.rowNumber)
                    result = BwaRunner(auto, page, one, decimals = prefs.decimals,
                        stopped = ::stopped).runRow(0, record.rowNumber)
                }
                current = repo.checkpoint(current, result, record.rowNumber + 1)
                if (!onRow(result, current)) break
                inARow = if (result.state == RowState.FAILED) inARow + 1 else 0
                if (inARow >= 5) {
                    page.log("five records failed one after another; stopping")
                    break
                }
            }
            repo.endRun(current, if (stopAsked.get()) "STOPPED" else "FINISHED")
        } finally {
            busy = false
        }
    }

    private fun program(macro: MacroRow): UvProgram =
        UiVision.compile(UvMacro.read(macro.body))

    /** The next file line after this one, for carrying on after a stop. */
    private fun nextAfter(table: Table, lineNumber: Int): Int {
        for (i in 0 until table.count()) {
            if (table.lineOf(i) == lineNumber) return i + 2
        }
        return lineNumber + 1
    }

    companion object {
        /** How a row's state reads on screen, in one word. */
        fun word(state: RowState): String = when (state) {
            RowState.SUCCESS -> "entered"
            RowState.FAILED -> "failed"
            RowState.NEEDS_REVIEW -> "needs review"
            RowState.SKIPPED -> "skipped"
            RowState.RUNNING -> "running"
            RowState.PENDING -> "not attempted"
        }
    }
}
