package ap.webland.ui.screens

import android.net.Uri
import android.webkit.WebView
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import ap.webland.ui.AppModel
import ap.webland.ui.Gap
import ap.webland.ui.Say
import ap.webland.ui.Words
import ap.webland.ui.text
import ap.webland.web.detach

/**
 * The pieces more than one screen needs.
 *
 * `PortalView` is the important one. There is a single WebView in the
 * whole app, made by the activity, because the portal's session lives in
 * it - a second one would be signed out. Whichever screen is showing it
 * takes it off its last parent and puts it in its own layout.
 */
@Composable
fun PortalView(model: AppModel, modifier: Modifier = Modifier.fillMaxSize()) {
    AndroidView(
        factory = { context ->
            model.webView?.also { it.detach() } ?: WebView(context)
        },
        modifier = modifier,
    )
}

@Composable
fun Page(title: String, note: String = "", content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary)
        if (note.isNotBlank()) {
            Text(note, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Gap(14)
        content()
    }
}

/** A page whose main business is the portal, so it must not scroll. */
@Composable
fun FixedPage(title: String, note: String = "", content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize()
            .padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 12.dp),
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary)
        if (note.isNotBlank()) {
            Text(note, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Gap(10)
        content()
    }
}

@Composable
fun Do(say: Say, onClick: () -> Unit, enabled: Boolean = true) {
    Button(onClick = onClick, enabled = enabled,
        modifier = Modifier.padding(end = 10.dp, bottom = 6.dp)) {
        Text(say.text())
    }
}

@Composable
fun Maybe(say: Say, onClick: () -> Unit, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, enabled = enabled,
        modifier = Modifier.padding(end = 10.dp, bottom = 6.dp)) {
        Text(say.text())
    }
}

@Composable
fun Buttons(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        content()
    }
}

/** Opening a file the surveyor picks. The app never goes looking itself. */
@Composable
fun rememberPicker(
    onPick: (Uri) -> Unit,
): ManagedActivityResultLauncher<Array<String>, Uri?> =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPick(uri)
    }

/** Saving a file out to wherever the surveyor wants it. */
@Composable
fun rememberSaver(
    onPlace: (Uri) -> Unit,
): ManagedActivityResultLauncher<String, Uri?> =
    rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) onPlace(uri)
    }

val anyFile = arrayOf("*/*")
val sheetFiles = arrayOf(
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "text/*")
val macroFiles = arrayOf("application/json", "text/plain", "*/*")
val mapFiles = arrayOf(
    "application/vnd.google-earth.kml+xml", "application/zip",
    "application/json", "*/*")

/**
 * The portal's own row of buttons.
 *
 * The browser is the app's own, inside this screen — not Chrome — so the
 * session belongs to the app and survives a restart. The sign-in buttons
 * are here rather than buried in Settings because this is where the
 * surveyor is standing when they need them: fill what was saved, or
 * remember what was just typed.
 */
@Composable
fun PortalBar(model: AppModel) {
    Column(Modifier.fillMaxWidth()) {
        Buttons {
            Do(Words.open, { model.openPortal() })
            Maybe(Words.refresh, { model.refreshLog() })
            Text(
                if (model.portalOpen)
                    Say("The portal is open", "పోర్టల్ తెరిచి ఉంది").text()
                else Words.portalNotOpen.text(),
                style = MaterialTheme.typography.bodySmall,
                color = if (model.portalOpen) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
        Buttons {
            Maybe(Words.fillSignIn, { model.fillSignIn() },
                enabled = model.portalOpen && model.signInSaved)
            Maybe(Words.rememberFromPage, { model.rememberFromPage() },
                enabled = model.portalOpen)
            Text(
                if (model.signInSaved)
                    "${Words.signInSaved.text()}: ${model.signInUser}"
                else Words.nothingSaved.text(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}
