package ap.webland.data

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Everything the tablet keeps, and the shape it keeps it in.
 *
 * The part worth reading twice is the record table. Each record carries
 * BOTH what the file said and what is in the boxes now, as two pieces of
 * text, plus a row in the audit table for every single change. That is
 * three copies of the same information, which looks wasteful until the
 * day somebody asks why an extent in the register is not the extent in
 * the Adangal. Then it is the only answer there is.
 *
 * A record also carries its automation state as the core module names it
 * - SUCCESS, FAILED, NEEDS_REVIEW and the rest - because the dashboard
 * must be able to show "needs review" as its own number. A record that
 * may already be in the portal is not a failure and must never be
 * counted as one, or offered for a retry.
 */

@Entity(tableName = "project")
data class ProjectRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val village: String = "",
    val mandal: String = "",
    val district: String = "",
    /** the workbook this project was made from, as the person sees it */
    val sourceFile: String = "",
    val sourceUri: String = "",
    val sheet: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long = 0,
)

@Entity(
    tableName = "record",
    indices = [Index("projectId"), Index("lpm"), Index("automationState")],
)
data class RecordRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    /** the line this record is on in its own file */
    val rowNumber: Int,
    val lpm: String = "",
    val extent: String = "",
    val surveyNo: String = "",
    val subDivision: String = "",
    val khata: String = "",
    val pattadarName: String = "",
    val relationName: String = "",
    /** which row of the land-nature table this record is */
    val presetId: String = "",
    /** the whole source row, as JSON, exactly as the file had it */
    val originalJson: String = "",
    /** the row as it stands now, as JSON */
    val currentJson: String = "",
    val validation: String = "",
    @ColumnInfo(defaultValue = "PENDING")
    val automationState: String = "PENDING",
    val code: String = "",
    val message: String = "",
    val stepId: String = "",
    val seconds: Double = 0.0,
    val screenshot: String = "",
    val reviewed: Boolean = false,
    val approvedBy: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "audit", indices = [Index("recordId"), Index("projectId")])
data class AuditRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val recordId: Long,
    val at: Long = System.currentTimeMillis(),
    val field: String,
    val was: String,
    val now: String,
    /** "import", "edit", "run", "report" - where the change came from */
    val source: String,
    val who: String = "",
)

@Entity(tableName = "macro")
data class MacroRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** BWA for a recording, UIVISION for a macro from the laptop */
    val kind: String,
    val uri: String = "",
    /** the file's own text, kept so a run does not depend on the uri */
    val body: String = "",
    val stepCount: Int = 0,
    val writeCount: Int = 0,
    val csvName: String = "",
    val addedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "run", indices = [Index("projectId")])
data class RunRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val macroId: Long,
    val macroName: String = "",
    val dataFile: String = "",
    val dataUri: String = "",
    val fromRow: Int = 1,
    val toRow: Int = 1,
    /** the next row to attempt: how a run carries on after a restart */
    val nextRow: Int = 1,
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0,
    /** RUNNING, PAUSED, STOPPED, FINISHED */
    val state: String = "RUNNING",
    val success: Int = 0,
    val failed: Int = 0,
    val review: Int = 0,
    val skipped: Int = 0,
    val note: String = "",
)

data class StateCount(val automationState: String, val howMany: Int)

@Dao
interface Dao0 {
    // --------------------------------------------------------- projects
    @Insert
    suspend fun addProject(row: ProjectRow): Long

    @Update
    suspend fun updateProject(row: ProjectRow)

    @Query("SELECT * FROM project ORDER BY createdAt DESC")
    fun projects(): Flow<List<ProjectRow>>

    @Query("SELECT * FROM project WHERE id = :id")
    suspend fun project(id: Long): ProjectRow?

    @Query("SELECT * FROM project ORDER BY createdAt DESC LIMIT 1")
    suspend fun newestProject(): ProjectRow?

    @Query("DELETE FROM project WHERE id = :id")
    suspend fun deleteProject(id: Long)

    // ---------------------------------------------------------- records
    @Insert
    suspend fun addRecords(rows: List<RecordRow>)

    @Update
    suspend fun updateRecord(row: RecordRow)

    @Query("SELECT * FROM record WHERE projectId = :projectId ORDER BY rowNumber")
    fun records(projectId: Long): Flow<List<RecordRow>>

    @Query("SELECT * FROM record WHERE projectId = :projectId ORDER BY rowNumber")
    suspend fun recordList(projectId: Long): List<RecordRow>

    @Query("SELECT * FROM record WHERE projectId = :projectId AND rowNumber = :rowNumber")
    suspend fun recordAt(projectId: Long, rowNumber: Int): RecordRow?

    @Query(
        "SELECT * FROM record WHERE projectId = :projectId AND " +
            "(lpm LIKE :like OR khata LIKE :like OR pattadarName LIKE :like OR " +
            "surveyNo LIKE :like) ORDER BY rowNumber LIMIT 400"
    )
    suspend fun findRecords(projectId: Long, like: String): List<RecordRow>

    @Query(
        "SELECT automationState, COUNT(*) AS howMany FROM record " +
            "WHERE projectId = :projectId GROUP BY automationState"
    )
    fun stateCounts(projectId: Long): Flow<List<StateCount>>

    @Query("SELECT COUNT(*) FROM record WHERE projectId = :projectId")
    fun recordCount(projectId: Long): Flow<Int>

    @Query(
        "SELECT COUNT(DISTINCT surveyNo) FROM record WHERE projectId = :projectId " +
            "AND surveyNo <> ''"
    )
    fun surveyCount(projectId: Long): Flow<Int>

    @Query(
        "SELECT COUNT(DISTINCT subDivision) FROM record WHERE projectId = :projectId " +
            "AND subDivision <> ''"
    )
    fun subDivisionCount(projectId: Long): Flow<Int>

    @Query(
        "SELECT COUNT(DISTINCT lpm) FROM record WHERE projectId = :projectId " +
            "AND lpm <> ''"
    )
    fun lpmCount(projectId: Long): Flow<Int>

    /**
     * The rows a retry may touch. FAILED and nothing else: this query is
     * the rule, so no screen can widen it by accident.
     */
    @Query(
        "SELECT * FROM record WHERE projectId = :projectId AND " +
            "automationState = 'FAILED' ORDER BY rowNumber"
    )
    suspend fun retryable(projectId: Long): List<RecordRow>

    @Query(
        "SELECT * FROM record WHERE projectId = :projectId AND " +
            "automationState = 'NEEDS_REVIEW' ORDER BY rowNumber"
    )
    suspend fun needingReview(projectId: Long): List<RecordRow>

    @Query(
        "UPDATE record SET automationState = :state, code = :code, " +
            "message = :message, stepId = :stepId, seconds = :seconds, " +
            "screenshot = :shot, updatedAt = :at " +
            "WHERE projectId = :projectId AND rowNumber = :rowNumber"
    )
    suspend fun markRecord(
        projectId: Long,
        rowNumber: Int,
        state: String,
        code: String,
        message: String,
        stepId: String,
        seconds: Double,
        shot: String,
        at: Long = System.currentTimeMillis(),
    )

    @Query("DELETE FROM record WHERE projectId = :projectId")
    suspend fun clearRecords(projectId: Long)

    // ------------------------------------------------------------ audit
    @Insert
    suspend fun addAudit(row: AuditRow)

    @Insert
    suspend fun addAudits(rows: List<AuditRow>)

    @Query("SELECT * FROM audit WHERE recordId = :recordId ORDER BY at DESC")
    suspend fun auditOf(recordId: Long): List<AuditRow>

    @Query("SELECT * FROM audit WHERE projectId = :projectId ORDER BY at DESC LIMIT 2000")
    suspend fun auditOfProject(projectId: Long): List<AuditRow>

    @Query("DELETE FROM audit WHERE projectId = :projectId")
    suspend fun clearAudit(projectId: Long)

    // ----------------------------------------------------------- macros
    @Insert
    suspend fun addMacro(row: MacroRow): Long

    @Query("SELECT * FROM macro ORDER BY addedAt DESC")
    fun macros(): Flow<List<MacroRow>>

    @Query("SELECT * FROM macro WHERE id = :id")
    suspend fun macro(id: Long): MacroRow?

    @Query("DELETE FROM macro WHERE id = :id")
    suspend fun deleteMacro(id: Long)

    // ------------------------------------------------------------- runs
    @Insert
    suspend fun addRun(row: RunRow): Long

    @Update
    suspend fun updateRun(row: RunRow)

    @Query("SELECT * FROM run WHERE projectId = :projectId ORDER BY startedAt DESC")
    fun runs(projectId: Long): Flow<List<RunRow>>

    @Query(
        "SELECT * FROM run WHERE projectId = :projectId AND " +
            "state IN ('RUNNING', 'PAUSED') ORDER BY startedAt DESC LIMIT 1"
    )
    suspend fun unfinishedRun(projectId: Long): RunRow?

    @Query("SELECT * FROM run WHERE projectId = :projectId ORDER BY startedAt DESC LIMIT 1")
    suspend fun lastRun(projectId: Long): RunRow?

    @Query("DELETE FROM run WHERE projectId = :projectId")
    suspend fun clearRuns(projectId: Long)
}

@Database(
    entities = [
        ProjectRow::class, RecordRow::class, AuditRow::class,
        MacroRow::class, RunRow::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class Store : RoomDatabase() {
    abstract fun dao(): Dao0
}
