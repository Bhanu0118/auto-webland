package ap.webland.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import ap.webland.core.Sheet
import java.io.File

/**
 * The detailed report, as a PDF.
 *
 * A4 across, because every one of these tables is wider than it is tall.
 * The drawing is deliberately plain - no library, no template - for one
 * reason: a report that will not open is worse than no report, and
 * everything here is in the Android framework already.
 *
 * Telugu comes out right because the text is drawn by the system, which
 * has the font. A name is never transliterated or shortened to fit; a
 * column is widened or the cell is cut with an ellipsis, and the full
 * value is always in the workbook beside it.
 */
object PdfReport {

    private const val WIDE = 842          // A4 landscape, in points
    private const val HIGH = 595
    private const val MARGIN = 28f

    fun write(
        file: File,
        title: String,
        subtitle: String,
        sheets: List<Sheet>,
        footer: String,
    ): File {
        val doc = PdfDocument()
        try {
            var pageNo = 1
            for (sheet in sheets) {
                if (sheet.isEmpty && sheet.headings.isEmpty()) continue
                pageNo = drawSheet(doc, sheet, title, subtitle, footer, pageNo)
            }
            if (pageNo == 1) {
                // nothing had any rows: say so on one page rather than
                // handing over an empty file
                val page = doc.startPage(
                    PdfDocument.PageInfo.Builder(WIDE, HIGH, 1).create())
                val c = page.canvas
                head(c, title, subtitle, 1)
                c.drawText("Nothing to report.", MARGIN, 120f, body())
                foot(c, footer, 1)
                doc.finishPage(page)
            }
            file.outputStream().use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
        return file
    }

    private fun drawSheet(
        doc: PdfDocument,
        sheet: Sheet,
        title: String,
        subtitle: String,
        footer: String,
        firstPageNo: Int,
    ): Int {
        var pageNo = firstPageNo
        val columns = sheet.headings.size.coerceAtLeast(1)
        val usable = WIDE - MARGIN * 2
        val widths = widthsOf(sheet, columns, usable)
        val rowHigh = 16f
        var page = doc.startPage(
            PdfDocument.PageInfo.Builder(WIDE, HIGH, pageNo).create())
        var canvas = page.canvas
        head(canvas, title, "$subtitle   -   ${sheet.name}", pageNo)
        var y = 96f
        drawRow(canvas, sheet.headings, widths, y, heading = true)
        y += rowHigh + 4

        for (row in sheet.rows) {
            if (y > HIGH - MARGIN - 28f) {
                foot(canvas, footer, pageNo)
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(
                    PdfDocument.PageInfo.Builder(WIDE, HIGH, pageNo).create())
                canvas = page.canvas
                head(canvas, title, "$subtitle   -   ${sheet.name} (continued)",
                    pageNo)
                y = 96f
                drawRow(canvas, sheet.headings, widths, y, heading = true)
                y += rowHigh + 4
            }
            drawRow(canvas, row, widths, y, heading = false)
            y += rowHigh
        }
        foot(canvas, footer, pageNo)
        doc.finishPage(page)
        return pageNo + 1
    }

    /** Wider columns for the ones that actually hold something. */
    private fun widthsOf(sheet: Sheet, columns: Int, usable: Float): FloatArray {
        val longest = FloatArray(columns)
        for (c in 0 until columns) {
            var most = sheet.headings.getOrElse(c) { "" }.length
            for (row in sheet.rows.take(400)) {
                val len = row.getOrElse(c) { "" }.length
                if (len > most) most = len
            }
            longest[c] = most.coerceIn(4, 40).toFloat()
        }
        val sum = longest.sum().coerceAtLeast(1f)
        return FloatArray(columns) { usable * longest[it] / sum }
    }

    private fun drawRow(
        canvas: Canvas,
        cells: List<String>,
        widths: FloatArray,
        y: Float,
        heading: Boolean,
    ) {
        val paint = if (heading) headingText() else body()
        if (heading) {
            val fill = Paint().apply { color = Color.rgb(0x1F, 0x38, 0x64) }
            canvas.drawRect(MARGIN, y - 12f, WIDE - MARGIN, y + 4f, fill)
        }
        var x = MARGIN + 3f
        for (i in widths.indices) {
            val text = cells.getOrElse(i) { "" }
            if (text.isNotEmpty()) {
                canvas.drawText(fit(text, widths[i] - 6f, paint), x, y, paint)
            }
            x += widths[i]
        }
    }

    /** As much of the value as the column holds, then an ellipsis. */
    private fun fit(text: String, width: Float, paint: Paint): String {
        if (paint.measureText(text) <= width) return text
        var cut = text.length
        while (cut > 1 && paint.measureText(text.take(cut) + "…") > width) cut--
        return text.take(cut) + "…"
    }

    private fun head(canvas: Canvas, title: String, subtitle: String, pageNo: Int) {
        canvas.drawText(title, MARGIN, 40f, titleText())
        canvas.drawText(subtitle, MARGIN, 60f, smallText())
        val line = Paint().apply {
            color = Color.rgb(0x1F, 0x38, 0x64)
            strokeWidth = 1.2f
        }
        canvas.drawLine(MARGIN, 70f, WIDE - MARGIN, 70f, line)
    }

    private fun foot(canvas: Canvas, footer: String, pageNo: Int) {
        canvas.drawText(footer, MARGIN, HIGH - 16f, smallText())
        val number = "page $pageNo"
        val paint = smallText()
        canvas.drawText(number, WIDE - MARGIN - paint.measureText(number),
            HIGH - 16f, paint)
    }

    private fun titleText() = Paint().apply {
        color = Color.rgb(0x1F, 0x38, 0x64)
        textSize = 17f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private fun headingText() = Paint().apply {
        color = Color.WHITE
        textSize = 9.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private fun body() = Paint().apply {
        color = Color.rgb(0x20, 0x24, 0x28)
        textSize = 9.5f
        isAntiAlias = true
    }

    private fun smallText() = Paint().apply {
        color = Color.rgb(0x60, 0x66, 0x70)
        textSize = 8.5f
        isAntiAlias = true
    }
}
