package ap.webland.ui

/**
 * Every word the surveyor reads, in both languages at once.
 *
 * This is in Kotlin rather than in strings.xml for two reasons. The
 * language can be switched on the Settings page and takes effect at
 * once, with no restart - which matters when a VRO and a Tahsildar share
 * one tablet. And a word that exists in English and not in Telugu will
 * not compile, instead of showing a blank space to whoever needed the
 * Telugu.
 *
 * Nothing here is a sentence the app invents about a record. Anything
 * that reports what happened to a record comes from the core module's
 * own failure table, which carries its own Telugu.
 */
data class Say(val en: String, val te: String) {
    fun get(telugu: Boolean): String = if (telugu) te else en
}

object Words {
    val appName = Say("B Webland DLR Auto", "బి వెబ్‌ల్యాండ్ DLR ఆటో")
    val edition = Say("Android Tablet Edition", "ఆండ్రాయిడ్ టాబ్లెట్ ఎడిషన్")
    val madeBy = Say(
        "Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh",
        "రూపకల్పన: భాను ప్రతాప్, విలేజ్ సర్వేయర్, ఆంధ్రప్రదేశ్")

    // ------------------------------------------------------- the screens
    val dashboard = Say("Dashboard", "డాష్‌బోర్డ్")
    val dlrData = Say("DLR Data", "DLR డేటా")
    val addRecord = Say("Add Record", "రికార్డు చేర్చు")
    val vsCorrelation = Say("VS Correlation", "VS కొరిలేషన్")
    val vroGroundTruth = Say("VRO Ground Truth", "VRO గ్రౌండ్ ట్రూత్")
    val digitalSign = Say("Digital Sign", "డిజిటల్ సంతకం")
    val recorder = Say("Recorder", "రికార్డర్")
    val runAutomation = Say("Run Automation", "ఆటోమేషన్ నడుపు")
    val validation = Say("Validation", "తనిఖీ")
    val reports = Say("Reports", "నివేదికలు")
    val fileManager = Say("Files", "ఫైల్స్")
    val settings = Say("Settings", "సెట్టింగ్‌లు")

    // -------------------------------------------------------- dashboard
    val project = Say("Project", "ప్రాజెక్టు")
    val village = Say("Village", "గ్రామం")
    val mandal = Say("Mandal", "మండలం")
    val district = Say("District", "జిల్లా")
    val surveyNumbers = Say("Survey numbers", "సర్వే నంబర్లు")
    val subdivisions = Say("Subdivisions", "సబ్ డివిజన్లు")
    val totalLpms = Say("LPMs", "LPM లు")
    val totalRecords = Say("DLR records", "DLR రికార్డులు")
    val completed = Say("Entered and confirmed", "నమోదై నిర్ధారణ అయినవి")
    val pending = Say("Not attempted yet", "ఇంకా ప్రయత్నించనివి")
    val failedCount = Say("Failed", "విఫలమైనవి")
    val reviewCount = Say("Need review", "పరిశీలించాల్సినవి")
    val skippedCount = Say("Skipped", "వదిలేసినవి")
    val lastSync = Say("Last run", "చివరి రన్")
    val runStatus = Say("Automation", "ఆటోమేషన్")
    val noProject = Say(
        "No project yet. Open the Files page and import a DLR workbook.",
        "ప్రాజెక్టు లేదు. ఫైల్స్ పేజీలో DLR వర్క్‌బుక్ దిగుమతి చేయండి.")
    val tabletNote = Say(
        "Drawn for a 10-inch tablet in landscape.",
        "10 అంగుళాల టాబ్లెట్, ల్యాండ్‌స్కేప్ కోసం రూపొందించింది.")
    val reviewNeverRetried = Say(
        "A record that needs review is never entered again by the app.",
        "పరిశీలించాల్సిన రికార్డును యాప్ మళ్ళీ నమోదు చేయదు.")

    // ------------------------------------------------------------- doing
    val open = Say("Open", "తెరువు")
    val import = Say("Import", "దిగుమతి")
    val export = Say("Export", "ఎగుమతి")
    val save = Say("Save", "భద్రపరచు")
    val cancel = Say("Cancel", "రద్దు")
    val close = Say("Close", "మూసివేయి")
    val delete = Say("Delete", "తొలగించు")
    val record = Say("Record", "రికార్డ్ చెయ్యి")
    val stop = Say("Stop", "ఆపు")
    val pause = Say("Pause", "విరామం")
    val resume = Say("Resume", "కొనసాగించు")
    val play = Say("Start", "ప్రారంభించు")
    val check = Say("Check", "తనిఖీ చేయి")
    val testOneRow = Say("Test one record", "ఒక రికార్డు పరీక్షించు")
    val retryFailed = Say("Retry the failed ones", "విఫలమైనవి మళ్ళీ")
    val chooseFile = Say("Choose a file", "ఫైల్ ఎంచుకో")
    val chooseMacro = Say("Choose a macro", "మాక్రో ఎంచుకో")
    val chooseFolder = Say("Choose a folder", "ఫోల్డర్ ఎంచుకో")
    val refresh = Say("Refresh", "రిఫ్రెష్")
    val approve = Say("Approve", "ఆమోదించు")
    val undo = Say("Undo", "వెనక్కి")
    val search = Say("Search", "వెతుకు")
    val edit = Say("Edit", "మార్చు")
    val signIn = Say("Open the portal and sign in", "పోర్టల్ తెరిచి లాగిన్ అవ్వండి")

    // ------------------------------------------------------- automation
    val macro = Say("Macro", "మాక్రో")
    val dataFile = Say("Data file", "డేటా ఫైల్")
    val fromRow = Say("From row", "ఈ వరుస నుంచి")
    val toRow = Say("To row", "ఈ వరుస వరకు")
    val rows = Say("rows", "వరుసలు")
    val commands = Say("commands", "కమాండ్లు")
    val perMinute = Say("records a minute", "నిమిషానికి రికార్డులు")
    val liveProgress = Say("Progress", "పురోగతి")
    val nothingRunning = Say("Nothing is running.", "ఏదీ నడవడం లేదు.")
    val portalNotOpen = Say(
        "The portal is not open. Open it and sign in before starting.",
        "పోర్టల్ తెరిచి లేదు. ప్రారంభించే ముందు తెరిచి లాగిన్ అవ్వండి.")
    val runFinished = Say("The run has finished.", "రన్ పూర్తయింది.")
    val resumeOffer = Say(
        "This run stopped partway. It can carry on from where it was.",
        "ఈ రన్ మధ్యలో ఆగింది. ఆగిన చోటు నుంచే కొనసాగించవచ్చు.")
    val keepScreenOn = Say(
        "Keep this screen on while a run is going; the portal page has to " +
            "stay in front.",
        "రన్ జరిగేటప్పుడు ఈ స్క్రీన్ ఆన్‌లో ఉంచండి; పోర్టల్ పేజీ ముందే ఉండాలి.")

    // ---------------------------------------------------------- recorder
    val beginnerMode = Say("Plain words", "సులభ భాష")
    val expertMode = Say("Show selectors", "సెలెక్టర్లు చూపు")
    val steps = Say("Steps", "దశలు")
    val stepNothing = Say("Nothing recorded yet.", "ఇంకా ఏమీ రికార్డ్ కాలేదు.")
    val recording = Say("Recording - do one record by hand",
        "రికార్డ్ అవుతోంది - ఒక రికార్డు చేతితో చేయండి")
    val mapColumns = Say("Which column fills which box",
        "ఏ కాలమ్ ఏ బాక్సులో")
    val saveAsBwa = Say("Save as a recording (.bwa)",
        "రికార్డింగ్‌గా భద్రపరచు (.bwa)")
    val saveAsUiVision = Say("Also save as a UI.Vision macro",
        "UI.Vision మాక్రోగా కూడా భద్రపరచు")

    // -------------------------------------------------------- validation
    val beforeYouRun = Say("Before you run", "నడిపే ముందు")
    val dlrSheet = Say("The DLR instruction sheet", "DLR సూచనల పత్రం")
    val khataChecks = Say("Khata numbers", "ఖాతా నంబర్లు")
    val theFile = Say("The file itself", "ఫైల్")
    val mustFix = Say("Must be fixed", "సరిచేయాలి")
    val worthALook = Say("Worth a look", "చూడటం మంచిది")
    val justSoYouKnow = Say("Just so you know", "తెలియడానికి")
    val nothingWrong = Say("Nothing to settle first.",
        "ముందుగా సరిచేయాల్సినది ఏదీ లేదు.")
    val appWillNotChange = Say(
        "The app does not change an LPM, a khata or a classification by " +
            "itself. It says what it sees; you decide.",
        "LPM, ఖాతా, క్లాసిఫికేషన్ యాప్ తనంతట తానే మార్చదు. కనిపించింది " +
            "చెబుతుంది; నిర్ణయం మీది.")

    // ----------------------------------------------------------- reports
    val finalDlr = Say("Final DLR workbook", "తుది DLR వర్క్‌బుక్")
    val govtRsr = Say("Government land (RSR)", "ప్రభుత్వ భూమి (RSR)")
    val correlationReport = Say("Correlation", "కొరిలేషన్")
    val extentReport = Say("Extent variation", "విస్తీర్ణ వ్యత్యాసం")
    val missingReport = Say("Missing data", "లోపించిన డేటా")
    val duplicateReport = Say("Duplicates", "నకిలీలు")
    val errorReport = Say("Errors and review", "లోపాలు, పరిశీలన")
    val pdfReport = Say("Detailed PDF", "వివరమైన PDF")
    val jointReport = Say("Joint cultivation", "ఉమ్మడి సాగు")
    val sourceKept = Say(
        "Every report keeps the file's own value beside anything the app " +
            "worked out.",
        "యాప్ లెక్కించినది పక్కనే ఫైల్‌లోని అసలు విలువ ప్రతి నివేదికలో ఉంటుంది.")
    val exported = Say("Saved", "భద్రపరచబడింది")

    // ------------------------------------------------------------- files
    val workbooks = Say("Workbooks", "వర్క్‌బుక్‌లు")
    val recordings = Say("Recordings", "రికార్డింగ్‌లు")
    val maps = Say("Maps (KML, GeoJSON, shapefile)",
        "మ్యాప్‌లు (KML, GeoJSON, షేప్‌ఫైల్)")
    val exports = Say("Exported reports", "ఎగుమతి చేసిన నివేదికలు")
    val importWorkbook = Say("Import a DLR workbook", "DLR వర్క్‌బుక్ దిగుమతి")
    val importMacro = Say("Import a macro or recording",
        "మాక్రో లేదా రికార్డింగ్ దిగుమతి")
    val importCsv = Say("Import a CSV", "CSV దిగుమతి")
    val importMap = Say("Import a map", "మ్యాప్ దిగుమతి")
    val previewFirst = Say("What the file holds", "ఫైల్‌లో ఏముంది")
    val nothingHere = Say("Nothing here yet.", "ఇంకా ఏమీ లేదు.")
    val geometryUntouched = Say(
        "A map is read for its attributes only. No coordinate is changed.",
        "మ్యాప్ నుంచి అట్రిబ్యూట్‌లు మాత్రమే చదువుతుంది. కోఆర్డినేట్ మారదు.")

    // ---------------------------------------------------------- settings
    val language = Say("Language", "భాష")
    val english = Say("English", "English")
    val telugu = Say("Telugu", "తెలుగు")
    val theme = Say("Theme", "థీమ్")
    val themeLight = Say("Light", "లైట్")
    val themeDark = Say("Dark", "డార్క్")
    val themeSystem = Say("As the tablet is set", "టాబ్లెట్ ఎలా ఉంటే అలా")
    val decimals = Say("Extent decimals", "విస్తీర్ణ దశాంశాలు")
    val speed = Say("Pace", "వేగం")
    val speedCareful = Say("Careful", "జాగ్రత్తగా")
    val speedSteady = Say("Steady", "సాధారణం")
    val speedBrisk = Say("Brisk", "వేగంగా")
    val portalAddress = Say("Portal address", "పోర్టల్ చిరునామా")
    val pdfToAttach = Say("PDF to attach", "జత చేసే PDF")
    val deleteEverything = Say("Delete this project and its backups",
        "ఈ ప్రాజెక్టు, బ్యాకప్‌లు తొలగించు")
    val deleteWarning = Say(
        "This cannot be undone. Export anything you want to keep first.",
        "ఇది వెనక్కి రాదు. ఉంచుకోవాల్సినది ముందు ఎగుమతి చేసుకోండి.")
    val about = Say("About", "గురించి")

    // ---------------------------------------------------------- sign-in
    val signInSaved = Say("Portal sign-in", "పోర్టల్ లాగిన్")
    val username = Say("Username", "యూజర్ నేమ్")
    val password = Say("Password", "పాస్‌వర్డ్")
    val rememberSignIn = Say("Remember this sign-in", "ఈ లాగిన్ గుర్తుంచుకో")
    val rememberFromPage = Say("Remember what is typed on the page",
        "పేజీలో టైప్ చేసినది గుర్తుంచుకో")
    val fillSignIn = Say("Fill sign-in", "లాగిన్ నింపు")
    val forgetSignIn = Say("Forget it", "మరచిపో")
    val autoFill = Say("Fill it as soon as the sign-in page opens",
        "లాగిన్ పేజీ తెరిచిన వెంటనే నింపు")
    val nothingSaved = Say("Nothing is saved yet.", "ఇంకా ఏమీ భద్రపరచలేదు.")
    val signInKept = Say(
        "The password is encrypted with a key made inside this tablet's own " +
            "keystore, which never leaves it. The encrypted bytes are useless " +
            "on any other tablet.",
        "పాస్‌వర్డ్ ఈ టాబ్లెట్ కీస్టోర్‌లో తయారైన కీతో ఎన్‌క్రిప్ట్ అవుతుంది, " +
            "ఆ కీ బయటికి వెళ్ళదు. ఎన్‌క్రిప్ట్ అయిన బైట్లు వేరే టాబ్లెట్‌లో " +
            "పనికిరావు.")
    val signInWarning = Say(
        "Anybody who can unlock this tablet can press Fill sign-in and be " +
            "signed in as you. Keep a lock screen on the tablet.",
        "ఈ టాబ్లెట్ అన్‌లాక్ చేయగలిగిన ఎవరైనా లాగిన్ నింపు నొక్కి మీలా " +
            "లాగిన్ అవ్వగలరు. టాబ్లెట్‌కు లాక్ స్క్రీన్ పెట్టుకోండి.")
    val captchaYours = Say(
        "A captcha or an OTP is never filled by the app — the portal is " +
            "checking that a person is there, and you are.",
        "క్యాప్చా, OTP యాప్ నింపదు — మనిషి ఉన్నారా అని పోర్టల్ చూస్తోంది, " +
            "మీరు ఉన్నారు.")
    val signInFilled = Say("The sign-in was filled in. Press the portal's own " +
        "Login button.", "లాగిన్ నింపింది. పోర్టల్ Login బటన్ నొక్కండి.")
    val signInNoForm = Say("No sign-in form on this page.",
        "ఈ పేజీలో లాగిన్ ఫారం లేదు.")
    val ownBrowser = Say(
        "This is the app's own browser, not Chrome. The session stays signed " +
            "in across restarts.",
        "ఇది యాప్ సొంత బ్రౌజర్, Chrome కాదు. యాప్ మళ్ళీ తెరిచినా లాగిన్ " +
            "ఉండిపోతుంది.")

    // ------------------------------------------------------ portal pages
    val tahsildarAdd = Say("Tahsildar - Add Record",
        "తహసీల్దార్ - రికార్డు చేర్చు")
    val vsLogin = Say("VS login - Correlation of Spatial Data",
        "VS లాగిన్ - స్పేషియల్ డేటా కొరిలేషన్")
    val vroLogin = Say("VRO login - Ground Truthing",
        "VRO లాగిన్ - గ్రౌండ్ ట్రూతింగ్")
    val signPage = Say("Tahsildar - Digital Signature",
        "తహసీల్దార్ - డిజిటల్ సంతకం")
    val signNeverFaked = Say(
        "The app opens the page and finds the records. The signing itself " +
            "is done by the officer with the DSC, never by the app.",
        "యాప్ పేజీ తెరిచి రికార్డులు చూపుతుంది. సంతకం DSC తో అధికారే " +
            "చేయాలి, యాప్ చేయదు.")
    val landType = Say("Kind of land", "భూమి రకం")
    val landTypeFromSheet = Say("From the DLR sheet", "DLR పత్రం నుంచి")
    val landTypeOlder = Say("Older presets", "పాత ప్రీసెట్లు")
    val chainShown = Say("What goes in the boxes", "బాక్సుల్లో ఏమి పడుతుంది")

    // ------------------------------------------------------- record words
    val lpm = Say("LPM No", "LPM నంబరు")
    val extent = Say("Extent", "విస్తీర్ణం")
    val surveyNo = Say("Survey No", "సర్వే నంబరు")
    val subDiv = Say("Sub Division", "సబ్ డివిజన్")
    val khata = Say("Khata No", "ఖాతా నంబరు")
    val pattadarName = Say("Pattadar name", "పట్టాదారు పేరు")
    val relationName = Say("Father / relation", "తండ్రి / బంధుత్వం")
    val rights = Say("Rights as per ROR", "ROR ప్రకారం హక్కులు")
    val action = Say("Action requested", "కోరిన చర్య")
    val remarks = Say("Remarks", "వివరణ")
    val chaltha = Say("Chaltha No", "చల్తా నంబరు")
    val state = Say("State", "స్థితి")
    val message = Say("What happened", "ఏమి జరిగింది")
    val row = Say("Row", "వరుస")
    val original = Say("In the file", "ఫైల్‌లో")
    val asEntered = Say("As entered", "నమోదు చేసినది")
}
