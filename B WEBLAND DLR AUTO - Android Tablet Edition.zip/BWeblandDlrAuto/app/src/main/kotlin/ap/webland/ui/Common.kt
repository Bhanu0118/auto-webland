package ap.webland.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ap.webland.core.Finding
import ap.webland.core.Level
import ap.webland.core.RowState
import ap.webland.ui.theme.Entered
import ap.webland.ui.theme.Failedd
import ap.webland.ui.theme.Review
import ap.webland.ui.theme.Waiting
import ap.webland.ui.theme.tableCell

/** Which language the screens are in. Changed on the Settings page. */
val LocalTelugu = staticCompositionLocalOf { true }

@Composable
fun Say.text(): String = get(LocalTelugu.current)

/**
 * The pieces every screen is built from.
 *
 * A panel with a heading, a counter, a line of findings, a cell of a
 * table. They are here rather than repeated so that the twelve screens
 * look like one program, and so that a change to how a finding reads
 * happens once.
 */

@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    note: String = "",
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary)
            if (note.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(note, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun Counter(
    label: String,
    value: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier,
) {
    Column(modifier.padding(end = 22.dp, bottom = 10.dp)) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = tint)
        Text(label, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StateChip(state: RowState, howMany: Int? = null) {
    val tint = tintOf(state)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(10.dp)
                .background(tint, RoundedCornerShape(5.dp)))
        Spacer(Modifier.width(6.dp))
        Text(
            stateWord(state).text() + if (howMany != null) "  $howMany" else "",
            style = MaterialTheme.typography.bodySmall, color = tint)
    }
}

fun tintOf(state: RowState): Color = when (state) {
    RowState.SUCCESS -> Entered
    RowState.FAILED -> Failedd
    RowState.NEEDS_REVIEW -> Review
    else -> Waiting
}

fun stateWord(state: RowState): Say = when (state) {
    RowState.SUCCESS -> Say("Entered", "నమోదైంది")
    RowState.FAILED -> Say("Failed", "విఫలమైంది")
    RowState.NEEDS_REVIEW -> Say("Needs review", "పరిశీలించాలి")
    RowState.SKIPPED -> Say("Skipped", "వదిలేసింది")
    RowState.RUNNING -> Say("Running", "నడుస్తోంది")
    RowState.PENDING -> Say("Not attempted", "ప్రయత్నించలేదు")
}

/** One finding, with its level shown by colour as well as by a mark. */
@Composable
fun FindingRow(finding: Finding) {
    val tint = when (finding.level) {
        Level.STOP -> Failedd
        Level.WARN -> Review
        Level.NOTE -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(finding.level.mark, color = tint,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.width(26.dp))
        Column(Modifier.weight(1f)) {
            Text(finding.title, style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium)
            if (finding.detail.isNotBlank()) {
                Text(finding.detail, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (finding.rows.isNotEmpty()) {
                Text(
                    Say("rows ", "వరుసలు ").text() +
                        finding.rows.take(12).joinToString(", ") +
                        if (finding.rows.size > 12)
                            Say(" and ${finding.rows.size - 12} more",
                                " మరో ${finding.rows.size - 12}").text()
                        else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (finding.fix.isNotBlank()) {
                Text(finding.fix, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary)
            }
        }
        if (finding.rule.isNotBlank()) {
            Text(finding.rule, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(54.dp).padding(start = 8.dp))
        }
    }
}

/** A row of a table of records: fixed widths, so columns line up. */
@Composable
fun Cells(
    values: List<String>,
    widths: List<Int>,
    heading: Boolean = false,
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
) {
    val base = if (heading) MaterialTheme.colorScheme.surfaceVariant
    else Color.Transparent
    Row(
        Modifier.fillMaxWidth()
            .background(base)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        values.forEachIndexed { i, value ->
            Text(
                value,
                style = if (heading) MaterialTheme.typography.labelMedium else tableCell,
                fontWeight = if (heading) FontWeight.SemiBold else FontWeight.Normal,
                color = tint ?: MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(widths.getOrElse(i) { 100 }.dp)
                    .padding(end = 8.dp),
            )
        }
    }
}

@Composable
fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    note: String = "",
    enabled: Boolean = true,
) {
    Column(modifier.padding(end = 12.dp, bottom = 10.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(label) },
            enabled = enabled,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        if (note.isNotBlank()) {
            Text(note, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp))
        }
    }
}

/**
 * A box for a password.
 *
 * Masked, with no eye to reveal it. There is nothing useful about
 * showing a password on a tablet screen in an office, and the app never
 * needs to display one: it either has it saved or it has not.
 */
@Composable
fun PasswordField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = modifier.fillMaxWidth().padding(end = 12.dp, bottom = 10.dp),
    )
}

/** A short line of explanation, the kind that stops a wrong assumption. */
@Composable
fun Note(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
            .padding(10.dp),
    ) {
        Text(text, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Gap(height: Int = 12) = Spacer(Modifier.height(height.dp))

/**
 * Panels side by side.
 *
 * The content runs in the Row's own scope, so a panel inside it can ask
 * for `Modifier.weight(1f)` and share the width out.
 */
@Composable
fun RowOfPanels(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        content()
    }
}
