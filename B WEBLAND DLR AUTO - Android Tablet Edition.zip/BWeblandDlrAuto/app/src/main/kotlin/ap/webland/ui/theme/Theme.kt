package ap.webland.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * The look of the app: the dark blue of the office's own report
 * headings, a light paper behind the tables, and nothing that moves.
 *
 * Two things here are decisions rather than taste. The text is a size
 * larger than a phone app's throughout, because this is read at arm's
 * length on a tablet propped on a desk, often by somebody who has been
 * looking at a screen all day. And the colours that carry meaning -
 * entered, failed, needs review - are different in lightness as well as
 * in hue, so they are still told apart in sunlight and by anyone who
 * does not see red and green as different.
 */

private val Brand = Color(0xFF1F3864)
private val BrandLight = Color(0xFF33518A)
private val Paper = Color(0xFFF7F8FA)
private val Ink = Color(0xFF1B1F24)

val Entered = Color(0xFF1B6E3C)
val Failedd = Color(0xFFB3261E)
val Review = Color(0xFFB26B00)
val Waiting = Color(0xFF5B6472)

private val light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8EDF6),
    onPrimaryContainer = Brand,
    secondary = BrandLight,
    onSecondary = Color.White,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFEDF0F5),
    onSurfaceVariant = Color(0xFF414752),
    error = Failedd,
    outline = Color(0xFFBFC6D1),
)

private val dark = darkColorScheme(
    primary = Color(0xFF9EB6E0),
    onPrimary = Color(0xFF0B1B33),
    primaryContainer = Color(0xFF1B2A44),
    onPrimaryContainer = Color(0xFFD6E1F6),
    secondary = Color(0xFF8FA6CF),
    onSecondary = Color(0xFF0B1B33),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE3E6EA),
    surface = Color(0xFF171C22),
    onSurface = Color(0xFFE3E6EA),
    surfaceVariant = Color(0xFF222932),
    onSurfaceVariant = Color(0xFFC2C8D0),
    error = Color(0xFFFFB4AB),
    outline = Color(0xFF49515C),
)

private val bigger = Typography().let { base ->
    Typography(
        displaySmall = base.displaySmall.copy(fontSize = 34.sp),
        headlineMedium = base.headlineMedium.copy(fontSize = 27.sp),
        headlineSmall = base.headlineSmall.copy(fontSize = 23.sp),
        titleLarge = base.titleLarge.copy(fontSize = 21.sp, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontSize = 18.sp),
        titleSmall = base.titleSmall.copy(fontSize = 16.sp),
        bodyLarge = base.bodyLarge.copy(fontSize = 17.sp, lineHeight = 25.sp),
        bodyMedium = base.bodyMedium.copy(fontSize = 15.sp, lineHeight = 22.sp),
        bodySmall = base.bodySmall.copy(fontSize = 13.sp, lineHeight = 19.sp),
        labelLarge = base.labelLarge.copy(fontSize = 15.sp),
        labelMedium = base.labelMedium.copy(fontSize = 13.sp),
    )
}

/** The smaller, even type used for a table of records. */
val tableCell = TextStyle(fontSize = 14.sp, lineHeight = 19.sp)

@Composable
fun BWeblandTheme(
    /** "light", "dark" or anything else for whatever the tablet is set to */
    theme: String,
    content: @Composable () -> Unit,
) {
    val isDark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (isDark) dark else light,
        typography = bigger,
        content = content,
    )
}
