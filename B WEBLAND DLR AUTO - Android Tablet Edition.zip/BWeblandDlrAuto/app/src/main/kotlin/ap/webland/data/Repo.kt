package ap.webland.data

import ap.webland.core.Bind
import ap.webland.core.Columns
import ap.webland.core.Headings
import ap.webland.core.Json
import ap.webland.core.Macro
import ap.webland.core.RowResult
import ap.webland.core.Table
import ap.webland.core.UiVision
import ap.webland.core.UvMacro
import kotlinx.coroutines.flow.Flow

/**
 * The one place that writes to the database.
 *
 * Two promises are kept here rather than in the screens, so that no
 * screen can forget them.
 *
 * Nothing is overwritten without a note. Importing keeps the source row
 * as it arrived; every later change writes an audit row saying what the
 * value was, what it became, and where the change came from.
 *
 * A record that may already be in the portal is never offered for a
 * retry. `rowsToRetry` asks the database for FAILED rows only, and that
 * query is in the DAO where it can be read in one line.
 */
class Repo(private val dao: Dao0) {

    // --------------------------------------------------------- projects
    fun projects(): Flow<List<ProjectRow>> = dao.projects()
    suspend fun project(id: Long): ProjectRow? = dao.project(id)
    suspend fun newestProject(): ProjectRow? = dao.newestProject()

    /**
     * A workbook becomes a project.
     *
     * The column headings are matched to the fields the portal wants,
     * and anything that cannot be matched is simply not filled in -
     * never guessed at. The whole source row is kept as JSON beside the
     * record, which is what makes "what did the file say?" answerable
     * three months later.
     */
    suspend fun importTable(
        name: String,
        village: String,
        mandal: String,
        district: String,
        sourceFile: String,
        sourceUri: String,
        table: Table,
    ): Long {
        val projectId = dao.addProject(ProjectRow(
            name = name, village = village, mandal = mandal,
            district = district, sourceFile = sourceFile,
            sourceUri = sourceUri, sheet = table.sheetName))

        val matched = Headings.match(Columns.COMMON, table.columns)
            .filter { it.column != null }
            .associate { it.field to it.column!! }

        fun cell(row: Map<String, String>, key: String): String =
            matched[key]?.let { row[it] } ?.trim() ?: ""

        val records = table.rows.mapIndexed { i, row ->
            val asJson = Json.write(Json.map(row), 0)
            RecordRow(
                projectId = projectId,
                rowNumber = table.lineOf(i),
                lpm = cell(row, "lpm"),
                extent = cell(row, "extent"),
                surveyNo = cell(row, "syno"),
                subDivision = cell(row, "subdiv"),
                khata = cell(row, "khata"),
                pattadarName = cell(row, "name"),
                relationName = cell(row, "fname"),
                originalJson = asJson,
                currentJson = asJson)
        }
        dao.addRecords(records)
        return projectId
    }

    fun records(projectId: Long): Flow<List<RecordRow>> = dao.records(projectId)
    suspend fun recordList(projectId: Long): List<RecordRow> = dao.recordList(projectId)
    suspend fun find(projectId: Long, text: String): List<RecordRow> =
        if (text.isBlank()) dao.recordList(projectId).take(400)
        else dao.findRecords(projectId, "%${text.trim()}%")

    fun counts(projectId: Long): Flow<List<StateCount>> = dao.stateCounts(projectId)
    fun recordCount(projectId: Long): Flow<Int> = dao.recordCount(projectId)
    fun surveyCount(projectId: Long): Flow<Int> = dao.surveyCount(projectId)
    fun subDivisionCount(projectId: Long): Flow<Int> = dao.subDivisionCount(projectId)
    fun lpmCount(projectId: Long): Flow<Int> = dao.lpmCount(projectId)

    /** One field of one record, changed by a person, with the note. */
    suspend fun edit(record: RecordRow, field: String, value: String, who: String) {
        val was = when (field) {
            "lpm" -> record.lpm
            "extent" -> record.extent
            "surveyNo" -> record.surveyNo
            "subDivision" -> record.subDivision
            "khata" -> record.khata
            "pattadarName" -> record.pattadarName
            "relationName" -> record.relationName
            "presetId" -> record.presetId
            else -> return
        }
        if (was == value) return
        val updated = when (field) {
            "lpm" -> record.copy(lpm = value)
            "extent" -> record.copy(extent = value)
            "surveyNo" -> record.copy(surveyNo = value)
            "subDivision" -> record.copy(subDivision = value)
            "khata" -> record.copy(khata = value)
            "pattadarName" -> record.copy(pattadarName = value)
            "relationName" -> record.copy(relationName = value)
            else -> record.copy(presetId = value)
        }.copy(updatedAt = System.currentTimeMillis())
        dao.updateRecord(updated)
        dao.addAudit(AuditRow(
            projectId = record.projectId, recordId = record.id,
            field = field, was = was, now = value, source = "edit", who = who))
    }

    suspend fun approve(record: RecordRow, who: String) {
        dao.updateRecord(record.copy(reviewed = true, approvedBy = who,
            updatedAt = System.currentTimeMillis()))
        dao.addAudit(AuditRow(
            projectId = record.projectId, recordId = record.id,
            field = "reviewed", was = "false", now = "true",
            source = "review", who = who))
    }

    suspend fun auditOf(recordId: Long): List<AuditRow> = dao.auditOf(recordId)
    suspend fun auditOfProject(projectId: Long): List<AuditRow> =
        dao.auditOfProject(projectId)

    // ----------------------------------------------------------- macros
    fun macros(): Flow<List<MacroRow>> = dao.macros()
    suspend fun macro(id: Long): MacroRow? = dao.macro(id)
    suspend fun deleteMacro(id: Long) = dao.deleteMacro(id)

    /**
     * A file the surveyor chose, read as whichever of the two kinds it
     * turns out to be. Neither is executed to find out: a recording
     * announces itself in its first field, and a UI.Vision macro has a
     * Commands list.
     */
    suspend fun addMacro(name: String, uri: String, text: String): MacroRow {
        val looksLikeBwa = text.contains(Macro.FORMAT)
        val row = if (looksLikeBwa) {
            val auto = Macro.read(text)
            MacroRow(name = auto.name.ifBlank { name }, kind = "BWA", uri = uri,
                body = text, stepCount = auto.live().size,
                writeCount = auto.writes().size, csvName = auto.dataFile)
        } else {
            val macro = UvMacro.read(text)
            val program = UiVision.compile(macro)
            MacroRow(name = macro.name.ifBlank { name }, kind = "UIVISION",
                uri = uri, body = text, stepCount = program.steps.size,
                writeCount = program.writeCount, csvName = program.csvName)
        }
        val id = dao.addMacro(row)
        return row.copy(id = id)
    }

    // ------------------------------------------------------------- runs
    fun runs(projectId: Long): Flow<List<RunRow>> = dao.runs(projectId)
    suspend fun lastRun(projectId: Long): RunRow? = dao.lastRun(projectId)
    suspend fun unfinishedRun(projectId: Long): RunRow? = dao.unfinishedRun(projectId)

    suspend fun startRun(
        projectId: Long,
        macro: MacroRow,
        dataFile: String,
        dataUri: String,
        fromRow: Int,
        toRow: Int,
    ): RunRow {
        val row = RunRow(
            projectId = projectId, macroId = macro.id, macroName = macro.name,
            dataFile = dataFile, dataUri = dataUri, fromRow = fromRow,
            toRow = toRow, nextRow = fromRow, state = "RUNNING")
        val id = dao.addRun(row)
        return row.copy(id = id)
    }

    /**
     * After every single record: the row's outcome against the record,
     * and where the run has got to.
     *
     * Saving after each one is what lets a flat battery cost one record
     * instead of a morning.
     */
    suspend fun checkpoint(run: RunRow, result: RowResult, nextRow: Int): RunRow {
        dao.markRecord(
            projectId = run.projectId, rowNumber = result.rowNumber,
            state = result.state.name, code = result.code,
            message = result.message, stepId = result.stepId,
            seconds = result.seconds, shot = result.screenshot)
        val updated = run.copy(
            nextRow = nextRow,
            success = run.success + if (result.state.name == "SUCCESS") 1 else 0,
            failed = run.failed + if (result.state.name == "FAILED") 1 else 0,
            review = run.review + if (result.state.name == "NEEDS_REVIEW") 1 else 0,
            skipped = run.skipped + if (result.state.name == "SKIPPED") 1 else 0)
        dao.updateRun(updated)
        return updated
    }

    suspend fun endRun(run: RunRow, state: String, note: String = ""): RunRow {
        val updated = run.copy(state = state, note = note,
            finishedAt = System.currentTimeMillis())
        dao.updateRun(updated)
        dao.project(run.projectId)?.let {
            dao.updateProject(it.copy(lastRunAt = System.currentTimeMillis()))
        }
        return updated
    }

    /** FAILED rows only. Never NEEDS_REVIEW. */
    suspend fun rowsToRetry(projectId: Long): List<Int> =
        dao.retryable(projectId).map { it.rowNumber }

    suspend fun rowsNeedingReview(projectId: Long): List<RecordRow> =
        dao.needingReview(projectId)

    // ----------------------------------------------------------- delete
    /** Everything about one project, for good. Asked for, never assumed. */
    suspend fun deleteProject(projectId: Long) {
        dao.clearAudit(projectId)
        dao.clearRecords(projectId)
        dao.clearRuns(projectId)
        dao.deleteProject(projectId)
    }

    /** The source row as the file had it, for a report or a comparison. */
    fun originalRow(record: RecordRow): Map<String, String> =
        try {
            Json.parse(record.originalJson).let { parsed ->
                (parsed as? Json.Obj)?.fields?.mapValues { (_, v) ->
                    (v as? Json.Str)?.value ?: ""
                } ?: emptyMap()
            }
        } catch (e: Exception) {
            emptyMap()
        }

    /** The row as it stands, for binding into a macro's {{Column}}. */
    fun currentRow(record: RecordRow): Map<String, String> {
        val base = originalRow(record).toMutableMap()
        // whatever a person has since corrected wins over the file
        for ((key, value) in listOf(
            "LPMNo" to record.lpm, "Extent" to record.extent,
            "SyNo" to record.surveyNo, "SubDiv" to record.subDivision,
            "Khata" to record.khata, "Name" to record.pattadarName,
            "Relation" to record.relationName)) {
            val match = base.keys.firstOrNull {
                Headings.tidy(it) == Headings.tidy(key)
            }
            if (match != null && value.isNotBlank()) base[match] = value
        }
        return base
    }

    /** Which {{Column}} names a recording wants that this file has not got. */
    fun unmapped(auto: ap.webland.core.Automation, table: Table): List<String> =
        auto.variables().filter { name ->
            val column = auto.mapping[name] ?: name
            column !in table.columns && Bind.loosely(column, table.columns) == null
        }
}
