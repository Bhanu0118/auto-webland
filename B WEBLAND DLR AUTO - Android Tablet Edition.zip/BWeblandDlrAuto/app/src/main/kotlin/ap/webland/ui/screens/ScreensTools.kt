package ap.webland.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ap.webland.BWeblandApp
import ap.webland.ui.AppModel
import ap.webland.ui.Cells
import ap.webland.ui.Field
import ap.webland.ui.Gap
import ap.webland.ui.Note
import ap.webland.ui.Panel
import ap.webland.ui.PasswordField
import ap.webland.ui.Say
import ap.webland.ui.Words
import ap.webland.ui.text
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val whenShown = SimpleDateFormat("d MMM, HH:mm", Locale.UK)

/**
 * The reports.
 *
 * Every one of them keeps the file's own value beside anything the app
 * worked out, in its own column, with the heading saying which is which.
 * That is the rule the whole set is built on: a correction has to be
 * arguable three months later, and it cannot be if the original is gone.
 */
@Composable
fun ReportsScreen(model: AppModel) {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<File?>(null) }
    val saver = rememberSaver { uri ->
        pending?.let { model.copyOut(it, uri) }
    }

    Page(Words.reports.text(), Words.sourceKept.text()) {
        if (model.project == null) {
            Note(Words.noProject.text())
            return@Page
        }
        Buttons {
            Do(Words.check, { model.buildReports() })
            Maybe(Words.finalDlr, { model.exportWorkbook() },
                enabled = model.project != null)
            Maybe(Words.pdfReport, { model.exportPdf() },
                enabled = model.project != null)
        }
        Gap()
        if (model.reportSheets.isNotEmpty()) {
            Panel(Say("What is in the workbook", "వర్క్‌బుక్‌లో ఏముంది").text()) {
                Cells(
                    listOf(Say("Sheet", "షీట్").text(), Words.rows.text(), ""),
                    listOf(230, 90, 160), heading = true)
                for (sheet in model.reportSheets) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Cells(
                            listOf(sheet.name, sheet.rows.size.toString(), ""),
                            listOf(230, 90, 10))
                        Maybe(Words.export, { model.exportOne(sheet) })
                    }
                    HorizontalDivider()
                }
            }
            Gap()
        }
        Panel(Words.exports.text()) {
            if (model.exported.isEmpty()) {
                Text(Words.nothingHere.text(),
                    style = MaterialTheme.typography.bodySmall)
            }
            LazyColumn(Modifier.height(280.dp).fillMaxWidth()) {
                items(model.exported, key = { it.absolutePath }) { file ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.width(380.dp)) {
                            Text(file.name,
                                style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "${file.length() / 1024} KB   " +
                                    whenShown.format(Date(file.lastModified())),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Maybe(Say("Save to…", "ఇక్కడ భద్రపరచు…"), {
                            pending = file
                            saver.launch(file.name)
                        })
                        Maybe(Say("Share", "పంచు"), {
                            val uri = model.shareUriOf(file)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "*/*"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(
                                Intent.createChooser(send, file.name))
                        })
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

/**
 * The files: what has been brought in, and what has been written out.
 *
 * Nothing is opened that the surveyor did not pick in the system's own
 * picker, so there is no folder this app can wander into. A map file is
 * read for its attributes and its geometry is left exactly as it is.
 */
@Composable
fun FilesScreen(model: AppModel) {
    var village by remember { mutableStateOf("") }
    var mandal by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }

    val importWorkbook = rememberPicker { uri ->
        model.importWorkbook(uri, village.trim(), mandal.trim(), district.trim())
    }
    val importData = rememberPicker { model.pickData(it) }
    val importMacro = rememberPicker { model.pickMacro(it) }
    val importMap = rememberPicker { model.pickMap(it) }

    Page(Words.fileManager.text()) {
        Panel(Words.importWorkbook.text(),
            note = Say("The workbook becomes the project. Its rows are kept " +
                "exactly as they are.",
                "వర్క్‌బుక్ ప్రాజెక్టు అవుతుంది. వరుసలు ఉన్నవి ఉన్నట్టే " +
                    "ఉంటాయి.").text()) {
            Row(Modifier.fillMaxWidth()) {
                Field(Words.village.text(), village, { village = it },
                    Modifier.weight(1f))
                Field(Words.mandal.text(), mandal, { mandal = it },
                    Modifier.weight(1f))
                Field(Words.district.text(), district, { district = it },
                    Modifier.weight(1f))
            }
            Buttons {
                Do(Words.importWorkbook, { importWorkbook.launch(sheetFiles) })
                Maybe(Words.importCsv, { importData.launch(sheetFiles) })
            }
        }
        Gap()
        Panel(Words.recordings.text()) {
            Buttons { Do(Words.importMacro, { importMacro.launch(macroFiles) }) }
            Gap(6)
            if (model.macros.isEmpty()) {
                Text(Words.nothingHere.text(),
                    style = MaterialTheme.typography.bodySmall)
            }
            LazyColumn(Modifier.height(200.dp).fillMaxWidth()) {
                items(model.macros, key = { it.id }) { row ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Cells(
                            listOf(row.name, row.kind,
                                "${row.stepCount} ${Words.commands.text()}",
                                row.csvName),
                            listOf(200, 90, 120, 150))
                        Maybe(Words.delete, { model.deleteMacro(row) })
                    }
                    HorizontalDivider()
                }
            }
        }
        Gap()
        Panel(Words.maps.text(), note = Words.geometryUntouched.text()) {
            Buttons { Do(Words.importMap, { importMap.launch(mapFiles) }) }
            Gap(6)
            Text(
                if (model.parcelFile.isBlank()) Words.nothingHere.text()
                else "${model.parcelFile}: ${model.parcels.size} " +
                    Say("parcels", "పార్సెల్స్").text(),
                style = MaterialTheme.typography.bodyMedium)
            if (model.parcels.isNotEmpty()) {
                Gap(6)
                Cells(
                    listOf(Words.surveyNo.text(), Words.subDiv.text(),
                        Words.lpm.text(), Words.extent.text()),
                    listOf(110, 110, 90, 110), heading = true)
                LazyColumn(Modifier.height(170.dp).fillMaxWidth()) {
                    items(model.parcels.take(300)) { parcel ->
                        Cells(
                            listOf(parcel.surveyNo, parcel.subDivision,
                                parcel.lpm, parcel.extent),
                            listOf(110, 110, 90, 110))
                    }
                }
            }
        }
        Gap()
        Panel(Words.project.text()) {
            val project = model.project
            if (project == null) {
                Text(Words.noProject.text(),
                    style = MaterialTheme.typography.bodyMedium)
            } else {
                Text("${project.name}   ${project.sourceFile}",
                    style = MaterialTheme.typography.bodyMedium)
                Text(
                    "${model.records.size} ${Words.rows.text()}   " +
                        whenShown.format(Date(project.createdAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** How the app behaves, and the one thing on it that cannot be undone. */
@Composable
fun SettingsScreen(model: AppModel) {
    var portal by remember { mutableStateOf(model.prefs.portalUrl) }
    var officer by remember { mutableStateOf(model.prefs.officer) }
    var decimals by remember { mutableStateOf(model.prefs.decimals.toString()) }
    var confirmDelete by remember { mutableStateOf(false) }

    Page(Words.settings.text()) {
        Panel(Words.language.text()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = model.telugu,
                    onCheckedChange = { model.setTelugu(it) })
                Text(
                    if (model.telugu) Words.telugu.text() else Words.english.text(),
                    modifier = Modifier.padding(start = 10.dp))
            }
        }
        Gap()
        Panel(Words.theme.text()) {
            Buttons {
                Maybe(Words.themeLight, { model.setTheme("light") })
                Maybe(Words.themeDark, { model.setTheme("dark") })
                Maybe(Words.themeSystem, { model.setTheme("system") })
            }
            Text(model.theme, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Gap()
        Panel(Words.speed.text(),
            note = Say("The pace only changes how long a step waits. The portal " +
                "answers in its own time.",
                "వేగం అంటే ఒక దశ ఎంత సేపు ఆగుతుందో మాత్రమే. పోర్టల్ తన " +
                    "సమయంలోనే జవాబిస్తుంది.").text()) {
            Buttons {
                Maybe(Words.speedCareful, { model.prefs.speed = 0 })
                Maybe(Words.speedSteady, { model.prefs.speed = 1 })
                Maybe(Words.speedBrisk, { model.prefs.speed = 2 })
            }
        }
        Gap()
        Panel(Words.decimals.text(),
            note = Say("Zeros are added to reach this many decimals. A value " +
                "with more is entered exactly as it is - an extent is never " +
                "rounded.",
                "ఇన్ని దశాంశాలకు సున్నాలు చేరుస్తుంది. ఎక్కువ ఉంటే ఉన్నది " +
                    "ఉన్నట్టే నమోదు చేస్తుంది - విస్తీర్ణాన్ని రౌండ్ " +
                    "చేయదు.").text()) {
            Field(Words.decimals.text(), decimals, {
                decimals = it
                it.toIntOrNull()?.let { n -> model.prefs.decimals = n }
            }, Modifier.width(180.dp))
        }
        Gap()
        Panel(Words.portalAddress.text()) {
            Field(Words.portalAddress.text(), portal, {
                portal = it
                if (it.startsWith("https://") || it.startsWith("http://")) {
                    model.prefs.portalUrl = it
                }
            })
            Note(Words.ownBrowser.text())
        }
        Gap()
        Panel(Words.signInSaved.text(), note = Words.signInKept.text()) {
            Field(Words.username.text(), model.signInUser,
                { model.signInUser = it })
            PasswordField(Words.password.text(), model.signInPassword,
                { model.signInPassword = it })
            Buttons {
                Do(Words.rememberSignIn, { model.rememberSignIn() },
                    enabled = model.signInUser.isNotBlank() &&
                        model.signInPassword.isNotEmpty())
                Maybe(Words.forgetSignIn, { model.forgetSignIn() },
                    enabled = model.signInSaved)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = model.autoFillSignIn,
                    onCheckedChange = { model.setAutoFill(it) })
                Text(Words.autoFill.text(),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 10.dp))
            }
            Gap(6)
            Text(
                if (model.signInSaved)
                    "${Words.signInSaved.text()}: ${model.signInUser}  ✓"
                else Words.nothingSaved.text(),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary)
            Gap(6)
            Note(Words.signInWarning.text())
            Gap(6)
            Note(Words.captchaYours.text())
        }
        Gap()
        Panel(Say("Who is working", "ఎవరు పని చేస్తున్నారు").text(),
            note = Say("Written against every change, so a correction can be " +
                "accounted for later.",
                "ప్రతి మార్పు పక్కన రాస్తుంది, తర్వాత లెక్క చెప్పడానికి.").text()) {
            Field(Say("Name", "పేరు").text(), officer, {
                officer = it
                model.prefs.officer = it
            })
        }
        Gap()
        Panel(Words.about.text()) {
            Text("${Words.appName.text()} ${BWeblandApp.VERSION}",
                style = MaterialTheme.typography.titleSmall)
            Text(Words.edition.text(), style = MaterialTheme.typography.bodySmall)
            Gap(4)
            Text(Words.madeBy.text(), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Gap(6)
            Text(
                Say("The land-nature table, the DLR instruction checks and the " +
                    "portal's own field names are carried over from the Windows " +
                    "application, unchanged.",
                    "భూమి స్వభావ పట్టిక, DLR సూచనల తనిఖీలు, పోర్టల్ ఫీల్డ్ పేర్లు " +
                        "విండోస్ యాప్ నుంచి మార్పు లేకుండా తీసుకున్నాం.").text(),
                style = MaterialTheme.typography.bodySmall)
        }
        Gap()
        Panel(Words.deleteEverything.text()) {
            Note(Words.deleteWarning.text())
            Gap(6)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = confirmDelete,
                    onCheckedChange = { confirmDelete = it })
                Text(
                    Say("Yes, delete this project", "అవును, ఈ ప్రాజెక్టు తొలగించు")
                        .text(),
                    modifier = Modifier.padding(start = 10.dp))
            }
            Buttons {
                Do(Words.delete, { model.deleteProject() },
                    enabled = confirmDelete && model.project != null)
            }
        }
    }
}
