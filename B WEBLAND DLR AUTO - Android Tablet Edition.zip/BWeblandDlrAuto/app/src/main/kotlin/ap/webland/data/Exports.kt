package ap.webland.data

import ap.webland.core.Correlate
import ap.webland.core.DlrRecord
import ap.webland.core.DlrRules
import ap.webland.core.Extent
import ap.webland.core.Finding
import ap.webland.core.Khata
import ap.webland.core.Level
import ap.webland.core.Presets
import ap.webland.core.Reports
import ap.webland.core.RowResult
import ap.webland.core.RowState
import ap.webland.core.Sheet
import ap.webland.core.Table
import ap.webland.pdf.PdfReport
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Turning a project into the reports the office sends on.
 *
 * All eight of them are built from the same two things: the rows as the
 * file had them, and what happened to each one. Nothing is recalculated
 * from a calculation - an extent in a report is either the file's own
 * value or the padded one, in its own column, side by side, with the
 * heading saying which.
 *
 * The shape of every sheet is in the core module, where there is a test
 * for it. This file only decides which sheets go in which workbook and
 * what the files are called.
 */
class Exports(private val files: FileKit) {

    private val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.UK)
    private val shown = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.UK)

    /** What a record looks like to the rule engine. */
    private class Rec(
        override val rowNumber: Int,
        override val lpm: String,
        override val khata: String,
    ) : DlrRecord

    /** The project's rows, back in the shape a report wants. */
    fun tableOf(repo: Repo, records: List<RecordRow>): Table {
        if (records.isEmpty()) return Table(emptyList(), emptyList())
        val first = repo.currentRow(records.first())
        val columns = if (first.isNotEmpty()) first.keys.toList()
        else listOf("LPMNo", "Extent", "SyNo", "SubDiv", "Khata", "Name", "Relation")
        val rows = records.map { r ->
            val row = repo.currentRow(r)
            if (row.isNotEmpty()) columns.associateWith { row[it] ?: "" }
            else mapOf(
                "LPMNo" to r.lpm, "Extent" to r.extent, "SyNo" to r.surveyNo,
                "SubDiv" to r.subDivision, "Khata" to r.khata,
                "Name" to r.pattadarName, "Relation" to r.relationName)
        }
        return Table(columns, rows, emptyList(), "DLR", records.map { it.rowNumber })
    }

    /** Every sheet, in the order a person reads them. */
    fun sheets(
        repo: Repo,
        project: ProjectRow,
        records: List<RecordRow>,
        runs: List<RunRow>,
        decimals: Int,
        telugu: Boolean,
        parcels: List<ap.webland.core.Parcel> = emptyList(),
    ): List<Sheet> {
        val table = tableOf(repo, records)
        val extentColumn = table.columns.firstOrNull {
            ap.webland.core.Headings.tidy(it).contains("extent")
        } ?: "Extent"
        val khataColumn = table.columns.firstOrNull {
            ap.webland.core.Headings.tidy(it).contains("khata")
        } ?: "Khata"
        val natureColumn = table.columns.firstOrNull {
            ap.webland.core.Headings.tidy(it).let {
                t -> t.contains("nature") || t.contains("broad")
            }
        } ?: khataColumn

        val results = records.map { r ->
            RowResult(r.rowNumber,
                runCatching { RowState.valueOf(r.automationState) }
                    .getOrDefault(RowState.PENDING),
                r.code, r.message, r.stepId, r.seconds, r.screenshot)
        }
        val last = runs.firstOrNull()
        val out = ArrayList<Sheet>()

        out.add(Reports.runSummary(results, records.size,
            last?.let { shown.format(Date(it.startedAt)) } ?: "-",
            last?.takeIf { it.finishedAt > 0 }
                ?.let { shown.format(Date(it.finishedAt)) } ?: "-",
            project.village.ifBlank { project.name },
            last?.macroName ?: "-", last?.dataFile ?: project.sourceFile))

        out.add(Reports.finalDlr(table, extentColumn, decimals))
        out.add(Reports.governmentLand(table, khataColumn, natureColumn))
        out.add(Reports.errorsAndReview(results, telugu))
        out.add(Reports.missingData(table,
            listOfNotNull(extentColumn, khataColumn,
                table.columns.firstOrNull {
                    ap.webland.core.Headings.tidy(it).contains("lpm")
                })))
        out.add(Reports.duplicates(table, table.columns.filter {
            val t = ap.webland.core.Headings.tidy(it)
            t.contains("lpm") || t.contains("khata")
        }))
        out.add(Reports.findings("Checks", checks(records, table)))

        val extentColumns = table.columns.filter {
            ap.webland.core.Headings.tidy(it).contains("extent")
        }.associateWith { it }
        if (extentColumns.size > 1) {
            out.add(Reports.extentVariation(table, extentColumns))
        }

        if (parcels.isNotEmpty()) {
            val govtRows = records.map {
                Khata.GovtRow(it.rowNumber, it.surveyNo, it.subDivision, it.lpm)
            }
            val byRow = records.associate { it.rowNumber to it.extent }
            out.add(Reports.correlation(
                Correlate.match(govtRows, parcels, { byRow[it] ?: "" })))
        }
        return out
    }

    /** Everything the check engines say about this project. */
    fun checks(records: List<RecordRow>, table: Table): List<Finding> {
        val simple = records.map { Rec(it.rowNumber, it.lpm, it.khata) }
        val out = ArrayList<Finding>()
        out.addAll(Khata.check(simple))

        // the DLR sheet, once per kind of land actually used
        val presets = records.map { it.presetId }.filter { it.isNotBlank() }.distinct()
        for (id in presets) {
            val preset = Presets.byId(id) ?: continue
            val mine = records.filter { it.presetId == id }
                .map { Rec(it.rowNumber, it.lpm, it.khata) }
            out.addAll(DlrRules.check(preset, mine))
        }
        if (presets.isEmpty()) {
            out.add(Finding(Level.NOTE, "dlr",
                "No kind of land has been chosen for these records yet",
                "the DLR sheet's own checks run once a record says which row " +
                    "of the table it is"))
        }

        // extents that cannot be padded without changing them
        val tooPrecise = records.filter { Extent.tooPrecise(it.extent, 3) }
        if (tooPrecise.isNotEmpty()) {
            out.add(Finding(Level.WARN, "extent",
                "${tooPrecise.size} extent(s) have more than three decimals",
                "they are entered exactly as they are; the app does not round " +
                    "an extent",
                rows = tooPrecise.map { it.rowNumber }))
        }
        val zero = records.filter { Extent.isZero(it.extent) }
        if (zero.isNotEmpty()) {
            out.add(Finding(Level.WARN, "extent",
                "${zero.size} record(s) have an extent of zero",
                rows = zero.map { it.rowNumber },
                fix = "The portal will refuse these. Put the extent in first."))
        }
        val noExtent = records.filter { it.extent.isBlank() }
        if (noExtent.isNotEmpty()) {
            out.add(Finding(Level.WARN, "extent",
                "${noExtent.size} record(s) have no extent at all",
                rows = noExtent.map { it.rowNumber }))
        }
        val noSurvey = records.filter { it.surveyNo.isBlank() }
        if (noSurvey.isNotEmpty()) {
            out.add(Finding(Level.WARN, "survey",
                "${noSurvey.size} record(s) have no survey number",
                rows = noSurvey.map { it.rowNumber }))
        }
        return out
    }

    // ------------------------------------------------------- the files
    fun workbook(project: ProjectRow, sheets: List<Sheet>): File =
        files.writeWorkbook(
            "${clean(project.village.ifBlank { project.name })} DLR " +
                "${stamp.format(Date())}.xlsx", sheets)

    fun oneSheet(project: ProjectRow, sheet: Sheet): File =
        files.writeWorkbook(
            "${clean(project.village.ifBlank { project.name })} " +
                "${clean(sheet.name)} ${stamp.format(Date())}.xlsx", listOf(sheet))

    fun csv(project: ProjectRow, sheet: Sheet): File =
        files.writeCsv(
            "${clean(project.village.ifBlank { project.name })} " +
                "${clean(sheet.name)} ${stamp.format(Date())}.csv", sheet)

    fun pdf(project: ProjectRow, sheets: List<Sheet>): File {
        val name = "${clean(project.village.ifBlank { project.name })} DLR " +
            "${stamp.format(Date())}.pdf"
        val file = files.exportFile(name)
        return PdfReport.write(
            file,
            "DLR - ${project.village.ifBlank { project.name }}",
            listOfNotNull(
                project.mandal.ifBlank { null }?.let { "Mandal $it" },
                project.district.ifBlank { null }?.let { "District $it" },
                shown.format(Date())).joinToString("   "),
            sheets,
            "B Webland DLR Auto - Android Tablet Edition.  " +
                "Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.")
    }

    /** The audit trail, as its own sheet, for a question about a record. */
    fun auditSheet(rows: List<AuditRow>): Sheet = Sheet("Audit",
        listOf("When", "Record", "Field", "Was", "Became", "Where from", "Who"),
        rows.map {
            listOf(shown.format(Date(it.at)), it.recordId.toString(), it.field,
                it.was, it.now, it.source, it.who)
        })

    private fun clean(text: String): String =
        text.filter { it.isLetterOrDigit() || it == ' ' || it == '_' }
            .trim().ifBlank { "project" }
}
