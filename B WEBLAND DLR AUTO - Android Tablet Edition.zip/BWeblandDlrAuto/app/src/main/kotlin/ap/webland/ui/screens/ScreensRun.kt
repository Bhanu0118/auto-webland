package ap.webland.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ap.webland.core.Level
import ap.webland.ui.AppModel
import ap.webland.ui.Cells
import ap.webland.ui.Counter
import ap.webland.ui.Field
import ap.webland.ui.FindingRow
import ap.webland.ui.Gap
import ap.webland.ui.Note
import ap.webland.ui.Panel
import ap.webland.ui.Say
import ap.webland.ui.Screen
import ap.webland.ui.Words
import ap.webland.ui.stateWord
import ap.webland.ui.text
import ap.webland.ui.theme.Entered
import ap.webland.ui.theme.Failedd
import ap.webland.ui.theme.Review
import ap.webland.ui.tintOf

/**
 * Entering one record by hand, with the portal beside it.
 *
 * The left half is the record; the right half is the actual Webland page
 * so the surveyor can watch it being filled. The twelve dropdowns are
 * listed before anything is pressed, with the words that will go in
 * them, because a word that is right in one village is not always the
 * word another village's adangal uses - and seeing "పుంజ" before the run
 * rather than after it is the difference between one wrong record and
 * three thousand.
 */
@Composable
fun AddRecordScreen(model: AppModel) {
    FixedPage(Words.tahsildarAdd.text(), Words.landTypeFromSheet.text()) {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Panel(Words.landType.text()) {
                    LazyColumn(Modifier.height(180.dp).fillMaxWidth()) {
                        items(model.presetList, key = { it.id }) { preset ->
                            Cells(
                                listOf(preset.te, preset.en),
                                listOf(140, 230),
                                tint = if (preset.id == model.presetId)
                                    MaterialTheme.colorScheme.primary else null,
                                onClick = { model.presetId = preset.id })
                        }
                    }
                }
                Gap()
                Panel(Words.chainShown.text()) {
                    for ((box, word) in model.chain()) {
                        Cells(listOf(box, word), listOf(210, 190))
                    }
                    val sheet = model.sheetFindings()
                    if (sheet.isNotEmpty()) {
                        Gap(6)
                        HorizontalDivider()
                        Gap(6)
                        for (f in sheet) FindingRow(f)
                    }
                }
                Gap()
                Panel(Words.addRecord.text()) {
                    Row(Modifier.fillMaxWidth()) {
                        Field(Words.lpm.text(), model.newLpm,
                            { model.newLpm = it }, Modifier.weight(1f))
                        Field(Words.extent.text(), model.newExtent,
                            { model.newExtent = it }, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Field(Words.surveyNo.text(), model.newSyno,
                            { model.newSyno = it }, Modifier.weight(1f))
                        Field(Words.subDiv.text(), model.newSubdiv,
                            { model.newSubdiv = it }, Modifier.weight(1f))
                    }
                    Field(Words.khata.text(), model.newKhata,
                        { model.newKhata = it })
                    Row(Modifier.fillMaxWidth()) {
                        Field(Words.pattadarName.text(), model.newName,
                            { model.newName = it }, Modifier.weight(1f))
                        Field(Words.relationName.text(), model.newRelation,
                            { model.newRelation = it }, Modifier.weight(1f))
                    }
                    PortalBar(model)
                    Buttons {
                        Do(Words.addRecord, { model.addOneRecord() },
                            enabled = model.portalOpen && !model.running)
                    }
                    val result = model.lastResult
                    if (result != null) {
                        Gap(6)
                        Text(
                            "${Words.row.text()} ${result.rowNumber}: " +
                                stateWord(result.state).text() +
                                if (result.message.isNotBlank())
                                    " - ${result.message}" else "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = tintOf(result.state))
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                Note(Words.keepScreenOn.text())
                Gap(6)
                PortalView(model, Modifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}

/**
 * A whole file, entered row by row, with the portal in view.
 *
 * There are two ways to run. A macro or recording - including the
 * UI.Vision macros already made for this work on a laptop - or the land
 * type on each record, which builds the form from the office's own
 * table. The second needs no macro at all and handles a file holding
 * several classifications in one pass.
 *
 * Stop works at once. Pause holds between records rather than in the
 * middle of a form. "Retry the failed ones" touches only the records
 * that failed; a record that may already be in the register is never
 * entered again by the app.
 */
@Composable
fun RunScreen(model: AppModel) {
    var byLandType by remember { mutableStateOf(false) }
    val pickMacro = rememberPicker { model.pickMacro(it) }
    val pickData = rememberPicker { model.pickData(it) }

    FixedPage(Words.runAutomation.text(), Words.keepScreenOn.text()) {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Panel(Words.macro.text()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = byLandType,
                            onCheckedChange = { byLandType = it })
                        Text(
                            Say("Use the land type on each record instead of a macro",
                                "మాక్రో కాకుండా ప్రతి రికార్డు భూమి రకం వాడు").text(),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 8.dp))
                    }
                    if (!byLandType) {
                        Gap(6)
                        LazyColumn(Modifier.height(130.dp).fillMaxWidth()) {
                            items(model.macros, key = { it.id }) { row ->
                                Cells(
                                    listOf(row.name, row.kind,
                                        "${row.stepCount} ${Words.commands.text()}",
                                        row.csvName),
                                    listOf(190, 80, 110, 150),
                                    tint = if (row.id == model.macro?.id)
                                        MaterialTheme.colorScheme.primary else null,
                                    onClick = { model.macro = row })
                            }
                        }
                        Buttons {
                            Maybe(Words.importMacro, { pickMacro.launch(macroFiles) })
                            Maybe(Words.chooseFile, { pickData.launch(sheetFiles) })
                        }
                        Text(
                            "${Words.dataFile.text()}: " +
                                model.dataName.ifBlank { "-" } +
                                (model.table?.let {
                                    "   ${it.count()} ${Words.rows.text()}"
                                } ?: ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Gap()
                Panel(Words.liveProgress.text()) {
                    Row(Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = model.fromRow,
                            onValueChange = { model.fromRow = it },
                            label = { Text(Words.fromRow.text()) },
                            singleLine = true,
                            modifier = Modifier.width(140.dp).padding(end = 10.dp))
                        OutlinedTextField(
                            value = model.toRow,
                            onValueChange = { model.toRow = it },
                            label = { Text(Words.toRow.text()) },
                            singleLine = true,
                            modifier = Modifier.width(140.dp))
                    }
                    Gap(6)
                    PortalBar(model)
                    Buttons {
                        Maybe(Words.check, { model.checkNow() })
                        Maybe(Words.testOneRow, { model.testOne() },
                            enabled = !byLandType && model.portalOpen &&
                                !model.running && model.table != null)
                        Do(Words.play, {
                            if (byLandType) model.runByLandType() else model.startRun()
                        }, enabled = model.portalOpen && !model.running)
                    }
                    Buttons {
                        Maybe(if (model.paused) Words.resume else Words.pause,
                            { model.pauseRun() }, enabled = model.running)
                        Maybe(Words.stop, { model.stopRun() }, enabled = model.running)
                        Maybe(Words.retryFailed, { model.retryFailed() },
                            enabled = !model.running && model.portalOpen)
                    }
                    val run = model.run
                    if (run != null) {
                        Gap(6)
                        Row {
                            Counter(Words.completed.text(), run.success.toString(),
                                Entered)
                            Counter(Words.failedCount.text(), run.failed.toString(),
                                Failedd)
                            Counter(Words.reviewCount.text(), run.review.toString(),
                                Review)
                        }
                    }
                    val stops = model.findings.count { it.level == Level.STOP }
                    if (stops > 0) {
                        Note("$stops  ${Words.mustFix.text()} - " +
                            Words.validation.text())
                        Buttons {
                            Maybe(Words.validation,
                                { model.screen = Screen.VALIDATION })
                        }
                    }
                }
                Gap()
                Panel(Words.message.text()) {
                    LazyColumn(Modifier.height(190.dp).fillMaxWidth()) {
                        items(model.progress.reversed()) { result ->
                            Cells(
                                listOf(result.rowNumber.toString(),
                                    stateWord(result.state).text(),
                                    result.message.take(90)),
                                listOf(60, 120, 260),
                                tint = tintOf(result.state))
                        }
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                PortalView(model, Modifier.fillMaxWidth().weight(1f))
                Gap(6)
                LazyColumn(Modifier.height(110.dp).fillMaxWidth()) {
                    items(model.pageLog.reversed()) { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/**
 * Recording one record by hand, so the app can do the rest.
 *
 * What is written down is the box, not the place on the screen: the id
 * the portal gave it, the label beside it, the words on it. A password
 * is seen being typed and deliberately not kept.
 */
@Composable
fun RecorderScreen(model: AppModel) {
    FixedPage(Words.recorder.text(),
        if (model.isRecording) Words.recording.text() else "") {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Panel(Words.steps.text()) {
                    PortalBar(model)
                    Buttons {
                        if (model.isRecording) {
                            Do(Words.stop, { model.stopRecording() })
                        } else {
                            Do(Words.record, { model.startRecording() },
                                enabled = model.portalOpen)
                        }
                        Maybe(Say("New", "కొత్తది"), { model.newRecording() })
                        Maybe(Words.saveAsBwa, { model.saveRecording(false) },
                            enabled = model.steps.isNotEmpty())
                        Maybe(Words.saveAsUiVision, { model.saveRecording(true) },
                            enabled = model.steps.isNotEmpty())
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = model.beginner,
                            onCheckedChange = { model.beginner = it })
                        Text(
                            if (model.beginner) Words.beginnerMode.text()
                            else Words.expertMode.text(),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 8.dp))
                    }
                    Gap(6)
                    if (model.steps.isEmpty()) {
                        Text(Words.stepNothing.text(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    LazyColumn(Modifier.height(300.dp).fillMaxWidth()) {
                        itemsIndexed(model.steps) { index, step ->
                            Column(Modifier.fillMaxWidth()) {
                                Text(
                                    if (model.beginner) step.describe()
                                    else "${step.id}  ${step.act.key}  " +
                                        "${step.target.parts}  ${step.value}",
                                    style = MaterialTheme.typography.bodyMedium)
                                Buttons {
                                    Maybe(Say("Up", "పైకి"),
                                        { model.moveStep(step, -1) },
                                        enabled = index > 0)
                                    Maybe(Say("Down", "కిందకి"),
                                        { model.moveStep(step, 1) },
                                        enabled = index < model.steps.size - 1)
                                    Maybe(Words.delete, { model.removeStep(step) })
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
                Gap()
                Panel(Words.mapColumns.text(),
                    note = Say("A value written as {{Khata}} is filled from that " +
                        "column of the file.",
                        "{{Khata}} లా రాసిన విలువ ఫైల్‌లోని ఆ కాలమ్ నుంచి " +
                            "నిండుతుంది.").text()) {
                    val names = model.recording?.variables() ?: emptyList()
                    if (names.isEmpty()) {
                        Text(Words.nothingHere.text(),
                            style = MaterialTheme.typography.bodySmall)
                    }
                    for (name in names) {
                        var column by remember(name) {
                            mutableStateOf(model.recording?.mapping?.get(name) ?: name)
                        }
                        Field("{{$name}}", column, {
                            column = it
                            model.mapStep(name, it)
                        })
                    }
                    val table = model.table
                    if (table != null) {
                        Text(
                            "${Words.dataFile.text()}: ${model.dataName}  " +
                                table.columns.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                PortalView(model, Modifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}
