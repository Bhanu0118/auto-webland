package ap.webland.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ap.webland.core.Level
import ap.webland.core.Presets
import ap.webland.core.RowState
import ap.webland.data.RecordRow
import ap.webland.ui.AppModel
import ap.webland.ui.Cells
import ap.webland.ui.Counter
import ap.webland.ui.FindingRow
import ap.webland.ui.Field
import ap.webland.ui.Gap
import ap.webland.ui.Note
import ap.webland.ui.Panel
import ap.webland.ui.RowOfPanels
import ap.webland.ui.Say
import ap.webland.ui.Screen
import ap.webland.ui.StateChip
import ap.webland.ui.stateWord
import ap.webland.ui.Words
import ap.webland.ui.text
import ap.webland.ui.theme.Entered
import ap.webland.ui.theme.Failedd
import ap.webland.ui.theme.Review
import ap.webland.ui.theme.Waiting
import ap.webland.ui.tintOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val when12 = SimpleDateFormat("d MMM, HH:mm", Locale.UK)

/**
 * The first screen: where the project stands.
 *
 * The four counts along the top are the whole point of this page, and
 * "needs review" is one of them rather than being folded into failures.
 * A record whose save was never confirmed is not a failure - it may be
 * in the register already - and the app will not try it again. Showing
 * it as its own number is what makes that visible rather than a rule
 * buried in the code.
 */
@Composable
fun DashboardScreen(model: AppModel) {
    val project = model.project
    Page(Words.dashboard.text(), Words.tabletNote.text()) {
        if (project == null) {
            Note(Words.noProject.text())
            Gap()
            Buttons { Do(Words.fileManager, { model.screen = Screen.FILES }) }
            return@Page
        }

        RowOfPanels {
            Panel(Words.project.text(), Modifier.weight(1f)) {
                Text(project.name, style = MaterialTheme.typography.titleMedium)
                Gap(6)
                Row {
                    Counter(Words.village.text(), project.village.ifBlank { "-" })
                    Counter(Words.mandal.text(), project.mandal.ifBlank { "-" })
                    Counter(Words.district.text(), project.district.ifBlank { "-" })
                }
                Text(project.sourceFile, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Panel(Words.totalRecords.text(), Modifier.weight(1f)) {
                Row {
                    Counter(Words.totalRecords.text(), model.records.size.toString())
                    Counter(Words.totalLpms.text(), model.lpms.toString())
                    Counter(Words.surveyNumbers.text(), model.surveyNumbers.toString())
                    Counter(Words.subdivisions.text(), model.subDivisions.toString())
                }
            }
        }
        Gap()

        Panel(Words.liveProgress.text(), note = Words.reviewNeverRetried.text()) {
            Row {
                Counter(Words.completed.text(),
                    (model.counts[RowState.SUCCESS] ?: 0).toString(), Entered)
                Counter(Words.failedCount.text(),
                    (model.counts[RowState.FAILED] ?: 0).toString(), Failedd)
                Counter(Words.reviewCount.text(),
                    (model.counts[RowState.NEEDS_REVIEW] ?: 0).toString(), Review)
                Counter(Words.skippedCount.text(),
                    (model.counts[RowState.SKIPPED] ?: 0).toString(), Waiting)
                Counter(Words.pending.text(),
                    (model.counts[RowState.PENDING] ?: 0).toString(), Waiting)
            }
            val run = model.run ?: model.runs.firstOrNull()
            if (run != null) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(
                    "${Words.macro.text()}: ${run.macroName}   " +
                        "${Words.dataFile.text()}: ${run.dataFile}",
                    style = MaterialTheme.typography.bodySmall)
                Text(
                    "${Words.lastSync.text()}: ${when12.format(Date(run.startedAt))}" +
                        "   ${Words.runStatus.text()}: ${run.state}" +
                        "   ${Words.fromRow.text()} ${run.fromRow} - " +
                        "${run.toRow}, ${Say("next", "తరువాత").text()} ${run.nextRow}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (run.state == "RUNNING" || run.state == "PAUSED") {
                    Gap(6)
                    Note(Words.resumeOffer.text())
                }
            } else {
                Text(Words.nothingRunning.text(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Gap()
        Buttons {
            Do(Words.validation, { model.screen = Screen.VALIDATION })
            Maybe(Words.runAutomation, { model.screen = Screen.RUN })
            Maybe(Words.reports, { model.screen = Screen.REPORTS })
            Maybe(Words.dlrData, { model.screen = Screen.DLR_DATA })
        }
        Gap()
        Note(Words.madeBy.text())
    }
}

/**
 * The records, as a table, with one of them opened beside it.
 *
 * Editing a cell here writes an audit row: what it was, what it became,
 * and who changed it. That is why the panel on the right shows the
 * file's own value under every box - a correction is a correction, and
 * the original has to stay readable.
 */
@Composable
fun DlrDataScreen(model: AppModel) {
    var text by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf<List<RecordRow>>(emptyList()) }
    var picked by remember { mutableStateOf<RecordRow?>(null) }
    val widths = listOf(58, 86, 88, 86, 92, 110, 170, 120, 150)

    val list = if (text.isBlank()) model.records else shown

    FixedPage(Words.dlrData.text()) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    model.search(it) { found -> shown = found }
                },
                label = { Text(Words.search.text()) },
                singleLine = true,
                modifier = Modifier.width(320.dp),
            )
            Text(
                "${list.size} ${Words.rows.text()}",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 12.dp, top = 18.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Gap(10)
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(Modifier.weight(1.6f)) {
                Cells(
                    listOf(Words.row.text(), Words.lpm.text(), Words.extent.text(),
                        Words.surveyNo.text(), Words.subDiv.text(),
                        Words.khata.text(), Words.pattadarName.text(),
                        Words.landType.text(), Words.state.text()),
                    widths, heading = true)
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(list, key = { it.id }) { record ->
                        val state = runCatching {
                            RowState.valueOf(record.automationState)
                        }.getOrDefault(RowState.PENDING)
                        Cells(
                            listOf(
                                record.rowNumber.toString(), record.lpm,
                                record.extent, record.surveyNo,
                                record.subDivision, record.khata,
                                record.pattadarName,
                                Presets.byId(record.presetId)?.te ?: "-",
                                stateWord(state).text()),
                            widths,
                            tint = if (state == RowState.PENDING) null else tintOf(state),
                            onClick = { picked = record })
                        HorizontalDivider()
                    }
                }
            }
            Column(
                Modifier.weight(1f).padding(start = 14.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                val record = picked
                if (record == null) {
                    Note(Say("Tap a record to open it.",
                        "రికార్డు తెరవడానికి దానిపై నొక్కండి.").text())
                } else {
                    RecordPanel(model, record)
                }
            }
        }
    }
}

@Composable
private fun RecordPanel(model: AppModel, record: RecordRow) {
    val original = record.originalJson
    Panel("${Words.row.text()} ${record.rowNumber}") {
        Field(Words.lpm.text(), record.lpm,
            { model.editRecord(record, "lpm", it) })
        Field(Words.extent.text(), record.extent,
            { model.editRecord(record, "extent", it) },
            note = Say("three decimals; zeros are added, never rounded",
                "మూడు దశాంశాలు; సున్నాలు చేరుస్తుంది, రౌండ్ చేయదు").text())
        Field(Words.surveyNo.text(), record.surveyNo,
            { model.editRecord(record, "surveyNo", it) })
        Field(Words.subDiv.text(), record.subDivision,
            { model.editRecord(record, "subDivision", it) })
        Field(Words.khata.text(), record.khata,
            { model.editRecord(record, "khata", it) },
            note = if (ap.webland.core.Khata.isNotional(record.khata))
                Say("this is a notional khata", "ఇది నోషనల్ ఖాతా").text()
            else if (ap.webland.core.Khata.isGovernment(record.khata))
                Say("a government khata", "ప్రభుత్వ ఖాతా").text() else "")
        Field(Words.pattadarName.text(), record.pattadarName,
            { model.editRecord(record, "pattadarName", it) })
        Field(Words.relationName.text(), record.relationName,
            { model.editRecord(record, "relationName", it) })

        Gap(6)
        Text(Words.landType.text(), style = MaterialTheme.typography.titleSmall)
        LazyColumn(Modifier.height(170.dp).fillMaxWidth()) {
            items(model.presetList, key = { it.id }) { preset ->
                Cells(
                    listOf(preset.te, preset.en),
                    listOf(150, 210),
                    tint = if (preset.id == record.presetId)
                        MaterialTheme.colorScheme.primary else null,
                    onClick = { model.setPreset(record, preset.id) })
            }
        }

        Gap(8)
        val state = runCatching { RowState.valueOf(record.automationState) }
            .getOrDefault(RowState.PENDING)
        StateChip(state)
        if (record.message.isNotBlank()) {
            Text(record.message, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (record.code.isNotBlank()) {
            val fault = ap.webland.core.Codes.ALL[record.code]
            if (fault != null) {
                Gap(4)
                Text(fault.human(model.telugu),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary)
            }
        }
        if (state == RowState.NEEDS_REVIEW && !record.reviewed) {
            Gap(6)
            Buttons { Do(Words.approve, { model.approve(record) }) }
        }
        Gap(6)
        Text("${Words.original.text()}: $original",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/**
 * Everything the app can say before anything is entered.
 *
 * The three levels are kept apart on purpose. A STOP means the run would
 * go ahead and put something wrong in the register, so it is not allowed
 * to start. A WARN would fail visibly, which is its own report. A NOTE
 * is worth knowing and nothing more.
 */
@Composable
fun ValidationScreen(model: AppModel) {
    val stops = model.findings.filter { it.level == Level.STOP }
    val warns = model.findings.filter { it.level == Level.WARN }
    val notes = model.findings.filter { it.level == Level.NOTE }
    Page(Words.beforeYouRun.text(), model.checkSummary) {
        Buttons {
            Do(Words.check, { model.checkNow() })
            Maybe(Words.runAutomation, { model.screen = Screen.RUN })
        }
        Gap()
        Note(Words.appWillNotChange.text())
        Gap()
        if (model.findings.isEmpty()) {
            Text(Words.nothingWrong.text(),
                style = MaterialTheme.typography.bodyMedium)
        }
        if (stops.isNotEmpty()) {
            Panel("${Words.mustFix.text()} (${stops.size})") {
                for (f in stops) FindingRow(f)
            }
            Gap()
        }
        if (warns.isNotEmpty()) {
            Panel("${Words.worthALook.text()} (${warns.size})") {
                for (f in warns) FindingRow(f)
            }
            Gap()
        }
        if (notes.isNotEmpty()) {
            Panel("${Words.justSoYouKnow.text()} (${notes.size})") {
                for (f in notes) FindingRow(f)
            }
        }
    }
}
