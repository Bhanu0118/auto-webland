package ap.webland.ui

import android.net.Uri
import android.webkit.WebView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ap.webland.BWeblandApp
import ap.webland.core.Automation
import ap.webland.core.Finding
import ap.webland.core.Level
import ap.webland.core.Macro
import ap.webland.core.Presets
import ap.webland.core.RowResult
import ap.webland.core.RowState
import ap.webland.core.Sheet
import ap.webland.core.Step
import ap.webland.core.Table
import ap.webland.core.UiVision
import ap.webland.data.MacroRow
import ap.webland.data.ProjectRow
import ap.webland.data.RecordRow
import ap.webland.data.RunRow
import ap.webland.web.AutomationRunner
import ap.webland.web.PortalPage
import ap.webland.web.Recorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** The twelve places the app can be. */
enum class Screen(val title: Say) {
    DASHBOARD(Words.dashboard),
    DLR_DATA(Words.dlrData),
    ADD_RECORD(Words.addRecord),
    VS(Words.vsCorrelation),
    VRO(Words.vroGroundTruth),
    SIGN(Words.digitalSign),
    RECORDER(Words.recorder),
    RUN(Words.runAutomation),
    VALIDATION(Words.validation),
    REPORTS(Words.reports),
    FILES(Words.fileManager),
    SETTINGS(Words.settings),
}

/**
 * What the screens are looking at, and everything they can ask for.
 *
 * Every long job runs in `viewModelScope` and reports back by setting
 * state, so a screen never waits. The three that touch the portal - test
 * one record, run a range, retry the failed ones - go through
 * `AutomationRunner`, which is the only thing allowed to press Add.
 */
class AppModel(private val app: BWeblandApp) : ViewModel() {

    private val repo = app.repo
    private val files = app.files
    private val exports = app.exports
    val prefs = app.prefs

    // ------------------------------------------------------------ where
    var screen by mutableStateOf(Screen.DASHBOARD)
    var telugu by mutableStateOf(prefs.telugu)
    var theme by mutableStateOf(prefs.theme)
    var busy by mutableStateOf(false)
        private set
    var said by mutableStateOf("")
        private set

    // ----------------------------------------------------------- what of
    var project by mutableStateOf<ProjectRow?>(null)
        private set
    var records = mutableStateListOf<RecordRow>()
        private set
    var macros = mutableStateListOf<MacroRow>()
        private set
    var runs = mutableStateListOf<RunRow>()
        private set

    var counts by mutableStateOf(mapOf<RowState, Int>())
        private set
    var surveyNumbers by mutableStateOf(0)
        private set
    var subDivisions by mutableStateOf(0)
        private set
    var lpms by mutableStateOf(0)
        private set

    // --------------------------------------------------------- the macro
    var macro by mutableStateOf<MacroRow?>(null)
    var dataName by mutableStateOf("")
        private set
    private var dataUri: String = ""
    var table by mutableStateOf<Table?>(null)
        private set
    var findings = mutableStateListOf<Finding>()
        private set
    var checkSummary by mutableStateOf("")
        private set

    // ------------------------------------------------------------ a run
    var run by mutableStateOf<RunRow?>(null)
        private set
    var fromRow by mutableStateOf("2")
    var toRow by mutableStateOf("2")
    var lastResult by mutableStateOf<RowResult?>(null)
        private set
    var running by mutableStateOf(false)
        private set
    var password by mutableStateOf("")
    val progress = mutableStateListOf<RowResult>()

    // ------------------------------------------------------- the portal
    /** The activity owns it; the screens borrow it to show the portal. */
    var webView: WebView? = null
        private set
    private var web: WebView? = null
    var page by mutableStateOf<PortalPage?>(null)
        private set
    private var runner: AutomationRunner? = null
    private var recorderBridge: Recorder? = null
    var portalOpen by mutableStateOf(false)
        private set
    var pageLog = mutableStateListOf<String>()
        private set

    // ------------------------------------------------------ a recording
    var recording by mutableStateOf<Automation?>(null)
        private set
    var isRecording by mutableStateOf(false)
        private set
    var steps = mutableStateListOf<Step>()
        private set
    var beginner by mutableStateOf(true)

    // --------------------------------------------------------- the files
    var exported = mutableStateListOf<File>()
        private set
    var reportSheets = mutableStateListOf<Sheet>()
        private set
    var parcels = mutableStateListOf<ap.webland.core.Parcel>()
        private set
    var parcelFile by mutableStateOf("")
        private set

    // ------------------------------------------------------------ set-up
    init {
        viewModelScope.launch {
            val chosen = prefs.projectId.takeIf { it != 0L }
                ?.let { repo.project(it) } ?: repo.newestProject()
            chosen?.let { use(it) }
            watchMacros()
        }
        exported.addAll(files.exported())
    }

    /** The WebView belongs to the activity; the model only borrows it. */
    fun attach(view: WebView) {
        if (web === view && page != null) return
        web = view
        webView = view
        val portal = PortalPage(view)
        portal.shotFolder = files.shotDir()
        portal.prepare(desktopPage = true) { url ->
            portalOpen = url.startsWith("http")
            recorderBridge?.inject()
            pageLog.clear()
            pageLog.addAll(portal.log.takeLast(200))
            portal.keepSession()
            autoFillIfWanted()
        }
        page = portal
        runner = AutomationRunner(repo, portal, prefs)
        recorderBridge = Recorder(view) { step -> onRecorded(step) }
    }

    fun openPortal() {
        page?.load(prefs.portalUrl)
        say(Words.signIn.get(telugu))
    }

    fun refreshLog() {
        page?.let {
            pageLog.clear()
            pageLog.addAll(it.log.takeLast(200))
        }
        portalOpen = page?.isOpen() ?: false
    }

    // ------------------------------------------------------- the project
    private suspend fun use(row: ProjectRow) {
        project = row
        prefs.projectId = row.id
        reload()
    }

    fun reload() {
        val id = project?.id ?: return
        viewModelScope.launch {
            records.clear()
            records.addAll(repo.recordList(id))
            counts = records.groupingBy {
                runCatching { RowState.valueOf(it.automationState) }
                    .getOrDefault(RowState.PENDING)
            }.eachCount()
            surveyNumbers = records.map { it.surveyNo }.filter { it.isNotBlank() }
                .distinct().size
            subDivisions = records.map { it.subDivision }.filter { it.isNotBlank() }
                .distinct().size
            lpms = records.map { it.lpm }.filter { it.isNotBlank() }.distinct().size
            runs.clear()
            repo.lastRun(id)?.let { runs.add(it) }
            run = repo.unfinishedRun(id)
            if (records.isNotEmpty()) {
                fromRow = records.first().rowNumber.toString()
                toRow = records.last().rowNumber.toString()
            }
        }
    }

    private fun watchMacros() {
        viewModelScope.launch {
            repo.macros().collect { list ->
                macros.clear()
                macros.addAll(list)
                if (macro == null) macro = list.firstOrNull()
            }
        }
    }

    fun pickProject(row: ProjectRow) {
        viewModelScope.launch { use(row) }
    }

    /** A workbook or CSV the surveyor chose becomes the project. */
    fun importWorkbook(uri: Uri, village: String, mandal: String, district: String) {
        work {
            files.remember(uri)
            val name = files.nameOf(uri)
            val read = withContext(Dispatchers.IO) { files.table(uri) }
            if (read.count() == 0) {
                say("\"$name\" has no rows in it.")
                return@work
            }
            val id = repo.importTable(
                name = village.ifBlank { name.substringBeforeLast('.') },
                village = village, mandal = mandal, district = district,
                sourceFile = name, sourceUri = uri.toString(), table = read)
            repo.project(id)?.let { use(it) }
            table = read
            dataName = name
            say("$name: ${read.count()} ${Words.rows.get(telugu)}, " +
                "${read.columns.size} columns")
        }
    }

    /** A CSV or workbook for a macro to read, without making a project. */
    fun pickData(uri: Uri) {
        work {
            files.remember(uri)
            val name = files.nameOf(uri)
            val read = withContext(Dispatchers.IO) { files.table(uri) }
            table = read
            dataName = name
            dataUri = uri.toString()
            if (read.count() > 0) {
                fromRow = read.lineOf(0).toString()
                toRow = read.lineOf(read.count() - 1).toString()
            }
            say("$name: ${read.count()} ${Words.rows.get(telugu)}")
            checkNow()
        }
    }

    fun pickMacro(uri: Uri) {
        work {
            files.remember(uri)
            val name = files.nameOf(uri)
            val body = withContext(Dispatchers.IO) { files.text(uri) }
            val row = repo.addMacro(name, uri.toString(), body)
            macro = row
            say("$name: ${row.stepCount} ${Words.commands.get(telugu)}")
            checkNow()
        }
    }

    fun pickMap(uri: Uri) {
        work {
            files.remember(uri)
            val name = files.nameOf(uri)
            val found = withContext(Dispatchers.IO) {
                when (files.kindOf(name)) {
                    ap.webland.data.FileKit.Kind.KML ->
                        ap.webland.core.Kml.read(files.text(uri))
                    ap.webland.data.FileKit.Kind.GEOJSON ->
                        ap.webland.core.GeoJson.read(files.text(uri))
                    ap.webland.data.FileKit.Kind.ZIP -> {
                        val kml = files.kmlInZip(uri)
                        if (kml != null) ap.webland.core.Kml.read(kml.second)
                        else files.dbfInZip(uri)?.let { (_, bytes) ->
                            ap.webland.core.Dbf.read(bytes).rows.map {
                                ap.webland.core.Parcel("", it)
                            }
                        } ?: emptyList()
                    }
                    else -> emptyList()
                }
            }
            parcels.clear()
            parcels.addAll(found)
            parcelFile = name
            say(if (found.isEmpty())
                "Nothing in \"$name\" could be read as parcels."
            else "$name: ${found.size} parcels read. No coordinate was changed.")
        }
    }

    fun deleteMacro(row: MacroRow) {
        work {
            repo.deleteMacro(row.id)
            if (macro?.id == row.id) macro = null
        }
    }

    // --------------------------------------------------------- the checks
    fun checkNow() {
        val chosen = macro
        work {
            findings.clear()
            if (chosen == null) {
                findings.add(Finding(Level.STOP, "macro",
                    "No macro or recording has been chosen",
                    fix = "Choose one on the Run page."))
            } else {
                findings.addAll(runner?.check(chosen, table) ?: emptyList())
            }
            val id = project?.id
            if (id != null) {
                val rows = repo.recordList(id)
                findings.addAll(exports.checks(rows, exports.tableOf(repo, rows)))
            }
            checkSummary = ap.webland.core.Validate.summary(findings)
        }
    }

    val mayRun: Boolean
        get() = findings.none { it.level == Level.STOP } && macro != null &&
            table != null && portalOpen

    // ------------------------------------------------------------- doing
    fun testOne() {
        val chosen = macro ?: return
        val data = table ?: return
        val at = (fromRow.toIntOrNull() ?: 2).let { line ->
            (0 until data.count()).firstOrNull { data.lineOf(it) == line } ?: 0
        }
        work {
            running = true
            val result = runner?.testOne(chosen, data, at, runPassword())
            lastResult = result
            running = false
            result?.let {
                progress.add(it)
                say("${Words.row.get(telugu)} ${it.rowNumber}: " +
                    stateWord(it.state).get(telugu) +
                    if (it.message.isNotBlank()) " - ${it.message}" else "")
            }
            refreshLog()
        }
    }

    fun startRun() {
        val chosen = macro ?: return
        val data = table ?: return
        val id = project?.id ?: return
        val first = fromRow.toIntOrNull() ?: return
        val last = toRow.toIntOrNull() ?: return
        val firstIndex = (0 until data.count())
            .firstOrNull { data.lineOf(it) >= first }?.plus(1) ?: 1
        val lastIndex = (0 until data.count())
            .lastOrNull { data.lineOf(it) <= last }?.plus(1) ?: data.count()
        work {
            progress.clear()
            running = true
            val started = repo.startRun(id, chosen, dataName, dataUri, first, last)
            run = started
            val ended = runner?.runRange(started, chosen, data, firstIndex,
                lastIndex, runPassword()) { result, current ->
                progress.add(result)
                lastResult = result
                run = current
                true
            }
            run = ended
            running = false
            reload()
            refreshLog()
            say(Words.runFinished.get(telugu))
        }
    }

    fun retryFailed() {
        val chosen = macro ?: return
        val data = table ?: return
        val current = run ?: runs.firstOrNull() ?: return
        work {
            running = true
            val ended = runner?.retryFailed(current, chosen, data, runPassword()) {
                result, now ->
                progress.add(result)
                lastResult = result
                run = now
                true
            }
            run = ended
            running = false
            reload()
        }
    }

    fun stopRun() {
        runner?.stop()
        running = false
    }

    fun pauseRun() {
        runner?.let { if (it.paused) it.unpause() else it.pause() }
    }

    val paused: Boolean get() = runner?.paused ?: false

    // --------------------------------------------------------- recording
    fun startRecording() {
        val auto = recording ?: Automation("Recording ${runs.size + 1}").also {
            recording = it
        }
        auto.startUrl = prefs.portalUrl
        steps.clear()
        steps.addAll(auto.steps)
        isRecording = true
        recorderBridge?.start()
        say(Words.recording.get(telugu))
    }

    fun stopRecording() {
        isRecording = false
        recorderBridge?.stop()
    }

    private fun onRecorded(step: Step) {
        val auto = recording ?: Automation("Recording").also { recording = it }
        auto.add(step)
        steps.clear()
        steps.addAll(auto.steps)
    }

    fun newRecording() {
        recording = Automation("Recording")
        steps.clear()
    }

    fun removeStep(step: Step) {
        recording?.remove(step.id)
        steps.clear()
        steps.addAll(recording?.steps ?: emptyList())
    }

    fun moveStep(step: Step, by: Int) {
        recording?.move(step.id, by)
        steps.clear()
        steps.addAll(recording?.steps ?: emptyList())
    }

    fun mapStep(name: String, column: String) {
        recording?.mapping?.put(name, column)
    }

    fun saveRecording(alsoUiVision: Boolean) {
        val auto = recording ?: return
        work {
            auto.appVersion = BWeblandApp.VERSION
            auto.createdAt = java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", java.util.Locale.UK).format(java.util.Date())
            auto.dataFile = dataName
            val name = Macro.safeName(auto.name)
            val bwa = files.writeText("$name${Macro.EXT}", auto.write())
            repo.addMacro(auto.name, bwa.absolutePath, auto.write())
            var note = bwa.name
            if (alsoUiVision) {
                val uv = UiVision.fromAutomation(auto, dataName)
                val json = files.writeText("$name.json", uv.write())
                note += " + " + json.name
            }
            exported.clear()
            exported.addAll(files.exported())
            say("${Words.exported.get(telugu)}: $note")
        }
    }

    // ----------------------------------------------------------- reports
    fun buildReports() {
        val row = project ?: return
        work {
            val rows = repo.recordList(row.id)
            val sheets = exports.sheets(repo, row, rows, runs, prefs.decimals,
                telugu, parcels.toList())
            reportSheets.clear()
            reportSheets.addAll(sheets)
            say("${sheets.size} sheets ready")
        }
    }

    fun exportWorkbook() {
        val row = project ?: return
        work {
            if (reportSheets.isEmpty()) {
                val rows = repo.recordList(row.id)
                reportSheets.addAll(exports.sheets(repo, row, rows, runs,
                    prefs.decimals, telugu, parcels.toList()))
            }
            val file = withContext(Dispatchers.IO) {
                exports.workbook(row, reportSheets.toList())
            }
            exported.clear()
            exported.addAll(files.exported())
            say("${Words.exported.get(telugu)}: ${file.name}")
        }
    }

    fun exportOne(sheet: Sheet) {
        val row = project ?: return
        work {
            val file = withContext(Dispatchers.IO) { exports.oneSheet(row, sheet) }
            exported.clear()
            exported.addAll(files.exported())
            say("${Words.exported.get(telugu)}: ${file.name}")
        }
    }

    fun exportPdf() {
        val row = project ?: return
        work {
            if (reportSheets.isEmpty()) {
                val rows = repo.recordList(row.id)
                reportSheets.addAll(exports.sheets(repo, row, rows, runs,
                    prefs.decimals, telugu, parcels.toList()))
            }
            val file = withContext(Dispatchers.IO) {
                exports.pdf(row, reportSheets.toList())
            }
            exported.clear()
            exported.addAll(files.exported())
            say("${Words.exported.get(telugu)}: ${file.name}")
        }
    }

    fun copyOut(file: File, target: Uri) {
        work {
            withContext(Dispatchers.IO) { files.copyTo(target, file) }
            say("${Words.exported.get(telugu)}: ${files.nameOf(target)}")
        }
    }

    fun shareUriOf(file: File): Uri = files.shareUri(file)

    // ---------------------------------------------------------- records
    fun editRecord(record: RecordRow, field: String, value: String) {
        work {
            repo.edit(record, field, value, prefs.officer)
            reload()
        }
    }

    fun approve(record: RecordRow) {
        work {
            repo.approve(record, prefs.officer)
            reload()
        }
    }

    fun setPreset(record: RecordRow, presetId: String) {
        work {
            repo.edit(record, "presetId", presetId, prefs.officer)
            reload()
        }
    }

    suspend fun auditOf(record: RecordRow) = repo.auditOf(record.id)

    fun search(text: String, into: (List<RecordRow>) -> Unit) {
        val id = project?.id ?: return
        viewModelScope.launch { into(repo.find(id, text)) }
    }

    fun deleteProject() {
        val row = project ?: return
        work {
            repo.deleteProject(row.id)
            project = null
            records.clear()
            prefs.projectId = 0
            say("Deleted.")
        }
    }

    // --------------------------------------------------------- settings
    fun setTelugu(value: Boolean) {
        telugu = value
        prefs.telugu = value
    }

    fun setTheme(value: String) {
        theme = value
        prefs.theme = value
    }

    // ----------------------------------------------------- the sign-in
    private val vault = app.secret

    var signInSaved by mutableStateOf(app.secret.saved)
        private set
    var signInUser by mutableStateOf(app.secret.username())
    /** only what is being typed on the Settings page; never kept here */
    var signInPassword by mutableStateOf("")
    var autoFillSignIn by mutableStateOf(prefs.autoFillSignIn)
        private set

    fun setAutoFill(value: Boolean) {
        autoFillSignIn = value
        prefs.autoFillSignIn = value
    }

    /** Keep what was typed on the Settings page. */
    fun rememberSignIn() {
        val user = signInUser.trim()
        val pass = signInPassword
        if (user.isBlank() || pass.isEmpty()) {
            say(Words.nothingSaved.get(telugu))
            return
        }
        val kept = vault.remember(user, pass)
        signInSaved = vault.saved
        signInPassword = ""                 // not held in memory either
        say(if (kept) Words.signInSaved.get(telugu) + " ✓"
        else "This tablet's keystore would not keep it, so nothing was saved.")
    }

    /**
     * Keep what is in the portal's own sign-in boxes.
     *
     * This is the "after login" case: sign in by hand once, tap this,
     * and the app has it for next time. Reading the page's password box
     * happens only here, only on this tap, and the value goes straight
     * into the keystore-backed vault.
     */
    fun rememberFromPage() {
        val portal = page ?: return
        work {
            val found = withContext(Dispatchers.Default) { portal.readSignIn() }
            if (found == null) {
                say(Words.signInNoForm.get(telugu))
                return@work
            }
            val kept = vault.remember(found.first, found.second)
            signInSaved = vault.saved
            signInUser = vault.username()
            say(if (kept) Words.signInSaved.get(telugu) + " ✓"
            else "This tablet's keystore would not keep it, so nothing was saved.")
        }
    }

    /** Put the saved sign-in into the page the portal is showing. */
    fun fillSignIn() {
        val portal = page ?: return
        val held = vault.signIn()
        if (held == null) {
            say(Words.nothingSaved.get(telugu))
            return
        }
        work {
            val result = withContext(Dispatchers.Default) {
                portal.fillSignIn(held.username, held.password)
            }
            say(when (result) {
                ap.webland.web.PortalPage.SignInResult.FILLED ->
                    Words.signInFilled.get(telugu)
                ap.webland.web.PortalPage.SignInResult.PASSWORD_ONLY ->
                    Words.signInFilled.get(telugu) + " (" +
                        Words.username.get(telugu) + "?)"
                else -> Words.signInNoForm.get(telugu)
            })
            refreshLog()
        }
    }

    fun forgetSignIn() {
        vault.forget()
        signInSaved = false
        signInUser = ""
        signInPassword = ""
        say(Words.forgetSignIn.get(telugu) + " ✓")
    }

    /**
     * The password a run uses for a recorded sign-in step: what was
     * typed on the Run page, or the saved one if there is nothing typed.
     */
    private fun runPassword(): String =
        password.ifBlank { vault.signIn()?.password ?: "" }

    /** Called when a page finishes loading. Never on the main thread. */
    private fun autoFillIfWanted() {
        val portal = page ?: return
        if (!autoFillSignIn || !vault.saved) return
        val held = vault.signIn() ?: return
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                if (portal.isSignInPage()) {
                    portal.fillSignIn(held.username, held.password)
                }
            }
            refreshLog()
        }
    }

    /** Write the session cookies down so a restart is still signed in. */
    fun keepSession() {
        page?.keepSession()
    }

    // ------------------------------------- reading the page as it stands
    var pageValues by mutableStateOf(mapOf<String, String>())
        private set

    /**
     * What the portal's own boxes hold right now.
     *
     * Nothing is typed. This is for comparing the page against the
     * register - the VS and VRO screens both do it - and for showing the
     * surveyor that the app is looking at the page they think it is.
     */
    fun readPage(which: String) {
        val portal = page ?: return
        val map = when (which) {
            "VS" -> ap.webland.core.PortalFields.VS
            "VRO" -> ap.webland.core.PortalFields.VRO
            "SIGN" -> ap.webland.core.PortalFields.SIGN
            else -> ap.webland.core.PortalFields.ADD
        }
        work {
            val read = withContext(Dispatchers.Default) {
                map.entries.associate { (key, id) ->
                    key to portal.readBack(ap.webland.core.Selector("id", id))
                }
            }
            pageValues = read
            val filled = read.count { it.value.isNotBlank() }
            say("$filled of ${read.size} boxes on that page hold something")
            refreshLog()
        }
    }

    // ------------------------------------------------- one record by hand
    var presetId by mutableStateOf("dry")
    var newLpm by mutableStateOf("")
    var newExtent by mutableStateOf("")
    var newSyno by mutableStateOf("")
    var newSubdiv by mutableStateOf("")
    var newKhata by mutableStateOf("")
    var newName by mutableStateOf("")
    var newRelation by mutableStateOf("")

    val preset: ap.webland.core.LandPreset?
        get() = Presets.byId(presetId)

    /** What the twelve boxes will say, before anything is entered. */
    fun chain(): List<Pair<String, String>> =
        preset?.let { ap.webland.core.AddFlow.chain(it) } ?: emptyList()

    /** What the DLR sheet says about this kind of land. */
    fun sheetFindings(): List<Finding> =
        preset?.let { ap.webland.core.DlrRules.check(it, emptyList()) } ?: emptyList()

    /**
     * Enter the one record typed on the screen.
     *
     * The form is built from the land-nature table, so the twelve
     * dropdowns carry that row's own words. Only the numbers and the
     * name come from what was typed.
     */
    fun addOneRecord() {
        val chosen = preset ?: return
        work {
            running = true
            val auto = ap.webland.core.AddFlow.build(chosen,
                pdfPath = prefs.pdfUri)
            val one = ap.webland.core.AddFlow.oneRow(newLpm, newExtent, newSyno,
                newSubdiv, newKhata, newName, newRelation)
            val result = runner?.testFlow(auto, one, 0, runPassword())
            lastResult = result
            running = false
            result?.let {
                progress.add(it)
                say("${Words.lpm.get(telugu)} $newLpm: " +
                    stateWord(it.state).get(telugu) +
                    if (it.message.isNotBlank()) " - ${it.message}" else "")
            }
            refreshLog()
        }
    }

    /**
     * The whole project, each record through the chain for its own kind
     * of land. No macro needed, and no classification mixed up with
     * another.
     */
    fun runByLandType() {
        val id = project?.id ?: return
        val first = fromRow.toIntOrNull() ?: 0
        val last = toRow.toIntOrNull() ?: Int.MAX_VALUE
        work {
            val rows = repo.recordList(id)
                .filter { it.rowNumber in first..last }
            if (rows.isEmpty()) {
                say("No records in that range.")
                return@work
            }
            val missing = rows.count { Presets.byId(it.presetId) == null }
            if (missing == rows.size) {
                say("None of these records says what kind of land it is. " +
                    "Set it on the DLR Data page first.")
                return@work
            }
            progress.clear()
            running = true
            val started = repo.startRun(id,
                MacroRow(id = 0, name = "By land type", kind = "FLOW"),
                dataName.ifBlank { project?.sourceFile ?: "" }, dataUri,
                rows.first().rowNumber, rows.last().rowNumber)
            run = started
            val ended = runner?.runRecords(started, rows, prefs.pdfUri) {
                result, now ->
                progress.add(result)
                lastResult = result
                run = now
                true
            }
            run = ended
            running = false
            reload()
            refreshLog()
            say(Words.runFinished.get(telugu) +
                if (missing > 0) "  ($missing without a land type)" else "")
        }
    }

    fun suggestedKhatas(howMany: Int): List<String> =
        ap.webland.core.Khata.nextNumbers(records.map { it.khata }, howMany)

    val presetList = Presets.ALL

    // ------------------------------------------------------------ plumbing
    private fun work(body: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                body()
            } catch (e: Exception) {
                say((e.message ?: e.toString()).take(240))
            } finally {
                busy = false
            }
        }
    }

    private fun say(line: String) {
        said = line
    }

    fun clearSaid() {
        said = ""
    }
}
