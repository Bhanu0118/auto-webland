package ap.webland.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ap.webland.core.AddFlow
import ap.webland.core.Correlate
import ap.webland.core.Khata
import ap.webland.core.Presets
import ap.webland.core.RowState
import ap.webland.data.RecordRow
import ap.webland.ui.AppModel
import ap.webland.ui.Cells
import ap.webland.ui.FindingRow
import ap.webland.ui.Gap
import ap.webland.ui.Note
import ap.webland.ui.Panel
import ap.webland.ui.Say
import ap.webland.ui.Words
import ap.webland.ui.stateWord
import ap.webland.ui.text
import ap.webland.ui.theme.Entered
import ap.webland.ui.theme.Failedd
import ap.webland.ui.tintOf

/**
 * VS login - Correlation of Spatial Data.
 *
 * What the app does here is read, compare and report. It shows the
 * survey number and chaltha the page is on, what the register says for
 * that plot, and - when a KML or shapefile has been opened on the Files
 * page - what the map says. Where the three disagree it says so and
 * leaves it in the review list.
 *
 * The geometry in the map file is never touched. Attributes are read;
 * not one coordinate is read back out, changed or written, because a
 * boundary nudged to tidy an attribute creates an overlap that nobody
 * finds until two farmers disagree.
 */
@Composable
fun VsScreen(model: AppModel) {
    var picked by remember { mutableStateOf<RecordRow?>(null) }
    FixedPage(Words.vsLogin.text(), Words.geometryUntouched.text()) {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Panel(Words.vsCorrelation.text()) {
                    PortalBar(model)
                    Buttons {
                        Do(Say("Read the page", "పేజీ చదువు"),
                            { model.readPage("VS") }, enabled = model.portalOpen)
                    }
                    Gap(6)
                    if (model.pageValues.isEmpty()) {
                        Text(Say("Open the correlation page and press Read.",
                            "కొరిలేషన్ పేజీ తెరిచి Read నొక్కండి.").text(),
                            style = MaterialTheme.typography.bodySmall)
                    }
                    for ((key, value) in model.pageValues) {
                        Cells(listOf(key, value.ifBlank { "-" }), listOf(150, 220))
                    }
                }
                Gap()
                Panel(Words.maps.text(), note = model.parcelFile.ifBlank { "-" }) {
                    Text(
                        "${model.parcels.size} " +
                            Say("parcels read", "పార్సెల్స్ చదివింది").text(),
                        style = MaterialTheme.typography.bodyMedium)
                    if (model.parcels.isNotEmpty() && model.records.isNotEmpty()) {
                        val rows = model.records.map {
                            Khata.GovtRow(it.rowNumber, it.surveyNo,
                                it.subDivision, it.lpm)
                        }
                        val extents = model.records.associate {
                            it.rowNumber to it.extent
                        }
                        val pairs = remember(model.parcels.size, model.records.size) {
                            Correlate.match(rows, model.parcels.toList(),
                                { extents[it] ?: "" })
                        }
                        Gap(6)
                        for (f in Correlate.summary(pairs)) FindingRow(f)
                        Gap(6)
                        Cells(
                            listOf(Words.row.text(), Words.surveyNo.text(),
                                Words.lpm.text(), "DLR", "Map",
                                Say("Confidence", "నమ్మకం").text()),
                            listOf(60, 90, 80, 90, 90, 120), heading = true)
                        LazyColumn(Modifier.height(240.dp).fillMaxWidth()) {
                            items(pairs.filter { it.needsReview }) { pair ->
                                Cells(
                                    listOf(pair.rowNumber.toString(), pair.surveyNo,
                                        pair.lpm, pair.dlrExtent, pair.mapExtent,
                                        pair.confidence.name),
                                    listOf(60, 90, 80, 90, 90, 120),
                                    tint = if (pair.confidence ==
                                        Correlate.Confidence.NONE) Failedd else null)
                            }
                        }
                    } else {
                        Note(Say("Open a KML, GeoJSON or shapefile zip on the " +
                            "Files page to compare it with the register.",
                            "రిజిస్టర్‌తో పోల్చడానికి Files పేజీలో KML, GeoJSON " +
                                "లేదా షేప్‌ఫైల్ zip తెరవండి.").text())
                    }
                }
                Gap()
                Panel(Words.dlrData.text()) {
                    LazyColumn(Modifier.height(200.dp).fillMaxWidth()) {
                        items(model.records.take(400), key = { it.id }) { record ->
                            Cells(
                                listOf(record.rowNumber.toString(), record.lpm,
                                    record.surveyNo, record.subDivision,
                                    record.extent),
                                listOf(60, 80, 90, 90, 90),
                                tint = if (picked?.id == record.id)
                                    MaterialTheme.colorScheme.primary else null,
                                onClick = { picked = record })
                        }
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                PortalView(model, Modifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}

/**
 * VRO login - Ground Truthing.
 *
 * The page's own ground-truth boxes are read and set beside what the
 * register says for the same plot, so a difference is seen rather than
 * worked out. Nothing is written: the ground truth is what the VRO saw,
 * and an app that filled it in would be inventing a field visit.
 */
@Composable
fun VroScreen(model: AppModel) {
    var picked by remember { mutableStateOf<RecordRow?>(null) }
    FixedPage(Words.vroLogin.text(),
        Say("The app reads and compares. What the ground truth says is for " +
            "the VRO to enter.",
            "యాప్ చదివి పోల్చుతుంది. గ్రౌండ్ ట్రూత్ VRO నింపాలి.").text()) {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Panel(Words.vroGroundTruth.text()) {
                    PortalBar(model)
                    Buttons {
                        Do(Say("Read the page", "పేజీ చదువు"),
                            { model.readPage("VRO") }, enabled = model.portalOpen)
                    }
                    Gap(6)
                    for ((key, value) in model.pageValues) {
                        Cells(listOf(key, value.ifBlank { "-" }), listOf(170, 200))
                    }
                }
                Gap()
                Panel(Say("The register, for the same plot",
                    "అదే ప్లాట్ కోసం రిజిస్టర్").text()) {
                    LazyColumn(Modifier.height(190.dp).fillMaxWidth()) {
                        items(model.records.take(400), key = { it.id }) { record ->
                            Cells(
                                listOf(record.rowNumber.toString(), record.lpm,
                                    record.surveyNo, record.subDivision,
                                    Presets.byId(record.presetId)?.te ?: "-"),
                                listOf(60, 80, 90, 90, 140),
                                tint = if (picked?.id == record.id)
                                    MaterialTheme.colorScheme.primary else null,
                                onClick = { picked = record })
                        }
                    }
                    val record = picked
                    val preset = record?.let { Presets.byId(it.presetId) }
                    if (record != null && preset != null) {
                        Gap(8)
                        Text(
                            "${Words.row.text()} ${record.rowNumber} - " +
                                Words.chainShown.text(),
                            style = MaterialTheme.typography.titleSmall)
                        for ((box, word) in AddFlow.chain(preset)) {
                            val onPage = model.pageValues.entries.firstOrNull {
                                it.value.isNotBlank() && it.value == word
                            }
                            Cells(
                                listOf(box, word,
                                    if (onPage != null)
                                        Say("same on the page", "పేజీలో అదే").text()
                                    else ""),
                                listOf(200, 170, 150),
                                tint = if (onPage != null) Entered else null)
                        }
                    } else if (record != null) {
                        Gap(6)
                        Note(Say("This record has no kind of land yet. Set it on " +
                            "the DLR Data page.",
                            "ఈ రికార్డుకు భూమి రకం లేదు. DLR డేటా పేజీలో " +
                                "పెట్టండి.").text())
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                PortalView(model, Modifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}

/**
 * Tahsildar - Digital Signature.
 *
 * The app opens the page, says which records are ready and which are
 * not, and stops there. It does not press the signing button, it cannot
 * hold a DSC, and it never records a signature that did not happen. A
 * signature is the officer saying the register is right; a program
 * cannot say that for them.
 */
@Composable
fun SignScreen(model: AppModel) {
    val ready = model.records.filter { it.automationState == RowState.SUCCESS.name }
    val notReady = model.records.filter {
        it.automationState != RowState.SUCCESS.name
    }
    FixedPage(Words.signPage.text(), Words.signNeverFaked.text()) {
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(end = 14.dp),
            ) {
                Note(Words.signNeverFaked.text())
                Gap()
                Panel(Say("Ready for signature", "సంతకానికి సిద్ధం").text(),
                    note = "${ready.size}") {
                    LazyColumn(Modifier.height(220.dp).fillMaxWidth()) {
                        items(ready.take(400), key = { it.id }) { record ->
                            Cells(
                                listOf(record.rowNumber.toString(), record.lpm,
                                    record.surveyNo, record.khata),
                                listOf(60, 90, 90, 120), tint = Entered)
                        }
                    }
                }
                Gap()
                Panel(Say("Not ready", "సిద్ధం కాలేదు").text(),
                    note = "${notReady.size}") {
                    LazyColumn(Modifier.height(200.dp).fillMaxWidth()) {
                        items(notReady.take(400), key = { it.id }) { record ->
                            val state = runCatching {
                                RowState.valueOf(record.automationState)
                            }.getOrDefault(RowState.PENDING)
                            Cells(
                                listOf(record.rowNumber.toString(), record.lpm,
                                    stateWord(state).text(),
                                    record.message.take(60)),
                                listOf(60, 90, 130, 200),
                                tint = tintOf(state))
                        }
                    }
                }
                Gap()
                Panel(Say("The signing page", "సంతకం పేజీ").text()) {
                    PortalBar(model)
                    Buttons {
                        Do(Say("Read the page", "పేజీ చదువు"),
                            { model.readPage("SIGN") }, enabled = model.portalOpen)
                    }
                    for ((key, value) in model.pageValues) {
                        Cells(listOf(key, value.ifBlank { "-" }), listOf(150, 220))
                    }
                }
            }
            Column(Modifier.weight(1.1f)) {
                PortalView(model, Modifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}
