package ap.webland

import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import ap.webland.ui.AppModel
import ap.webland.ui.LocalTelugu
import ap.webland.ui.Screen
import ap.webland.ui.Words
import ap.webland.ui.screens.AddRecordScreen
import ap.webland.ui.screens.DashboardScreen
import ap.webland.ui.screens.DlrDataScreen
import ap.webland.ui.screens.FilesScreen
import ap.webland.ui.screens.RecorderScreen
import ap.webland.ui.screens.ReportsScreen
import ap.webland.ui.screens.RunScreen
import ap.webland.ui.screens.SettingsScreen
import ap.webland.ui.screens.SignScreen
import ap.webland.ui.screens.ValidationScreen
import ap.webland.ui.screens.VroScreen
import ap.webland.ui.screens.VsScreen
import ap.webland.ui.text
import ap.webland.ui.theme.BWeblandTheme

/**
 * The one screen of the app, with the twelve places down its left side.
 *
 * The WebView is made here, once, and lent to whichever page is showing
 * the portal. That is not a detail: the portal's session lives in that
 * one view, and making a new one for each screen would sign the
 * surveyor out every time they looked at the dashboard.
 *
 * The screen is kept awake while a run is going, because the portal page
 * has to stay in front for a WebView to work reliably, and a tablet that
 * sleeps halfway through 3,000 records is a morning lost.
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    /** kept so the session can be written down when the app goes away */
    private var held: AppModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as BWeblandApp
        web = WebView(this)

        setContent {
            val model: AppModel = viewModel(factory = factoryFor(app))
            LaunchedEffect(Unit) {
                model.attach(web)
                held = model
            }
            LaunchedEffect(model.running) {
                if (model.running) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
            BWeblandTheme(model.theme) {
                CompositionLocalProvider(LocalTelugu provides model.telugu) {
                    Shell(model)
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        // Write the session cookies down, so closing the app does not
        // sign the surveyor out of the portal.
        held?.keepSession()
    }

    override fun onDestroy() {
        super.onDestroy()
        web.destroy()
    }

    private fun factoryFor(app: BWeblandApp): ViewModelProvider.Factory =
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AppModel(app) as T
        }
}

private data class Place(val screen: Screen, val icon: ImageVector)

private val places = listOf(
    Place(Screen.DASHBOARD, Icons.Filled.Dashboard),
    Place(Screen.DLR_DATA, Icons.Filled.TableChart),
    Place(Screen.ADD_RECORD, Icons.Filled.NoteAdd),
    Place(Screen.VS, Icons.Filled.Map),
    Place(Screen.VRO, Icons.Filled.Terrain),
    Place(Screen.SIGN, Icons.Filled.Draw),
    Place(Screen.RECORDER, Icons.Filled.FiberManualRecord),
    Place(Screen.RUN, Icons.Filled.PlayArrow),
    Place(Screen.VALIDATION, Icons.Filled.Checklist),
    Place(Screen.REPORTS, Icons.Filled.Description),
    Place(Screen.FILES, Icons.Filled.Folder),
    Place(Screen.SETTINGS, Icons.Filled.Settings),
)

@Composable
private fun Shell(model: AppModel) {
    Scaffold { padding ->
        Row(Modifier.fillMaxSize().padding(padding)) {
            NavigationRail(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                header = {
                    Column(
                        Modifier.padding(top = 10.dp, bottom = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(Icons.Filled.Assignment, contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary)
                    }
                },
            ) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    for (place in places) {
                        NavigationRailItem(
                            selected = model.screen == place.screen,
                            onClick = { model.screen = place.screen },
                            icon = {
                                Icon(place.icon,
                                    contentDescription = place.screen.title.text())
                            },
                            label = { Text(place.screen.title.text()) },
                        )
                    }
                }
            }
            Column(Modifier.weight(1f)) {
                if (model.busy || model.running) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else {
                    Spacer(Modifier.height(4.dp))
                }
                Box(Modifier.weight(1f)) {
                    when (model.screen) {
                        Screen.DASHBOARD -> DashboardScreen(model)
                        Screen.DLR_DATA -> DlrDataScreen(model)
                        Screen.ADD_RECORD -> AddRecordScreen(model)
                        Screen.VS -> VsScreen(model)
                        Screen.VRO -> VroScreen(model)
                        Screen.SIGN -> SignScreen(model)
                        Screen.RECORDER -> RecorderScreen(model)
                        Screen.RUN -> RunScreen(model)
                        Screen.VALIDATION -> ValidationScreen(model)
                        Screen.REPORTS -> ReportsScreen(model)
                        Screen.FILES -> FilesScreen(model)
                        Screen.SETTINGS -> SettingsScreen(model)
                    }
                }
                if (model.said.isNotBlank()) {
                    Snackbar(
                        action = {
                            TextButton(onClick = { model.clearSaid() }) {
                                Text(Words.close.text())
                            }
                        },
                        modifier = Modifier.padding(8.dp),
                    ) { Text(model.said) }
                }
            }
        }
    }
}
