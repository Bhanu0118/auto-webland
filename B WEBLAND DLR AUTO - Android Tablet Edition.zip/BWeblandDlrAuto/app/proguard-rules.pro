# The macro engine and the rules are reached by name from the WebView
# bridge and from Room's generated code, so they are kept whole.
-keep class ap.webland.core.** { *; }
-keep class ap.webland.data.** { *; }

# Anything annotated for the WebView bridge must keep its method names,
# or the page cannot call back into the app.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keepattributes *Annotation*, Signature, InnerClasses
-dontwarn org.jetbrains.annotations.**
