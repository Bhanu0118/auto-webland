#!/usr/bin/env bash
# B WEBLAND DLR AUTO - Android Tablet Edition
#
# Builds app-debug.apk on Linux or macOS with no Android Studio.
# Everything is downloaded into ./tools, so nothing is installed into
# the system and deleting that folder undoes all of it.
#
# Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.

set -u
cd "$(dirname "$0")"
HERE="$PWD"
TOOLS="$HERE/tools"
SDK="$TOOLS/android-sdk"
GRADLE="$TOOLS/gradle-8.9"

say() { printf '  %s\n' "$*"; }
die() { printf '\n  ERROR: %s\n\n' "$*" >&2; exit 1; }

[ -f settings.gradle.kts ] || die "run this from inside the BWeblandDlrAuto folder"
mkdir -p "$TOOLS"

case "$(uname -s)" in
  Linux)  OS=linux;  SDK_OS=linux ;;
  Darwin) OS=mac;    SDK_OS=mac ;;
  *) die "this script is for Linux and macOS; on Windows run BUILD_APK.bat" ;;
esac

echo
echo "  ============================================================"
echo "   B WEBLAND DLR AUTO  -  APK build"
echo "  ============================================================"
echo

# ----------------------------------------------------------------- java
say "[1/5] Java 17"
if [ -n "${JAVA_HOME:-}" ] && "$JAVA_HOME/bin/javac" -version 2>&1 | grep -q ' 17'; then
  say "      using JAVA_HOME"
elif command -v javac >/dev/null && javac -version 2>&1 | grep -q ' 17'; then
  JAVA_HOME="$(dirname "$(dirname "$(command -v javac)")")"
  say "      using the javac already installed"
elif [ -x "$TOOLS/jdk17/bin/javac" ]; then
  JAVA_HOME="$TOOLS/jdk17"
  say "      already downloaded"
else
  say "      downloading Temurin JDK 17 (about 180 MB)"
  ARCH=x64
  [ "$(uname -m)" = "aarch64" ] && ARCH=aarch64
  [ "$(uname -m)" = "arm64" ] && ARCH=aarch64
  URL="https://api.adoptium.net/v3/binary/latest/17/ga/${OS}/${ARCH}/jdk/hotspot/normal/eclipse"
  curl -fL "$URL" -o "$TOOLS/jdk.tar.gz" || die "Java could not be downloaded"
  mkdir -p "$TOOLS/jdktmp"
  tar -xzf "$TOOLS/jdk.tar.gz" -C "$TOOLS/jdktmp"
  inner="$(find "$TOOLS/jdktmp" -maxdepth 1 -mindepth 1 -type d | head -1)"
  [ "$OS" = "mac" ] && inner="$inner/Contents/Home"
  mv "$inner" "$TOOLS/jdk17"
  rm -rf "$TOOLS/jdk.tar.gz" "$TOOLS/jdktmp"
  JAVA_HOME="$TOOLS/jdk17"
fi
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"

# --------------------------------------------------------------- gradle
say "[2/5] Gradle 8.9"
if [ -x "$GRADLE/bin/gradle" ]; then
  say "      already here"
else
  say "      downloading (about 130 MB)"
  curl -fL "https://services.gradle.org/distributions/gradle-8.9-bin.zip" \
    -o "$TOOLS/gradle.zip" || die "Gradle could not be downloaded"
  unzip -q "$TOOLS/gradle.zip" -d "$TOOLS"
  rm -f "$TOOLS/gradle.zip"
fi

# ------------------------------------------------------------------ sdk
say "[3/5] Android SDK command line tools"
if [ -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  say "      already here"
else
  say "      downloading (about 130 MB)"
  URL="https://dl.google.com/android/repository/commandlinetools-${SDK_OS}-11076708_latest.zip"
  curl -fL "$URL" -o "$TOOLS/cmdline.zip" || die \
    "the command line tools could not be downloaded. Get the zip from
  https://developer.android.com/studio#command-line-tools-only
  and unzip it so that $SDK/cmdline-tools/latest/bin/sdkmanager exists"
  rm -rf "$TOOLS/cmdtmp"
  unzip -q "$TOOLS/cmdline.zip" -d "$TOOLS/cmdtmp"
  mkdir -p "$SDK/cmdline-tools"
  mv "$TOOLS/cmdtmp/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$TOOLS/cmdline.zip" "$TOOLS/cmdtmp"
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

say "[4/5] Android platform 34 and build tools"
if [ -f "$SDK/platforms/android-34/android.jar" ]; then
  say "      already here"
else
  yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses \
    >/dev/null 2>&1 || true
  say "      downloading (about 600 MB)"
  "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" \
    "platform-tools" "platforms;android-34" "build-tools;34.0.0" \
    || die "the Android platform could not be downloaded"
fi

printf 'sdk.dir=%s\n' "$SDK" > local.properties

# ---------------------------------------------------------------- build
say "[5/5] Building the APK"
echo
"$GRADLE/bin/gradle" --no-daemon clean assembleDebug || {
  echo
  echo "  ============================================================"
  echo "   THE BUILD STOPPED."
  echo "  ============================================================"
  echo "  The message above says where. If it names a file under"
  echo "    app/src/main/kotlin/ap/webland/ui/"
  echo "  send that message back - that part of the app could not be"
  echo "  compiled on the machine it was written on, and docs/STATUS.md"
  echo "  explains why."
  exit 1
}

APK="app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || die "the build said it worked but no APK is at $APK"
cp "$APK" "$HERE/B-WEBLAND-DLR-AUTO.apk"

echo
echo "  ============================================================"
echo "   DONE"
echo "  ============================================================"
echo
say "B-WEBLAND-DLR-AUTO.apk is in this folder."
say "Copy it to the tablet and open it; allow installing from this"
say "source once when the tablet asks."
echo
