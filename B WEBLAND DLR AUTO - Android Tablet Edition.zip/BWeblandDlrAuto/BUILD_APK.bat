@echo off
setlocal enabledelayedexpansion
title B WEBLAND DLR AUTO - build the APK
color 0F

REM ===================================================================
REM  B WEBLAND DLR AUTO - Android Tablet Edition
REM  Builds app-debug.apk on a Windows machine with NO Android Studio.
REM
REM  Everything it needs is downloaded into the "tools" folder beside
REM  this file, so nothing is installed into Windows and nothing is
REM  changed outside this folder. Delete the folder and it is all gone.
REM
REM  First run downloads about 1.5 GB and takes 15-30 minutes on a
REM  normal connection. After that a build takes a minute or two.
REM
REM  Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.
REM ===================================================================

cd /d "%~dp0"
set "HERE=%~dp0"
set "TOOLS=%HERE%tools"
set "SDK=%TOOLS%\android-sdk"
set "JDK=%TOOLS%\jdk17"
set "GRADLE=%TOOLS%\gradle-8.9"

echo.
echo  ============================================================
echo   B WEBLAND DLR AUTO  -  APK build
echo  ============================================================
echo.

if not exist "settings.gradle.kts" (
  echo  ERROR: run this from inside the BWeblandDlrAuto folder.
  echo  settings.gradle.kts was not found beside this file.
  goto :stop
)

if not exist "%TOOLS%" mkdir "%TOOLS%"

REM ------------------------------------------------------------- 1. JDK
echo  [1/5] Java 17
if exist "%JDK%\bin\javac.exe" (
  echo        already here
) else (
  echo        downloading Temurin JDK 17 ... this is about 180 MB
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "$u='https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse';" ^
    "Invoke-WebRequest -Uri $u -OutFile '%TOOLS%\jdk.zip' -UseBasicParsing;" ^
    "Expand-Archive -Path '%TOOLS%\jdk.zip' -DestinationPath '%TOOLS%\jdktmp' -Force;" ^
    "$inner=(Get-ChildItem '%TOOLS%\jdktmp' -Directory)[0].FullName;" ^
    "Move-Item $inner '%JDK%';" ^
    "Remove-Item '%TOOLS%\jdk.zip','%TOOLS%\jdktmp' -Recurse -Force"
  if not exist "%JDK%\bin\javac.exe" (
    echo  ERROR: Java could not be downloaded.
    echo  Download "OpenJDK 17 - JDK - Windows x64 - .zip" yourself from
    echo    https://adoptium.net/temurin/releases/?version=17
    echo  and unzip it so that this path exists:
    echo    %JDK%\bin\javac.exe
    goto :stop
  )
)
set "JAVA_HOME=%JDK%"
set "PATH=%JDK%\bin;%PATH%"

REM ---------------------------------------------------------- 2. Gradle
echo  [2/5] Gradle 8.9
if exist "%GRADLE%\bin\gradle.bat" (
  echo        already here
) else (
  echo        downloading Gradle ... about 130 MB
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '%TOOLS%\gradle.zip' -UseBasicParsing;" ^
    "Expand-Archive -Path '%TOOLS%\gradle.zip' -DestinationPath '%TOOLS%' -Force;" ^
    "Remove-Item '%TOOLS%\gradle.zip' -Force"
  if not exist "%GRADLE%\bin\gradle.bat" (
    echo  ERROR: Gradle could not be downloaded.
    echo  Get gradle-8.9-bin.zip from https://gradle.org/releases/
    echo  and unzip it into the tools folder.
    goto :stop
  )
)

REM ----------------------------------------------------- 3. Android SDK
echo  [3/5] Android SDK command line tools
if exist "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" (
  echo        already here
) else (
  echo        downloading ... about 130 MB
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "$u='https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip';" ^
    "Invoke-WebRequest -Uri $u -OutFile '%TOOLS%\cmdline.zip' -UseBasicParsing;" ^
    "Expand-Archive -Path '%TOOLS%\cmdline.zip' -DestinationPath '%TOOLS%\cmdtmp' -Force;" ^
    "New-Item -ItemType Directory -Force -Path '%SDK%\cmdline-tools' | Out-Null;" ^
    "Move-Item '%TOOLS%\cmdtmp\cmdline-tools' '%SDK%\cmdline-tools\latest';" ^
    "Remove-Item '%TOOLS%\cmdline.zip','%TOOLS%\cmdtmp' -Recurse -Force"
  if not exist "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" (
    echo  ERROR: the Android command line tools could not be downloaded.
    echo  Open   https://developer.android.com/studio#command-line-tools-only
    echo  download the Windows zip, and unzip it so that this path exists:
    echo    %SDK%\cmdline-tools\latest\bin\sdkmanager.bat
    echo  then run this file again.
    goto :stop
  )
)

set "ANDROID_HOME=%SDK%"
set "ANDROID_SDK_ROOT=%SDK%"

echo  [4/5] Android platform 34 and build tools
if exist "%SDK%\platforms\android-34\android.jar" (
  echo        already here
) else (
  echo        accepting the Android SDK licences
  powershell -NoProfile -Command "for($i=0;$i -lt 40;$i++){'y'}" | ^
    call "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" --sdk_root="%SDK%" --licenses >nul
  echo        downloading platform 34 and build tools ... about 600 MB
  call "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" --sdk_root="%SDK%" ^
    "platform-tools" "platforms;android-34" "build-tools;34.0.0"
  if not exist "%SDK%\platforms\android-34\android.jar" (
    echo  ERROR: the Android platform could not be downloaded.
    echo  Check the internet connection and run this file again.
    goto :stop
  )
)

> local.properties echo sdk.dir=%SDK:\=\\%

REM ------------------------------------------------------------ 5. build
echo  [5/5] Building the APK
echo        the first build downloads Compose and Room - give it time
echo.
call "%GRADLE%\bin\gradle.bat" --no-daemon clean assembleDebug
if errorlevel 1 (
  echo.
  echo  ============================================================
  echo   THE BUILD STOPPED.
  echo  ============================================================
  echo  The message above says where. If it names a file under
  echo    app\src\main\kotlin\ap\webland\ui\
  echo  send me that message and I will fix it - that part of the app
  echo  could not be compiled on the machine it was written on, and
  echo  docs\STATUS.md explains why.
  goto :stop
)

set "APK=app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (
  echo  ERROR: the build said it worked but no APK was found at
  echo    %APK%
  goto :stop
)

copy /y "%APK%" "%HERE%B-WEBLAND-DLR-AUTO.apk" >nul
echo.
echo  ============================================================
echo   DONE
echo  ============================================================
echo.
echo   B-WEBLAND-DLR-AUTO.apk  is in this folder.
echo.
echo   Copy it to the tablet and open it. The tablet will ask to
echo   allow installing from this source - allow it once.
echo.
echo   To build again after a change, just run this file. It keeps
echo   everything it downloaded and takes a minute.
echo.

:stop
echo.
pause
endlocal
