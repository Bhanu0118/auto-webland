import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.jvm)
}

// The rules engine, the macro engine and the spreadsheet reader. There
// is deliberately nothing here but the Kotlin standard library: no
// Android, no third-party dependency, nothing to go wrong on a tablet
// and nothing to stop the whole thing being run on a desktop.
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

/**
 * Every check in the core module.
 *
 *     ./gradlew :core:coreCheck
 *
 * There is no test framework to download: the checks are plain Kotlin
 * with their own runner, so this works on a machine that has never seen
 * this project before. Give it a real workbook to read as well with
 *
 *     ./gradlew :core:coreCheck -Dbwa.sample.xlsx=/path/to/DLR.xlsx
 */
val coreCheck by tasks.registering(JavaExec::class) {
    group = "verification"
    description = "Runs the core rules, macro, spreadsheet and map checks."
    classpath = sourceSets["test"].runtimeClasspath
    mainClass.set("ap.webland.core.test.MainKt")
    System.getProperty("bwa.sample.xlsx")?.let {
        systemProperty("bwa.sample.xlsx", it)
    }
}

tasks.named("check") { dependsOn(coreCheck) }
