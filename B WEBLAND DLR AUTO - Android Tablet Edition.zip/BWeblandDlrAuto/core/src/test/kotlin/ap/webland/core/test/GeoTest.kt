package ap.webland.core.test

import ap.webland.core.*

/** Maps: attributes are read, geometry is not touched. */
object GeoTest {

    private val KML = """
    <?xml version="1.0" encoding="UTF-8"?>
    <kml xmlns="http://www.opengis.net/kml/2.2"><Document>
      <Placemark>
        <name>212-4</name>
        <ExtendedData><SchemaData>
          <SimpleData name="SURVEY_NO">212</SimpleData>
          <SimpleData name="SUBDIV">212-4</SimpleData>
          <SimpleData name="LPM">1</SimpleData>
          <SimpleData name="EXTENT">0.680</SimpleData>
        </SchemaData></ExtendedData>
        <Polygon><outerBoundaryIs><LinearRing><coordinates>
          83.9,18.3,0 83.91,18.3,0 83.91,18.31,0 83.9,18.3,0
        </coordinates></LinearRing></outerBoundaryIs></Polygon>
      </Placemark>
      <Placemark>
        <name>212-2</name>
        <ExtendedData>
          <Data name="SURVEY_NO"><value>212</value></Data>
          <Data name="SUBDIV"><value>212-2</value></Data>
          <Data name="LPM"><value>3</value></Data>
          <Data name="EXTENT"><value>0.800</value></Data>
        </ExtendedData>
        <Polygon><outerBoundaryIs><LinearRing><coordinates>
          83.92,18.3,0 83.93,18.3,0 83.93,18.31,0 83.92,18.3,0
        </coordinates></LinearRing></outerBoundaryIs></Polygon>
      </Placemark>
    </Document></kml>
    """.trimIndent()

    private val GEOJSON = """
    {"type":"FeatureCollection","features":[
      {"type":"Feature",
       "properties":{"name":"474-0","SURVEY_NO":"474","SUBDIV":"474-0",
                     "LPM":"259","EXTENT":"10.666"},
       "geometry":{"type":"Polygon","coordinates":[[[83.9,18.3],[83.91,18.3],
                   [83.91,18.31],[83.9,18.3]]]}}
    ]}
    """.trimIndent()

    fun kml() {
        Check.group("KML - attributes read, coordinates left alone")
        val parcels = Kml.read(KML)
        Check.equal("two placemarks", parcels.size, 2)
        Check.equal("survey number", parcels[0].surveyNo, "212")
        Check.equal("subdivision", parcels[0].subDivision, "212-4")
        Check.equal("LPM", parcels[0].lpm, "1")
        Check.equal("extent", parcels[0].extent, "0.680")
        Check.equal("the name", parcels[0].name, "212-4")
        Check.equal("one ring", parcels[0].ringCount, 1)
        Check.that("the geometry is carried as text, not parsed",
            parcels[0].geometryRaw.contains("83.9,18.3"))
        Check.equal("the second form of ExtendedData is read too",
            parcels[1].lpm, "3")
        Check.that("every coordinate string is still exactly as it was",
            KML.contains(parcels[0].geometryRaw.trim()))
    }

    fun geoJson() {
        Check.group("GeoJSON")
        val parcels = GeoJson.read(GEOJSON)
        Check.equal("one feature", parcels.size, 1)
        Check.equal("its survey number", parcels[0].surveyNo, "474")
        Check.equal("its LPM", parcels[0].lpm, "259")
        Check.equal("its extent", parcels[0].extent, "10.666")
        Check.equal("one ring counted", parcels[0].ringCount, 1)
    }

    fun dbf() {
        Check.group("A shapefile's attribute table, and only that")
        val bytes = buildDbf(
            listOf(Triple("SURVEY_NO", 'C', 10), Triple("LPM", 'C', 8)),
            listOf(listOf("212", "1"), listOf("213", "2")))
        val read = Dbf.read(bytes)
        Check.equal("two fields", read.fields.size, 2)
        Check.equal("named as in the file", read.fields[0].name, "SURVEY_NO")
        Check.equal("two records", read.rows.size, 2)
        Check.equal("first survey number", read.rows[0]["SURVEY_NO"], "212")
        Check.equal("second LPM", read.rows[1]["LPM"], "2")
        Check.equal("nothing was marked deleted", read.deleted, 0)
        Check.threw("a file too short to be a .dbf is refused") {
            Dbf.read(ByteArray(10))
        }
    }

    fun correlate() {
        Check.group("Matching the map to the register")
        val parcels = Kml.read(KML)
        val records = listOf(
            Khata.GovtRow(2, "212", "212-4", "1"),
            Khata.GovtRow(3, "212", "212-2", "3"),
            Khata.GovtRow(4, "999", "999-1", "77"))
        val extents = mapOf(2 to "0.680", 3 to "0.900", 4 to "1.000")
        val pairs = Correlate.match(records, parcels, { extents[it] ?: "" })
        Check.equal("three pairs", pairs.size, 3)
        Check.equal("the first matched on its LPM",
            pairs[0].confidence, Correlate.Confidence.CERTAIN)
        Check.that("and needs nobody", !pairs[0].needsReview)
        Check.equal("the second matched but the extents differ",
            pairs[1].confidence, Correlate.Confidence.LIKELY)
        Check.that("so it is kept for a person",
            pairs[1].needsReview && pairs[1].why.contains("differ"))
        Check.equal("the third has no parcel at all",
            pairs[2].confidence, Correlate.Confidence.NONE)

        val found = Correlate.summary(pairs)
        Check.that("the summary counts the certain ones",
            found.any { it.title.contains("1 of 3") })
        Check.that("and promises that no geometry was touched",
            found.any { it.rule == "geometry" && it.title.contains("No coordinate") })

        val sheet = Reports.correlation(pairs)
        Check.equal("the report has a row per record", sheet.rows.size, 3)
        Check.that("and marks the ones needing a person",
            sheet.rows.count { it.last() == "yes" } == 2)
    }

    /** The smallest real .dbf: a header, field descriptors, records. */
    private fun buildDbf(
        fields: List<Triple<String, Char, Int>>,
        rows: List<List<String>>,
    ): ByteArray {
        val headerLength = 32 + fields.size * 32 + 1
        val recordLength = 1 + fields.sumOf { it.third }
        val out = ByteArray(headerLength + rows.size * recordLength + 1)
        out[0] = 0x03
        out[1] = 126; out[2] = 11; out[3] = 7                 // a date
        writeInt(out, 4, rows.size)
        writeShort(out, 8, headerLength)
        writeShort(out, 10, recordLength)
        var at = 32
        for ((name, type, length) in fields) {
            val bytes = name.toByteArray(Charsets.ISO_8859_1)
            for (i in bytes.indices.take(11)) out[at + i] = bytes[i]
            out[at + 11] = type.code.toByte()
            out[at + 16] = length.toByte()
            at += 32
        }
        out[at] = 0x0D
        var p = headerLength
        for (row in rows) {
            out[p] = ' '.code.toByte()
            var q = p + 1
            fields.forEachIndexed { i, f ->
                val text = (row.getOrNull(i) ?: "").padEnd(f.third).take(f.third)
                val bytes = text.toByteArray(Charsets.UTF_8)
                for (j in 0 until minOf(bytes.size, f.third)) out[q + j] = bytes[j]
                q += f.third
            }
            p += recordLength
        }
        out[out.size - 1] = 0x1A
        return out
    }

    private fun writeShort(b: ByteArray, at: Int, v: Int) {
        b[at] = (v and 0xFF).toByte()
        b[at + 1] = ((v shr 8) and 0xFF).toByte()
    }

    private fun writeInt(b: ByteArray, at: Int, v: Int) {
        b[at] = (v and 0xFF).toByte()
        b[at + 1] = ((v shr 8) and 0xFF).toByte()
        b[at + 2] = ((v shr 16) and 0xFF).toByte()
        b[at + 3] = ((v shr 24) and 0xFF).toByte()
    }

    fun run() {
        kml(); geoJson(); dbf(); correlate()
    }
}
