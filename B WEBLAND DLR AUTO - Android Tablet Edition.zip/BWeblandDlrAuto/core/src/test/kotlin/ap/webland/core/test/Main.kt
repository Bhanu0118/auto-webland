package ap.webland.core.test

/**
 * Every check in the core module, in one run.
 *
 *     ./gradlew :core:coreCheck
 *
 * or, with nothing but the Kotlin compiler:
 *
 *     kotlinc core/src -d out
 *     kotlin -cp out ap.webland.core.test.MainKt
 *
 * The exit code is 0 when everything passed, so this can be wired into
 * a build that must not ship a broken rule engine.
 */
fun main() {
    println("B WEBLAND DLR AUTO - core checks")
    println("=".repeat(62))
    RulesTest.run()
    MacroTest.run()
    RunnerTest.run()
    BwaTest.run()
    AddFlowTest.run()
    XlsxTest.run()
    GeoTest.run()
    println("=".repeat(62))
    val code = Check.report()
    if (code != 0) throw AssertionError("$code: some checks failed")
}
