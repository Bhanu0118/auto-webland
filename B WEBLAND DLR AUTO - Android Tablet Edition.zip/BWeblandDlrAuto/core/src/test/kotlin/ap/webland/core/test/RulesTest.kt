package ap.webland.core.test

import ap.webland.core.*

/** Extents, the land-nature table, the instruction sheet, khatas. */
object RulesTest {

    fun extents() {
        Check.group("Extent - zeros are added, nothing is rounded")
        Check.equal("0.33 becomes 0.330", Extent.pad("0.33"), "0.330")
        Check.equal("0.68 becomes 0.680", Extent.pad("0.68"), "0.680")
        Check.equal("1 becomes 1.000", Extent.pad("1"), "1.000")
        Check.equal("0.550 stays 0.550", Extent.pad("0.550"), "0.550")
        Check.equal("10.666 stays 10.666", Extent.pad("10.666"), "10.666")
        Check.equal("0.1 becomes 0.100", Extent.pad("0.1"), "0.100")
        Check.equal("a fourth decimal is NOT rounded away",
            Extent.pad("0.3333"), "0.3333")
        Check.that("and it is reported instead", Extent.tooPrecise("0.3333"))
        Check.that("three decimals are not too precise", !Extent.tooPrecise("0.333"))
        Check.equal("a blank stays blank", Extent.pad(""), "")
        Check.equal("words are left alone", Extent.pad("na"), "na")
        Check.equal("a negative keeps its sign", Extent.pad("-0.5"), "-0.500")
        Check.that("0.68 and 0.680 are the same extent", Extent.same("0.68", "0.680"))
        Check.that("0.68 and 0.69 are not", !Extent.same("0.68", "0.69"))
        Check.equal("a column adds up", Extent.total(listOf("0.680", "0.320")),
            "1.000")
        Check.that("zero is noticed", Extent.isZero("0.000"))
        Check.equal("an acre is 100 cents",
            Extent.convert(1.0, Extent.Unit.ACRE, Extent.Unit.CENT), 100.0)
    }

    fun presets() {
        Check.group("The land-nature table, carried from the Windows app")
        Check.equal("32 rows", Presets.ALL.size, 32)
        Check.equal("22 of them come from the DLR sheet", Presets.fromSheet().size, 22)
        Check.equal("10 are older", Presets.older().size, 10)
        Check.equal("every id is unique",
            Presets.ALL.map { it.id }.distinct().size, 32)

        val dry = Presets.byId("dry")!!
        Check.equal("dry nature", dry.nature, "పట్టా")
        Check.equal("dry classification", dry.classification, "పుంజ")
        Check.equal("dry broad classification", dry.broadClass, "Dry")
        Check.equal("dry sub classification", dry.subClass, "-")
        Check.equal("dry rights", dry.rights, "Ancestral")
        Check.that("dry is not government land", !dry.isGovt)

        val wet = Presets.byId("wet")!!
        Check.equal("wet classification", wet.classification, "నంజ")
        Check.equal("wet sub classification", wet.subClass,
            "Medium/Minor Irrigation")

        val dpatta = Presets.byId("dpatta")!!
        Check.that("d-patta is government land", dpatta.isGovt)
        Check.equal("d-patta sub nature", dpatta.subNature, "Govt.Land Alloted")
        Check.equal("d-patta sub A", dpatta.subNatureA, "Assigned (D-Patta)")
        Check.equal("d-patta sub B", dpatta.subNatureB, "Agriculture")
        Check.equal("d-patta rights", dpatta.rights, "Assignment")

        val burial = Presets.byId("burial")!!
        Check.equal("a sheet row uses the portal's own spelling",
            burial.subNature, "Govt.Land-Settlement")
        Check.equal("and the portal's Poramboke", burial.broadClass, "Poramboke(P)")
        Check.equal("and the sheet's rights", burial.rights, "Govt. Lands")
        Check.that("every sheet row is government land",
            Presets.fromSheet().all { it.isGovt })

        Check.equal("the old reservoir was renamed, not deleted",
            Presets.byId("reservoir-old")?.supersededBy, "reservoir")
        Check.equal("nadhi now points at the sheet's river",
            Presets.byId("nadhi")?.supersededBy, "river")
        Check.equal("the sheet has no row for gayalu",
            Presets.byId("gayalu")?.supersededBy, "")
        Check.that("a row from the sheet is not marked superseded",
            Presets.fromSheet().all { it.supersededBy == null })

        Check.group("The portal's own field ids")
        Check.equal("the LPM box", PortalFields.ADD["lpm"], "grAddRecord_txtlpmno_0")
        Check.equal("the misspelling on the site is kept",
            PortalFields.ADD["bclass"],
            "grAddRecord_ddlBroadCategory_LandCalssification1_0")
        Check.equal("the Add button", PortalFields.ADD["add_btn"], "btnAdd")
        Check.equal("joint cultivation No",
            PortalFields.ADD["joint_no"], "grAddRecord_rbllistcultivate_add_0_1_0")
        Check.equal("the VS page's chaltha box", PortalFields.VS["chaltha"],
            "txtChaltha")
        Check.equal("the VRO page's ground-truth nature",
            PortalFields.VRO["bnature"], "ddlBroadCategory_LandNature_GT")
    }

    fun dlrRules() {
        Check.group("The DLR instruction sheet, as checks")
        Check.equal("3,00,001 is written the way the sheet writes it",
            DlrRules.grouped(300001), "3,00,001")
        Check.equal("the series starts there", PortalWords.NON_AGRI_LPM_FROM, 300001)
        Check.equal("the SWLA khata", PortalWords.SWLA_KHATA, "20001701")

        val (govtRights, govtRule) = DlrRules.expectedRights(Presets.byId("burial"))
        Check.equal("rule 19.1 gives government land Govt. Lands",
            govtRights, "Govt. Lands")
        Check.equal("and it is rule 19.1", govtRule, "19.1")

        val (dRights, dRule) = DlrRules.expectedRights(Presets.byId("dpatta"))
        Check.equal("rule 19.2 gives d-patta Assignment", dRights, "Assignment")
        Check.equal("and it is rule 19.2", dRule, "19.2")

        val (pRights, pRule) = DlrRules.expectedRights(Presets.byId("dry"))
        Check.equal("private land's rights come from the ROR, so nothing is " +
            "expected", pRights, "")
        Check.equal("which the sheet numbers 19.6", pRule, "19.6")

        Check.that("a government building is in rule 13's list",
            DlrRules.looksNonAgri(Presets.byId("govt-building")))
        Check.that("gramakhantam too",
            DlrRules.looksNonAgri(Presets.byId("gramakhantam")))
        Check.that("a canal is NOT, however non-agricultural it is",
            !DlrRules.looksNonAgri(Presets.byId("canal")))
        Check.that("nor is a road", !DlrRules.looksNonAgri(Presets.byId("gp-road")))
        Check.that("nor is a banjar", !DlrRules.looksNonAgri(Presets.byId("banjar")))

        val low = listOf(SimpleRecord(5, "45", "20000102"),
            SimpleRecord(6, "300002", "20000102"))
        val onBuildings = DlrRules.check(Presets.byId("govt-building"), low)
        val rule13 = onBuildings.firstOrNull { it.rule == "13" }
        Check.that("rule 13 fires on the LPM below the series", rule13 != null)
        Check.equal("and names only that row", rule13?.rows, listOf(5))
        Check.equal("as a warning, not a change", rule13?.level, Level.WARN)
        Check.that("nothing in the sheet check is a STOP",
            onBuildings.none { it.level == Level.STOP })
        Check.that("so the run may go ahead", DlrRules.mayRun(onBuildings))

        val onCanal = DlrRules.check(Presets.byId("canal"), low)
        Check.that("rule 13 stays quiet for a canal",
            onCanal.none { it.rule == "13" })

        val swla = DlrRules.check(Presets.byId("canal"),
            listOf(SimpleRecord(9, "12", PortalWords.SWLA_KHATA)))
        Check.that("rule 17 notices the SWLA khata",
            swla.any { it.rule == "17" && it.rows == listOf(9) })

        val old = DlrRules.check(Presets.byId("nadhi"), emptyList())
        Check.that("an older preset says which sheet row replaced it",
            old.any { it.rule == "1-10" && it.detail.contains("river") })

        Check.equal("no preset is left with the rights box empty where the " +
            "sheet names one",
            Presets.fromSheet().count {
                val (want, _) = DlrRules.expectedRights(it)
                want.isNotEmpty() && it.rights != want
            }, 0)
    }

    fun khatas() {
        Check.group("Khata numbers")
        Check.that("101234 is notional", Khata.isNotional("101234"))
        Check.that("1012345 is notional", Khata.isNotional("1012345"))
        Check.that("20000102 is NOT notional", !Khata.isNotional("20000102"))
        Check.that("20000102 is a government khata", Khata.isGovernment("20000102"))
        Check.that("222 is an ordinary village khata", Khata.isOrdinary("222"))
        Check.that("10 on its own is too short to be notional",
            !Khata.isNotional("10"))
        Check.that("letters are not a khata number", !Khata.isNotional("10abcd"))

        val next = Khata.nextNumbers(listOf("222", "478", "20000102", "101234"), 3)
        Check.equal("numbering carries on from the last ordinary khata",
            next, listOf("479", "480", "481"))
        Check.that("and never repeats one already used",
            Khata.nextNumbers(listOf("1", "2", "3"), 2) == listOf("4", "5"))

        Check.that("the same name with the same father is one person",
            Khata.samePerson("దాటి అప్పన్న", "దాటి", "దాటి అప్పన్న", "దాటి"))
        Check.that("the same name with a different father is two",
            !Khata.samePerson("దాటి అప్పన్న", "దాటి", "దాటి అప్పన్న", "వేరే"))
        Check.that("a missing father's name is not agreement",
            !Khata.samePerson("దాటి అప్పన్న", "", "దాటి అప్పన్న", ""))
        Check.that("extra spaces do not make two people",
            Khata.sameName("దాటి  అప్పన్న", "దాటి అప్పన్న"))

        val j = Khata.joint(listOf("ఒకటి", "రెండు", "మూడు"))
        Check.equal("a joint cultivation enters the first name", j.enter, "ఒకటి")
        Check.that("and keeps all of them", j.isJoint && j.all.size == 3)
        Check.equal("for the change-later report", j.report(), "ఒకటి / రెండు / మూడు")

        val rows = listOf(SimpleRecord(2, "1", "101234"),
            SimpleRecord(3, "2", ""), SimpleRecord(4, "3", "20000102"),
            SimpleRecord(5, "4", "222"), SimpleRecord(6, "5", "222"))
        val found = Khata.check(rows)
        Check.that("a notional khata is reported",
            found.any { it.title.contains("notional") && it.rows == listOf(2) })
        Check.that("a blank khata is reported",
            found.any { it.title.contains("no khata") && it.rows == listOf(3) })
        Check.that("a government khata is not treated as a problem",
            found.any { it.level == Level.NOTE && it.title.contains("government") })
        Check.that("one khatadar with two plots is a note, not a warning",
            found.any { it.level == Level.NOTE && it.title.contains("more than one") })

        val clash = Khata.govtLpmClashes(listOf(
            Khata.GovtRow(2, "212", "212-1", "1"),
            Khata.GovtRow(3, "212", "212-1", "2"),
            Khata.GovtRow(4, "213", "213-1", "3")))
        Check.equal("two LPMs on one government survey number are reported",
            clash.size, 1)
    }

    fun codes() {
        Check.group("Failures, and what may be offered after one")
        Check.equal("27 named failures", Codes.ALL.size, 27)
        Check.that("not one REVIEW failure recommends a retry",
            Codes.ALL.values.none {
                it.severity == Severity.REVIEW && it.advice in Codes.RETRY_ADVICE
            })
        Check.that("an unknown code still answers",
            Codes.of("NOT_A_REAL_CODE").code == Codes.UNKNOWN_ERROR)
        Check.equal("a lost session is fatal",
            Codes.of(Codes.SESSION_EXPIRED).severity, Severity.FATAL)
        Check.equal("an unknown save is for a person to look at",
            Codes.of(Codes.SAVE_UNKNOWN).severity, Severity.REVIEW)
        Check.that("and may not be retried",
            !Codes.of(Codes.SAVE_UNKNOWN).mayRetry())
        Check.that("every failure says something in Telugu",
            Codes.ALL.values.all { it.te.isNotBlank() })
        Check.that("and in English", Codes.ALL.values.all { it.en.isNotBlank() })
        Check.equal("the worst of several decides",
            Codes.worst(listOf(Codes.TIMEOUT, Codes.SESSION_EXPIRED,
                Codes.FIELD_MISMATCH))?.severity, Severity.FATAL)
    }

    fun states() {
        Check.group("Row states, and the one that is never retried")
        Check.that("only FAILED may be retried by the app",
            RowState.entries.filter { it.retryable } == listOf(RowState.FAILED))
        Check.that("NEEDS_REVIEW is not retryable",
            !RowState.NEEDS_REVIEW.retryable)
        Check.equal("a confirmed save is a success",
            SaveOutcome.OK.state(), RowState.SUCCESS)
        Check.equal("a refusal is a failure",
            SaveOutcome.INVALID.state(), RowState.FAILED)
        Check.equal("a duplicate is a failure, not a success",
            SaveOutcome.DUPLICATE.state(), RowState.FAILED)
        Check.equal("no answer means a person must look",
            SaveOutcome.TIMEOUT.state(), RowState.NEEDS_REVIEW)
        Check.equal("a form that merely cleared means the same",
            SaveOutcome.CLEARED.state(), RowState.NEEDS_REVIEW)

        Check.group("Reading what the portal says")
        Check.equal("\"Record saved successfully\" is a save",
            PortalTalk.read("Record saved successfully"), SaveOutcome.OK)
        Check.equal("\"Logged in successfully\" is NOT our save",
            PortalTalk.read("Logged in successfully"), null)
        Check.equal("\"Deleted successfully\" is not either",
            PortalTalk.read("Deleted successfully"), null)
        Check.equal("already available is a duplicate",
            PortalTalk.read("LPM already available"), SaveOutcome.DUPLICATE)
        Check.equal("please select is a refusal",
            PortalTalk.read("Please select Land Nature"), SaveOutcome.INVALID)
        Check.equal("session expired is a lost session",
            PortalTalk.read("Your session has expired"), SaveOutcome.SESSION)
        Check.equal("silence says nothing", PortalTalk.read(""), null)
        Check.that("the login page means signed out",
            PortalTalk.signedOut("https://webland2.ap.gov.in/POLR6/loginpage.aspx"))
        Check.that("the add page does not",
            !PortalTalk.signedOut("https://webland2.ap.gov.in/POLR6/DLR_Add.aspx"))

        Check.equal("a cleared form, settled, is evidence only",
            PortalTalk.decide(null, "x", false, true, 3_000), SaveOutcome.CLEARED)
        Check.equal("a form still holding the record, settled, did not save",
            PortalTalk.decide(null, "x", true, false, 5_000), SaveOutcome.NOT_SAVED)
        Check.equal("and with a message it was refused",
            PortalTalk.decide("Please enter extent", "x", true, false, 5_000),
            SaveOutcome.INVALID)
        Check.equal("too early to say", PortalTalk.decide(null, "x", true, false, 500),
            null)
        Check.equal("a password box on screen means signed out",
            PortalTalk.decide(null, "x", false, false, 0, true), SaveOutcome.SESSION)

        val results = listOf(
            RowResult(2, RowState.SUCCESS), RowResult(3, RowState.FAILED),
            RowResult(4, RowState.NEEDS_REVIEW), RowResult(5, RowState.SUCCESS))
        val t = Tally.of(results, 10)
        Check.equal("the counters add up", listOf(t.success, t.failed, t.review,
            t.pending, t.processed), listOf(2, 1, 1, 6, 4))
    }

    fun run() {
        extents(); presets(); dlrRules(); khatas(); codes(); states()
    }
}
