package ap.webland.core.test

import ap.webland.core.*

/** The recorder's own player, against the same pretend portal. */
object BwaTest {

    private fun recording(): Automation {
        val auto = Automation("Add one record")
        auto.mapping["LPM"] = "LPM"
        auto.add(Step(act = Act.TYPE,
            target = Target(mapOf("id" to "grAddRecord_txtlpmno_0",
                "label" to "LPM No")),
            value = "{{LPM}}"))
        auto.add(Step(act = Act.TYPE,
            target = Target(mapOf("id" to "grAddRecord_txtlpmnoExtent_0",
                "label" to "Extent")),
            value = "{{Extent}}"))
        auto.add(Step(act = Act.SELECT,
            target = Target(mapOf("id" to "grAddRecord_ddlLandNature1_0")),
            value = "{{Nature}}"))
        auto.add(Step(act = Act.SELECT,
            target = Target(mapOf("id" to "grAddRecord_ddlLandClassification1_0")),
            value = "{{Classification}}"))
        auto.add(Step(act = Act.CLICK,
            target = Target(mapOf("id" to "btnAdd", "text" to "Add")),
            meaning = Meaning.ADD))
        auto.add(Step(act = Act.WAIT, wait = Wait.SAVE_CONFIRMATION,
            timeoutMs = 30_000))
        return auto
    }

    private fun table(vararg rows: List<String>) = Table.of(
        listOf(listOf("LPM", "Extent", "Nature", "Classification")) + rows.toList())

    fun goodRow() {
        Check.group("A recording played on a good row")
        val page = FakePage()
        val t = table(listOf("1", "0.68", "పట్టా", "పుంజ"))
        val runner = BwaRunner(recording(), page, t)
        val r = runner.runRow(0)
        Check.equal("it succeeded", r.state, RowState.SUCCESS)
        Check.equal("the portal confirmed it", r.code, Codes.SAVE_CONFIRMED)
        Check.equal("the extent was padded",
            page.values["grAddRecord_txtlpmnoExtent_0"], "0.680")
        Check.equal("the nature was chosen",
            page.chosen["grAddRecord_ddlLandNature1_0"], "పట్టా")
        Check.equal("Add was pressed once", page.saves, 1)
        Check.that("nothing was left unverified", runner.misses.isEmpty())
    }

    fun columnByName() {
        Check.group("A recording names its columns, so their order does not matter")
        val page = FakePage()
        // the same data with the columns the other way round
        val t = Table.of(listOf(
            listOf("Classification", "Nature", "Extent", "LPM"),
            listOf("నంజ", "పట్టా", "0.5", "9")))
        val r = BwaRunner(recording(), page, t).runRow(0)
        Check.equal("it still succeeded", r.state, RowState.SUCCESS)
        Check.equal("and the right word went in",
            page.chosen["grAddRecord_ddlLandClassification1_0"], "నంజ")
        Check.equal("and the right LPM", page.saves, 1)
    }

    fun missingColumn() {
        Check.group("A column the file has not got")
        val page = FakePage()
        val t = Table.of(listOf(listOf("LPM", "Extent", "Nature"),
            listOf("1", "0.68", "పట్టా")))
        val r = BwaRunner(recording(), page, t).runRow(0)
        Check.that("the missing one is said out loud",
            page.logs.any { it.contains("{{Classification}}") })
        Check.that("the box is left alone rather than filled with a blank",
            page.chosen["grAddRecord_ddlLandClassification1_0"] == null)
        Check.that("and the row is not called a plain success",
            r.state != RowState.SUCCESS || r.code == Codes.FIELD_MISMATCH)
    }

    fun passwordNeeded() {
        Check.group("A recording that types a password")
        val auto = recording()
        auto.add(Step(act = Act.TYPE,
            target = Target(mapOf("id" to "grAddRecord_txtwebsysno_0")),
            value = Macro.SECRET_MARK, secret = true), at = 0)
        val withoutIt = BwaRunner(auto, FakePage(), table(
            listOf("1", "0.68", "పట్టా", "పుంజ"))).runRow(0)
        Check.equal("without one, the row stops before anything is entered",
            withoutIt.state, RowState.FAILED)
        Check.equal("and says why", withoutIt.code, Codes.LOGIN_FAILED)

        val page = FakePage()
        val withIt = BwaRunner(auto, page, table(
            listOf("1", "0.68", "పట్టా", "పుంజ")), password = "given-for-this-run")
            .runRow(0)
        Check.equal("with one, the row goes in", withIt.state, RowState.SUCCESS)
        Check.that("and the password is nowhere in the step",
            auto.steps.first().value == Macro.SECRET_MARK)
    }

    fun retryOnlyFailed() {
        Check.group("Retrying by row number touches only the rows named")
        val page = FakePage()
        val t = table(
            listOf("1", "0.68", "పట్టా", "పుంజ"),
            listOf("", "0.5", "పట్టా", "నంజ"),
            listOf("3", "0.25", "పట్టా", "పుంజ"))
        val first = BwaRunner(recording(), page, t).run(1, 3) { true }
        Check.equal("one of the three failed",
            first.count { it.state == RowState.FAILED }, 1)
        val failedLines = first.filter { it.state == RowState.FAILED }
            .map { it.rowNumber }
        Check.equal("and it is row 3 of the file", failedLines, listOf(3))

        val again = FakePage()
        val second = BwaRunner(recording(), again, t).runThese(failedLines) { true }
        Check.equal("only that row was attempted again", second.size, 1)
        Check.equal("and it is the same row", second.first().rowNumber, 3)
        Check.equal("so Add was pressed once more, not four times", again.saves, 1)
    }

    fun ticking() {
        Check.group("A tick box, read back to make sure it stayed ticked")
        val auto = Automation("tick")
        auto.add(Step(act = Act.CHECK,
            target = Target(mapOf("id" to "grAddRecord_rbllistcultivate_add_0_1_0",
                "label" to "Joint Cultivation No"))))
        val page = FakePage()
        val r = BwaRunner(auto, page, table(listOf("1", "0.1", "పట్టా", "పుంజ")))
            .runRow(0)
        Check.equal("it was ticked",
            page.chosen["grAddRecord_rbllistcultivate_add_0_1_0"], "CHECKED")
        Check.equal("and nothing saved, so the row is simply done",
            r.state, RowState.SUCCESS)
    }

    fun run() {
        goodRow(); columnByName(); missingColumn(); passwordNeeded()
        retryOnlyFailed(); ticking()
    }
}
