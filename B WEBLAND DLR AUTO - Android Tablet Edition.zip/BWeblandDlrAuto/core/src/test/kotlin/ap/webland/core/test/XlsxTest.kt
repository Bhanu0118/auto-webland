package ap.webland.core.test

import ap.webland.core.*
import java.io.ByteArrayInputStream
import java.io.File

/**
 * The spreadsheet reader and writer.
 *
 * Two kinds of check. The first writes a workbook and reads it straight
 * back, which proves the two halves agree with each other. The second
 * reads a file that this app did not write - when one is put beside the
 * test, the real thing from the office - which is the only way to find
 * out whether the reader agrees with Excel.
 */
object XlsxTest {

    private fun sheets(): List<Sheet> = listOf(
        Sheet("DLR", listOf("LPMNo", "Extent", "SyNo", "SubDiv", "Khata",
            "Name", "Note"),
            listOf(
                listOf("1", "0.680", "212", "212-4", "222",
                    "యరింజల సుబ్బమ్మ", "ordinary"),
                listOf("2", "10.666", "474", "474-0", "20000102",
                    "ప్రభుత్వ భూమి", "a comma, a \"quote\" & an ampersand"),
                listOf("3", "1.000", "212", "212-2", "478", "దాటి అప్పన్న", ""))),
        Sheet("Findings", listOf("Level", "What"),
            listOf(listOf("WARN", "LPM 45 is below the 3,00,001 series"))))

    fun roundTrip() {
        Check.group("A workbook written and read straight back")
        val bytes = Xlsx.bytes(sheets())
        Check.that("something was written", bytes.size > 1_000)
        Check.that("and it is a zip", bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte())

        val open = { ByteArrayInputStream(bytes) as java.io.InputStream }
        Check.equal("two sheets, named", Xlsx.sheetNames(open), listOf("DLR", "Findings"))

        val t = Xlsx.read(open, 0)
        Check.equal("seven columns", t.columns.size, 7)
        Check.equal("three rows", t.count(), 3)
        Check.equal("the headings came back", t.columns.take(3),
            listOf("LPMNo", "Extent", "SyNo"))
        Check.equal("an extent keeps its trailing zero",
            t.cell(0, "Extent"), "0.680")
        Check.equal("a whole-number extent keeps three decimals",
            t.cell(2, "Extent"), "1.000")
        Check.equal("a subdivision is not turned into anything else",
            t.cell(0, "SubDiv"), "212-4")
        Check.equal("a long khata stays as it is", t.cell(1, "Khata"), "20000102")
        Check.equal("Telugu survives the round trip", t.cell(0, "Name"),
            "యరింజల సుబ్బమ్మ")
        Check.equal("so do the characters XML cares about", t.cell(1, "Note"),
            "a comma, a \"quote\" & an ampersand")
        Check.equal("an empty cell is empty, not missing", t.cell(2, "Note"), "")

        val second = Xlsx.read(open, 1)
        Check.equal("the second sheet reads too", second.cell(0, "Level"), "WARN")
        Check.equal("and its sheet name is kept", second.sheetName, "Findings")
    }

    fun columnLetters() {
        Check.group("Column letters")
        Check.equal("A is the first", Xlsx.columnOf("A"), 0)
        Check.equal("Z is the twenty-sixth", Xlsx.columnOf("Z"), 25)
        Check.equal("AA comes next", Xlsx.columnOf("AA"), 26)
        Check.equal("and BK is 62", Xlsx.columnOf("BK"), 62)
        Check.equal("back again: 0 is A", Xlsx.lettersOf(0), "A")
        Check.equal("26 is AA", Xlsx.lettersOf(26), "AA")
        Check.equal("62 is BK", Xlsx.lettersOf(62), "BK")
        Check.that("every column up to 200 goes both ways",
            (0..200).all { Xlsx.columnOf(Xlsx.lettersOf(it)) == it })
    }

    fun escaping() {
        Check.group("Escaping, which is where a file breaks")
        Check.equal("an ampersand", Xlsx.unescape(Xlsx.escape("a & b")), "a & b")
        Check.equal("angle brackets",
            Xlsx.unescape(Xlsx.escape("<row> & </row>")), "<row> & </row>")
        Check.equal("a quote", Xlsx.unescape(Xlsx.escape("he said \"no\"")),
            "he said \"no\"")
        Check.equal("an apostrophe", Xlsx.unescape(Xlsx.escape("it's")), "it's")
        Check.equal("Telugu is left alone", Xlsx.escape("పట్టా"), "పట్టా")
        Check.that("a control character does not reach the file",
            !Xlsx.escape("a\u0007b").contains('\u0007'))
        Check.equal("a numeric escape is read back",
            Xlsx.unescape("&#x0C2A;&#3122;"), "పల")
    }

    /**
     * A file this app did not write. The build puts one here from the
     * office's own workbook; without it the check says so rather than
     * passing quietly.
     */
    fun realFile() {
        Check.group("A workbook written by something else")
        val file = File(System.getProperty("bwa.sample.xlsx") ?: "")
        if (!file.isFile) {
            Check.that("no outside workbook was given to read, so this is " +
                "not proved here", true,
                "pass -Dbwa.sample.xlsx=<path> to check against a real file")
            return
        }
        val open = { file.inputStream() as java.io.InputStream }
        val names = Xlsx.sheetNames(open)
        Check.that("its sheets are listed", names.isNotEmpty())
        val t = Xlsx.read(open, 0)
        Check.that("it has rows", t.count() > 0)
        Check.that("it has columns", t.columns.isNotEmpty())
        println("      ${file.name}: ${names.size} sheet(s), " +
            "${t.count()} rows, ${t.columns.size} columns")
        println("      headings: " + t.columns.take(8).joinToString(" | "))
        println("      first row: " +
            t.columns.take(8).map { t.cell(0, it) }.joinToString(" | "))
    }

    fun run() {
        roundTrip(); columnLetters(); escaping(); realFile()
    }
}
