package ap.webland.core.test

import ap.webland.core.*

/**
 * The runner, against a pretend portal.
 *
 * The point of a fake page is that the awkward cases can be arranged on
 * purpose: a dropdown whose list arrives late, a box that refuses the
 * first value typed into it, a Save that is never answered. Those are
 * exactly the cases that decide whether a land register ends up right,
 * and they are the ones a real portal will not produce to order.
 */
class FakePage(
    /** polls before a late dropdown's list appears */
    private val listArrivesAfter: Int = 0,
    /** boxes that refuse the first value typed */
    private val sticky: Set<String> = emptySet(),
    private val saveAnswers: Boolean = true,
    /** a silent save that empties the form, as a real one does */
    private val clearsOnSave: Boolean = true,
    private val signedOut: Boolean = false,
) : PageHost {

    val values = HashMap<String, String>()
    val options = HashMap<String, MutableList<String>>()
    val chosen = HashMap<String, String>()
    val clicks = ArrayList<String>()
    val logs = ArrayList<String>()
    var message = ""
    var saves = 0
    private var clock = 0L
    private val polls = HashMap<String, Int>()
    private val refused = HashSet<String>()

    /**
     * The real Add Record form, as far as a test needs one.
     *
     * Every box is taken from `PortalFields.ADD` and every dropdown's
     * options from the land-nature table, so the fake page cannot drift
     * away from the form the app actually drives. A word that is not in
     * the table is not in a list here either - which is how the test for
     * "another village's word" stays honest.
     */
    init {
        for ((key, id) in PortalFields.ADD) {
            if (id.contains("txt")) values[id] = ""
            if (key == "sclass_text") values[id] = ""
        }
        fun list(of: (LandPreset) -> String) =
            (listOf("") + Presets.ALL.map(of).filter { it.isNotBlank() })
                .distinct().toMutableList()
        options[PortalFields.ADD.getValue("nature")] = list { it.nature }
        options[PortalFields.ADD.getValue("classification")] =
            list { it.classification }
        options[PortalFields.ADD.getValue("bnature")] = list { it.broadNature }
        options[PortalFields.ADD.getValue("snature")] = list { it.subNature }
        options[PortalFields.ADD.getValue("snature_a")] = list { it.subNatureA }
        options[PortalFields.ADD.getValue("snature_b")] = list { it.subNatureB }
        options[PortalFields.ADD.getValue("bclass")] = list { it.broadClass }
        options[PortalFields.ADD.getValue("sclass")] = list { it.subClass }
        options[PortalFields.ADD.getValue("sclass_a")] = list { it.subClassA }
        options[PortalFields.ADD.getValue("land_use")] = list { it.landUse }
        options[PortalFields.ADD.getValue("irrigation")] = list { it.irrigation }
        options[PortalFields.ADD.getValue("rights")] = list { it.rights }
        options[PortalFields.ADD.getValue("action")] = list { it.action }
    }

    private fun id(sel: Selector) = sel.value

    override fun exists(sel: Selector): Boolean =
        id(sel) in values || id(sel) in options || id(sel) == "btnAdd" ||
            id(sel).contains("rbllist") || sel.kind == "linktext"

    override fun visible(sel: Selector) = exists(sel)

    override fun optionCount(sel: Selector): Int {
        val key = id(sel)
        val list = options[key] ?: return 0
        if (listArrivesAfter > 0 && key == "grAddRecord_ddlLandClassification1_0") {
            val n = (polls[key] ?: 0) + 1
            polls[key] = n
            if (n <= listArrivesAfter) return 1          // only the blank option
        }
        return list.size
    }

    override fun click(sel: Selector): Boolean {
        clicks.add(id(sel))
        if (id(sel).contains("rbllist")) chosen[id(sel)] = "CHECKED"
        if (id(sel) == "btnAdd") {
            saves++
            if (!saveAnswers) {
                // the portal says nothing. Whether the form emptied is
                // then the only evidence there is, either way.
                if (clearsOnSave) values["grAddRecord_txtlpmno_0"] = ""
                return true
            }
            val natureSet = (chosen["grAddRecord_ddlLandNature1_0"] ?: "").isNotEmpty()
            val lpm = values["grAddRecord_txtlpmno_0"] ?: ""
            if (!natureSet) {
                message = "Please select Land Nature"
            } else if (lpm.isBlank()) {
                message = "Please enter LPM No"
            } else {
                message = "Record saved successfully"
                values["grAddRecord_txtlpmno_0"] = ""      // the form clears
            }
        }
        return true
    }

    override fun type(sel: Selector, text: String): Boolean {
        val key = id(sel)
        if (key in sticky && key !in refused) {
            refused.add(key)                              // refuses once
            return true
        }
        if (key !in values && key !in options) return false
        values[key] = text
        return true
    }

    override fun select(sel: Selector, label: String): Boolean {
        val key = id(sel)
        val list = options[key] ?: return false
        if (optionCount(sel) <= 1) return false           // list not ready
        if (label !in list) return false                  // not an option
        chosen[key] = label
        return true
    }

    override fun readBack(sel: Selector): String {
        val key = id(sel)
        return chosen[key] ?: values[key] ?: ""
    }

    override fun pageText() = message
    override fun pageMessage() = message
    override fun url() =
        if (signedOut) "https://webland2.ap.gov.in/POLR6/loginpage.aspx"
        else "https://webland2.ap.gov.in/POLR6/DLR_Add.aspx"

    override fun open(url: String) {}
    override fun refresh() {}
    override fun frame(name: String) {}
    override fun hasPasswordBox() = signedOut
    override fun screenshot(tag: String) = "shots/$tag.png"
    override fun sleep(ms: Long) { clock += ms }
    override fun now(): Long { clock += 20; return clock }
    override fun log(line: String) { logs.add(line) }
}

object RunnerTest {

    private fun macro(vararg lines: UvCommand) = UvMacro("test", lines.toMutableList())

    private fun addRecordMacro(): UvMacro = macro(
        UvCommand("store", "true", "!ERRORIGNORE"),
        UvCommand("store", "2", "!TIMEOUT_WAIT"),
        UvCommand("csvRead", "data.csv"),
        UvCommand("type", "id=grAddRecord_txtlpmno_0", "\${!COL1}"),
        UvCommand("type", "id=grAddRecord_txtlpmnoExtent_0", "\${!COL2}"),
        UvCommand("type", "id=grAddRecord_txttotalextent_0", "\${!COL2}"),
        UvCommand("select", "id=grAddRecord_ddlLandNature1_0", "label=\${!COL3}"),
        UvCommand("select", "id=grAddRecord_ddlLandClassification1_0",
            "label=\${!COL4}"),
        UvCommand("click", "id=btnAdd"),
        UvCommand("echo", "done \${!COL1}"))

    private fun table(vararg rows: List<String>) = Table.of(
        listOf(listOf("LPM", "Extent", "Nature", "Classification")) + rows.toList())

    fun oneGoodRow() {
        Check.group("One record, everything as it should be")
        val page = FakePage()
        val t = table(listOf("1", "0.68", "పట్టా", "పుంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.equal("the row succeeded", r.state, RowState.SUCCESS)
        Check.equal("and the portal confirmed it", r.code, Codes.SAVE_CONFIRMED)
        Check.equal("Add was pressed once", page.saves, 1)
        Check.equal("the extent was padded to three decimals before typing",
            page.values["grAddRecord_txtlpmnoExtent_0"], "0.680")
        Check.equal("the total extent too",
            page.values["grAddRecord_txttotalextent_0"], "0.680")
        Check.equal("the land nature was chosen",
            page.chosen["grAddRecord_ddlLandNature1_0"], "పట్టా")
        Check.equal("the classification too",
            page.chosen["grAddRecord_ddlLandClassification1_0"], "పుంజ")
        Check.that("nothing was left unverified", runner.misses.isEmpty())
        Check.that("the echo was logged", page.logs.any { it.contains("done 1") })
    }

    fun lateList() {
        Check.group("A dropdown whose list arrives late")
        val page = FakePage(listArrivesAfter = 3)
        val t = table(listOf("1", "0.5", "పట్టా", "నంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.equal("it waits and then chooses",
            page.chosen["grAddRecord_ddlLandClassification1_0"], "నంజ")
        Check.equal("so the row still succeeds", r.state, RowState.SUCCESS)
    }

    fun stickyBox() {
        Check.group("A box that refuses the first value typed into it")
        val page = FakePage(sticky = setOf("grAddRecord_txtlpmno_0"))
        val t = table(listOf("7", "0.25", "పట్టా", "పుంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.equal("the second attempt gets the value in",
            page.values["grAddRecord_txtlpmno_0"], "")   // cleared by the save
        Check.equal("and the row succeeds", r.state, RowState.SUCCESS)
        Check.that("nothing is left over", runner.misses.isEmpty())
    }

    fun wordNotInTheList() {
        Check.group("A word the village's own dropdown does not have")
        val page = FakePage()
        val t = table(listOf("1", "0.68", "పట్టా", "మెట్ట"))   // Kadumu's word
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.that("the box is left unset",
            page.chosen["grAddRecord_ddlLandClassification1_0"] == null)
        Check.that("the miss is written down", runner.misses.isNotEmpty())
        Check.that("naming the box and the word",
            runner.misses.any {
                it.box.contains("ddlLandClassification") && it.wanted == "మెట్ట"
            })
        Check.equal("the portal still saved it, so a person must look",
            r.state, RowState.NEEDS_REVIEW)
        Check.equal("and the reason is a field that did not match",
            r.code, Codes.FIELD_MISMATCH)
        Check.that("the message says what was wanted",
            r.message.contains("మెట్ట"))
        Check.that("a picture was taken", r.screenshot.isNotBlank())
    }

    fun refusedSave() {
        Check.group("The portal refuses the record")
        val page = FakePage()
        val t = table(listOf("", "0.68", "పట్టా", "పుంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.equal("the row failed", r.state, RowState.FAILED)
        Check.equal("with the portal's own reason", r.code, Codes.SAVE_REFUSED)
        Check.that("a failure may be retried", r.state.retryable)
    }

    fun unansweredSave() {
        // The two silent cases are not the same thing, and telling them
        // apart is what stops a record going in twice.
        Check.group("Silent after Add, and the form emptied")
        val quiet = FakePage(saveAnswers = false, clearsOnSave = true)
        val t = table(listOf("1", "0.68", "పట్టా", "పుంజ"))
        val first = UvRunner(UiVision.compile(addRecordMacro()), quiet, t).runRow(0)
        Check.equal("an empty form is evidence, not proof, so a person looks",
            first.state, RowState.NEEDS_REVIEW)
        Check.equal("and it is recorded as a save we cannot vouch for",
            first.code, Codes.SAVE_UNKNOWN)
        Check.that("the app will not retry it itself", !first.state.retryable)
        Check.that("nor does its advice offer one", !Codes.of(first.code).mayRetry())
        Check.equal("Add was pressed once and once only", quiet.saves, 1)
        Check.that("a picture was kept", first.screenshot.isNotBlank())

        Check.group("Silent after Add, and the form still holds the record")
        val held = FakePage(saveAnswers = false, clearsOnSave = false)
        val second = UvRunner(UiVision.compile(addRecordMacro()), held, t).runRow(0)
        Check.equal("a form that kept the LPM means nothing went in",
            second.state, RowState.FAILED)
        Check.equal("so it is a refusal, which may be tried again",
            second.code, Codes.SAVE_REFUSED)
        Check.that("and a retry is honest here", second.state.retryable)
        Check.equal("Add was still pressed only once", held.saves, 1)
    }

    fun signedOut() {
        Check.group("Signed out in the middle of a run")
        val page = FakePage(signedOut = true)
        val t = table(listOf("1", "0.68", "పట్టా", "పుంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        val r = runner.runRow(0)
        Check.equal("the row stops", r.state, RowState.FAILED)
        Check.equal("saying the session went", r.code, Codes.SESSION_EXPIRED)
        Check.equal("which is fatal for the run",
            Codes.of(r.code).severity, Severity.FATAL)
    }

    fun conditions() {
        Check.group("if / else, and the columns UI.Vision would not read")
        val m = macro(
            UvCommand("store", "\${!COL5}", "flag"),
            UvCommand("if", "\${flag}==1"),
            UvCommand("type", "id=grAddRecord_txtwebsysno_0", "yes"),
            UvCommand("else"),
            UvCommand("type", "id=grAddRecord_txtwebsysno_0", "no"),
            UvCommand("endif"),
            UvCommand("type", "id=grAddRecord_txtwebsubno_0", "\${!COL21}"))
        val head = (1..21).map { "C$it" }
        val on = (1..20).map { "" } + listOf("twentyone")
        val rows = listOf(head,
            listOf("1", "", "", "", "1") + List(16) { "" },
            listOf("2", "", "", "", "0") + List(15) { "" } + listOf("twentyone"))
        val t = Table.of(rows)
        val program = UiVision.compile(m)
        Check.that("it compiles", program.mayRun())

        val page1 = FakePage()
        UvRunner(program, page1, t).runRow(0)
        Check.equal("the then-branch ran",
            page1.values["grAddRecord_txtwebsysno_0"], "yes")

        val page2 = FakePage()
        UvRunner(program, page2, t).runRow(1)
        Check.equal("the else-branch ran",
            page2.values["grAddRecord_txtwebsysno_0"], "no")
        Check.equal("and column 21 was read, which a laptop would refuse",
            page2.values["grAddRecord_txtwebsubno_0"], "twentyone")
        Check.that("the flag column is unused on this row", on.size == 21)
    }

    fun wholeRun() {
        Check.group("A run of several rows, with progress saved after each")
        val page = FakePage()
        val t = table(
            listOf("1", "0.68", "పట్టా", "పుంజ"),
            listOf("2", "0.5", "పట్టా", "నంజ"),
            listOf("", "0.25", "పట్టా", "పుంజ"),
            listOf("4", "1", "పట్టా", "పుంజ"))
        val saved = ArrayList<Int>()
        val results = UvRunner(UiVision.compile(addRecordMacro()), page, t)
            .run(1, 4) { r -> saved.add(r.rowNumber); true }
        Check.equal("four rows attempted", results.size, 4)
        Check.equal("three went in", results.count { it.state == RowState.SUCCESS }, 3)
        Check.equal("one failed", results.count { it.state == RowState.FAILED }, 1)
        Check.equal("progress was saved after every row", saved.size, 4)
        Check.equal("and the row numbers are the file's own lines",
            saved, listOf(2, 3, 4, 5))
        val tally = Tally.of(results, 4)
        Check.equal("nothing is left pending", tally.pending, 0)

        Check.group("Stopping")
        val stopAfter = intArrayOf(0)
        val stopped = UvRunner(UiVision.compile(addRecordMacro()), FakePage(), t,
            stopped = { stopAfter[0] >= 2 })
            .run(1, 4) { stopAfter[0]++; true }
        Check.equal("the run ends when the person says so", stopped.size, 2)

        Check.group("Asking to stop after one row")
        val one = UvRunner(UiVision.compile(addRecordMacro()), FakePage(), t)
            .run(1, 4) { false }
        Check.equal("only the first row ran", one.size, 1)
    }

    fun padding() {
        Check.group("Extents are typed exactly, never shortened")
        val page = FakePage()
        val t = table(listOf("1", "0.3333", "పట్టా", "పుంజ"))
        val runner = UvRunner(UiVision.compile(addRecordMacro()), page, t)
        runner.runRow(0)
        Check.equal("a fourth decimal goes in as it stands",
            page.values["grAddRecord_txtlpmnoExtent_0"], "0.3333")
        Check.that("and it is logged rather than silently shortened",
            page.logs.any { it.contains("more than 3 decimals") })

        val page2 = FakePage()
        UvRunner(UiVision.compile(addRecordMacro()), page2,
            table(listOf("1", "1", "పట్టా", "పుంజ"))).runRow(0)
        Check.equal("a whole number becomes 1.000",
            page2.values["grAddRecord_txtlpmnoExtent_0"], "1.000")
    }

    fun run() {
        oneGoodRow(); lateList(); stickyBox(); wordNotInTheList(); refusedSave()
        unansweredSave(); signedOut(); conditions(); wholeRun(); padding()
    }
}
