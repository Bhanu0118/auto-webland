package ap.webland.core.test

/**
 * The smallest test harness that does the job.
 *
 * There is no JUnit here on purpose: the core module has no
 * dependencies, so it compiles and its tests run with nothing but the
 * Kotlin compiler. `./gradlew :core:coreCheck` runs them, and so does
 *
 *     kotlinc core/src -d out && kotlin -cp out ap.webland.core.test.MainKt
 *
 * A test says what it expects in words, because a failure message that
 * reads "expected true" tells whoever sees it nothing.
 */
object Check {
    var passed = 0
    var failed = 0
    private val failures = ArrayList<String>()
    private var group = ""

    fun group(name: String) {
        group = name
        println("\n$name")
    }

    fun that(what: String, ok: Boolean, detail: String = "") {
        if (ok) {
            passed++
            println("  PASS  $what")
        } else {
            failed++
            val line = "$group / $what" + if (detail.isBlank()) "" else "  ($detail)"
            failures.add(line)
            println("  FAIL  $what" + if (detail.isBlank()) "" else "   <- $detail")
        }
    }

    fun equal(what: String, got: Any?, want: Any?) {
        that(what, got == want, "got <$got>, wanted <$want>")
    }

    fun threw(what: String, body: () -> Unit) {
        try {
            body()
            that(what, false, "nothing was thrown")
        } catch (e: Exception) {
            that(what, true)
        }
    }

    fun report(): Int {
        println("\n${passed + failed} checks: $passed passed, $failed failed")
        if (failures.isNotEmpty()) {
            println("\nWhat failed:")
            for (f in failures) println("  - $f")
        }
        return if (failed == 0) 0 else 1
    }
}
