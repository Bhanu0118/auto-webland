package ap.webland.core.test

import ap.webland.core.*

/**
 * The Add Record form built from the land-nature table, and played.
 *
 * The case that matters most is the last one: a word that this village's
 * dropdown does not have must leave the box empty, be noticed, and send
 * the record to the review list - never be quietly skipped.
 */
object AddFlowTest {

    private fun page(): FakePage = FakePage()

    fun builds() {
        Check.group("The form, built from one row of the table")
        val dry = AddFlow.build(Presets.byId("dry")!!)
        Check.that("it has steps", dry.live().size > 15)
        Check.equal("it saves once", dry.writes().size, 1)
        Check.equal("and the save is the Add button",
            dry.writes().first().target.id, "btnAdd")
        Check.equal("the columns it wants", dry.variables().sorted(),
            listOf("Extent", "Khata", "LPM", "Name", "Relation", "SubDiv", "SyNo"))
        Check.that("the save is followed by a wait for the portal's answer",
            dry.live().last().wait == Wait.SAVE_CONFIRMATION)

        Check.that("the dropdown words are literal, not out of the file",
            dry.live().filter { it.act == Act.SELECT }
                .none { it.value.contains("{{") })
        Check.equal("[7] Land Nature",
            dry.live().first { it.target.id == "grAddRecord_ddlLandNature1_0" }.value,
            "పట్టా")
        Check.equal("[8] Land Classification",
            dry.live().first {
                it.target.id == "grAddRecord_ddlLandClassification1_0"
            }.value, "పుంజ")
        Check.equal("[10A] Classification (Broad)",
            dry.live().first {
                it.target.id ==
                    "grAddRecord_ddlBroadCategory_LandCalssification1_0"
            }.value, "Dry")
        Check.equal("[10B] Classification (Sub)",
            dry.live().first {
                it.target.id == "grAddRecord_ddlSubCategory_LandClassification1_0"
            }.value, "-")
        Check.equal("[11] Nature of Land Use",
            dry.live().first { it.target.id == "grAddRecord_ddlnatureoflanduse_0" }
                .value, "Agriculture")
        Check.equal("[12] Source of Irrigation",
            dry.live().first { it.target.id == "grAddRecord_ddlSourceOfIrrigiAdd_0" }
                .value, "Minor")

        Check.group("A box a kind of land does not have is not touched at all")
        Check.that("dry land has no Land Nature (Sub)",
            dry.live().none {
                it.target.id == "grAddRecord_ddlSubCategory_LandNature1_0"
            })
        Check.that("nor a Sub A", dry.live().none {
            it.target.id == "grAddRecord_ddlSubCategory_LandNature1_SubA_0"
        })

        val dpatta = AddFlow.build(Presets.byId("dpatta")!!)
        Check.that("d-patta does have the Sub box", dpatta.live().any {
            it.target.id == "grAddRecord_ddlSubCategory_LandNature1_0" &&
                it.value == "Govt.Land Alloted"
        })
        Check.that("and Sub A", dpatta.live().any {
            it.target.id == "grAddRecord_ddlSubCategory_LandNature1_SubA_0" &&
                it.value == "Assigned (D-Patta)"
        })
        Check.that("and Sub B", dpatta.live().any {
            it.target.id == "grAddRecord_ddlSubCategory_LandNature1_SubB_0" &&
                it.value == "Agriculture"
        })
        Check.that("and its rights are Assignment", dpatta.live().any {
            it.target.id == "grAddRecord_ddlrightsreq_0" && it.value == "Assignment"
        })

        Check.group("Government land fills the enjoyer boxes, patta the pattadar")
        val burial = AddFlow.build(Presets.byId("burial")!!)
        Check.that("a burial ground fills the enjoyer name", burial.live().any {
            it.target.id == "grAddRecord_txtEnjoyerName_0"
        })
        Check.that("and not the pattadar name", burial.live().none {
            it.target.id == "grAddRecord_txtPattadarName_0"
        })
        Check.that("patta land fills both, the enjoyer being the same person",
            dry.live().any { it.target.id == "grAddRecord_txtPattadarName_0" } &&
                dry.live().any { it.target.id == "grAddRecord_txtEnjoyerName_0" })
        val alone = AddFlow.build(Presets.byId("dry")!!,
            enjoyerSameAsPattadar = false)
        Check.that("unless the office fills them differently", alone.live().none {
            it.target.id == "grAddRecord_txtEnjoyerName_0"
        })

        Check.group("The names are filled AFTER the khata lookup")
        val order = dry.live().map { it.target.id }
        Check.that("because the lookup rebuilds those boxes",
            order.indexOf("grAddRecord_btnKhata_0") <
                order.indexOf("grAddRecord_txtPattadarName_0"))

        Check.group("What the chain will put in the boxes, shown first")
        val chain = AddFlow.chain(Presets.byId("wet")!!)
        Check.that("every box is named with its word",
            chain.any { it.first == "Land Classification" && it.second == "నంజ" })
        Check.that("including the holder",
            chain.any { it.first == "Holder boxes" && it.second == "Pattadar" })
    }

    fun plays() {
        Check.group("Entering one record with it")
        val p = page()
        val t = AddFlow.oneRow("1", "0.68", "212", "212-4", "222",
            "యరింజల సుబ్బమ్మ", "యరింజల")
        val r = BwaRunner(AddFlow.build(Presets.byId("dry")!!), p, t).runRow(0)
        Check.equal("the record went in", r.state, RowState.SUCCESS)
        Check.equal("the extent was padded to three decimals",
            p.values["grAddRecord_txtlpmnoExtent_0"], "0.680")
        Check.equal("the land nature came from the table",
            p.chosen["grAddRecord_ddlLandNature1_0"], "పట్టా")
        Check.equal("the classification too",
            p.chosen["grAddRecord_ddlLandClassification1_0"], "పుంజ")
        Check.equal("the survey number came from the row",
            p.values["grAddRecord_txtwebsysno_0"], "212")
        Check.equal("so did the khata", p.values["grAddRecord_txtkhatano_0"], "222")
        Check.equal("Add was pressed once", p.saves, 1)

        Check.group("A word this village's dropdown has not got")
        // The fake page's Classification list has పుంజ and నంజ but not
        // మెట్ట, which is what another village calls the same land.
        val other = Presets.byId("dry")!!.copy(classification = "మెట్ట")
        val p2 = page()
        val runner = BwaRunner(AddFlow.build(other), p2, t)
        val r2 = runner.runRow(0)
        Check.that("the box is left empty rather than set to something near it",
            p2.chosen["grAddRecord_ddlLandClassification1_0"] == null)
        Check.that("the miss is written down", runner.misses.any {
            it.wanted == "మెట్ట"
        })
        Check.equal("and the record is for a person to look at",
            r2.state, RowState.NEEDS_REVIEW)
        Check.equal("named as a box that did not match",
            r2.code, Codes.FIELD_MISMATCH)
        Check.that("which is not retried by the app", !r2.state.retryable)
    }

    fun everyPreset() {
        Check.group("All 32 kinds of land build a form that could be run")
        var worst = ""
        var bad = 0
        for (preset in Presets.ALL) {
            val auto = AddFlow.build(preset)
            val findings = Validate.check(auto,
                Table.of(listOf(AddFlow.NEEDS, List(AddFlow.NEEDS.size) { "x" })),
                browserOpen = true)
            if (!Validate.mayRun(findings)) {
                bad++
                worst = preset.id + ": " +
                    findings.first { it.level == Level.STOP }.title
            }
        }
        Check.that("not one of them is refused before it starts", bad == 0, worst)
        Check.equal("and every one saves exactly once",
            Presets.ALL.count { AddFlow.build(it).writes().size != 1 }, 0)
    }

    fun run() {
        builds(); plays(); everyPreset()
    }
}
