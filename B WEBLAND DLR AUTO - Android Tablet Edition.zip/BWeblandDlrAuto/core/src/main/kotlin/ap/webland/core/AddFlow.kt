package ap.webland.core

/**
 * The Add Record form, built from the land-nature table.
 *
 * This is what makes the tablet useful on its own. A recorded macro is
 * one way to fill the form; the other is to know what the form is, which
 * the Windows application does and which is carried over here. Choose
 * the kind of land, and every one of the twelve boxes from Land Nature
 * to Source of Irrigation is filled with the word that row of the table
 * says - not a word out of a spreadsheet column.
 *
 * That distinction cost real work to learn. A classification written in
 * one village's adangal is not the word another village's dropdown has,
 * so a macro that reads the chain out of the file enters nothing at all
 * in the second village and says nothing about it. The words here come
 * from the table the office itself uses, and when one of them is not in
 * the portal's list the runner reads the box back, sees it empty, and
 * the record is marked for a person instead of being saved wrong.
 *
 * Only the record's own values - LPM, extent, survey number, khata, the
 * pattadar's name - come from the file.
 */
object AddFlow {

    const val LPM = "LPM"
    const val EXTENT = "Extent"
    const val SYNO = "SyNo"
    const val SUBDIV = "SubDiv"
    const val KHATA = "Khata"
    const val NAME = "Name"
    const val RELATION = "Relation"

    /** The columns this flow asks a file for. */
    val NEEDS = listOf(LPM, EXTENT, SYNO, SUBDIV, KHATA, NAME, RELATION)

    private fun id(key: String): String = PortalFields.ADD[key] ?: ""

    private fun type(key: String, value: String, label: String): Step =
        Step(
            act = Act.TYPE,
            target = Target(mapOf("id" to id(key), "label" to label)),
            value = value,
            wait = Wait.VISIBLE,
            timeoutMs = 15_000)

    private fun choose(key: String, value: String, label: String): Step =
        Step(
            act = Act.SELECT,
            target = Target(mapOf("id" to id(key), "label" to label)),
            value = value,
            wait = Wait.VISIBLE,
            timeoutMs = 20_000)

    private fun click(key: String, label: String, meaning: Meaning = Meaning.NONE): Step =
        Step(
            act = Act.CLICK,
            target = Target(mapOf("id" to id(key), "label" to label)),
            meaning = meaning,
            wait = if (meaning.writes) Wait.SAVE_CONFIRMATION else Wait.VISIBLE,
            timeoutMs = if (meaning.writes) 45_000 else 15_000)

    /**
     * One recording that enters any record of this kind of land.
     *
     * `enjoyerSameAsPattadar` follows the Windows application's own
     * setting: on a patta record the enjoyer is normally the same person,
     * so those boxes take the same values. Where an office fills them
     * differently, this is turned off and the portal asks for them.
     */
    fun build(
        preset: LandPreset,
        enjoyerSameAsPattadar: Boolean = true,
        pdfPath: String = "",
    ): Automation {
        val auto = Automation("Add - ${preset.en}")
        auto.startUrl = PortalWords.START_URL
        auto.beginner = true

        auto.add(Step(
            act = Act.CLICK,
            target = Target(mapOf("text" to (PortalFields.ADD["add_link"] ?: "Add Record"),
                "label" to "Add Record")),
            meaning = Meaning.NONE,
            wait = Wait.VISIBLE,
            timeoutMs = 20_000))

        // ---- the record's own numbers
        auto.add(type("lpm", "{{$LPM}}", "LPM No"))
        auto.add(type("lpm_extent", "{{$EXTENT}}", "LPM Extent"))
        auto.add(type("total_extent", "{{$EXTENT}}", "Total Extent"))
        auto.add(type("syno", "{{$SYNO}}", "Web Survey No"))
        auto.add(type("subdiv", "{{$SUBDIV}}", "Web Sub Division No"))

        // ---- boxes 7 to 12: the words come from the table, not the file
        auto.add(choose("nature", preset.nature, "Land Nature"))
        auto.add(choose("classification", preset.classification,
            "Land Classification"))
        auto.add(choose("bnature", preset.broadNature, "Land Nature (Broad)"))
        if (preset.subNature.isNotBlank()) {
            auto.add(choose("snature", preset.subNature, "Land Nature (Sub)"))
        }
        if (preset.subNatureA.isNotBlank()) {
            auto.add(choose("snature_a", preset.subNatureA, "Land Nature (Sub A)"))
        }
        if (preset.subNatureB.isNotBlank()) {
            auto.add(choose("snature_b", preset.subNatureB, "Land Nature (Sub B)"))
        }
        auto.add(choose("bclass", preset.broadClass,
            "Land Classification (Broad)"))
        if (preset.subClass.isNotBlank()) {
            auto.add(choose("sclass", preset.subClass,
                "Land Classification (Sub)"))
        }
        if (preset.subClassA.isNotBlank()) {
            auto.add(choose("sclass_a", preset.subClassA,
                "Land Classification (Sub A)"))
        }
        if (preset.subClassText.isNotBlank()) {
            auto.add(type("sclass_text", preset.subClassText,
                "Land Classification (text)"))
        }
        auto.add(choose("land_use", preset.landUse, "Nature of Land Use"))
        auto.add(choose("irrigation", preset.irrigation, "Source of Irrigation"))

        // ---- the khata, and the lookup that rebuilds the name boxes
        // ---- the holder. The lookup clears these, so they come last.
        val holderIsEnjoyer = preset.holder == "E"

        auto.add(type("khata", "{{$KHATA}}", "Khata No"))
        auto.add(click("khata_btn", "Khata lookup"))
        auto.add(Step(
            act = Act.WAIT,
            target = Target(mapOf(
                "id" to id(if (holderIsEnjoyer) "enj_name" else "pat_name"))),
            wait = Wait.VISIBLE,
            timeoutMs = 25_000,
            note = "the lookup rebuilds the name boxes, so they are filled after it"))

        if (holderIsEnjoyer) {
            auto.add(type("enj_name", "{{$NAME}}", "Enjoyer Name"))
            auto.add(type("enj_fname", "{{$RELATION}}", "Enjoyer Relation"))
            auto.add(type("enj_extent", "{{$EXTENT}}", "Enjoyer Extent"))
        } else {
            auto.add(type("pat_name", "{{$NAME}}", "Pattadar Name"))
            auto.add(type("pat_fname", "{{$RELATION}}", "Pattadar Relation"))
            auto.add(type("pat_extent", "{{$EXTENT}}", "Pattadar Extent"))
            if (enjoyerSameAsPattadar) {
                auto.add(type("enj_name", "{{$NAME}}", "Enjoyer Name"))
                auto.add(type("enj_fname", "{{$RELATION}}", "Enjoyer Relation"))
                auto.add(type("enj_extent", "{{$EXTENT}}", "Enjoyer Extent"))
            }
        }

        if (preset.rights.isNotBlank()) {
            auto.add(choose("rights", preset.rights, "Rights as per ROR"))
        }
        auto.add(choose("action", preset.action, "Action requested"))

        // Joint cultivation: one khatadar's name goes in and this says
        // No, which is the office's practice; the change-later report
        // lists every joint record so none is forgotten.
        auto.add(Step(
            act = Act.CHECK,
            target = Target(mapOf("id" to id("joint_no"),
                "label" to "Joint Cultivation No")),
            wait = Wait.VISIBLE,
            timeoutMs = 10_000))

        if (pdfPath.isNotBlank()) {
            auto.add(Step(
                act = Act.UPLOAD,
                target = Target(mapOf("id" to "filetahsil", "label" to "Attach PDF")),
                value = pdfPath,
                optional = true,
                note = "chosen on the Run page"))
        }

        auto.add(click("add_btn", "Add", Meaning.ADD))
        auto.add(Step(
            act = Act.WAIT,
            wait = Wait.SAVE_CONFIRMATION,
            timeoutMs = 45_000,
            note = "wait for the portal to say what it did with the record"))

        for (name in NEEDS) auto.mapping[name] = name
        return auto
    }

    /**
     * Which boxes this flow will fill, in order, for showing on screen
     * before anything is entered. The surveyor can then see that [8] is
     * going to say "పుంజ" and stop if that is not what this village
     * calls it.
     */
    fun chain(preset: LandPreset): List<Pair<String, String>> = listOfNotNull(
        "Land Nature" to preset.nature,
        "Land Classification" to preset.classification,
        "Land Nature (Broad)" to preset.broadNature,
        preset.subNature.ifBlank { null }?.let { "Land Nature (Sub)" to it },
        preset.subNatureA.ifBlank { null }?.let { "Land Nature (Sub A)" to it },
        preset.subNatureB.ifBlank { null }?.let { "Land Nature (Sub B)" to it },
        "Land Classification (Broad)" to preset.broadClass,
        preset.subClass.ifBlank { null }?.let { "Land Classification (Sub)" to it },
        preset.subClassA.ifBlank { null }?.let { "Land Classification (Sub A)" to it },
        preset.subClassText.ifBlank { null }?.let {
            "Land Classification (text)" to it
        },
        "Nature of Land Use" to preset.landUse,
        "Source of Irrigation" to preset.irrigation,
        preset.rights.ifBlank { null }?.let { "Rights as per ROR" to it },
        "Action requested" to preset.action,
        "Holder boxes" to if (preset.holder == "E") "Enjoyer" else "Pattadar",
    )

    /** A one-record table, for entering something typed on the screen. */
    fun oneRow(
        lpm: String, extent: String, syno: String, subdiv: String,
        khata: String, name: String, relation: String, lineNumber: Int = 2,
    ): Table = Table(
        columns = NEEDS,
        rows = listOf(mapOf(
            LPM to lpm, EXTENT to extent, SYNO to syno, SUBDIV to subdiv,
            KHATA to khata, NAME to name, RELATION to relation)),
        sheetName = "one record",
        lineNumbers = listOf(lineNumber))
}
