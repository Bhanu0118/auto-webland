package ap.webland.core

/**
 * Reading a KML, a GeoJSON or a shapefile's attribute table, for one
 * purpose only: correlating what the map says with what the DLR says.
 *
 * The constraint that shapes this whole file is in the master prompt and
 * it is not negotiable: when the task is attribute correlation, the
 * geometry is not touched. No coordinate is moved, no polygon is split
 * or merged, no feature is added or dropped. A resurvey KML that has
 * been closed and approved must come out of this app byte for byte as it
 * went in, because shifting one boundary to tidy an attribute creates an
 * overlap or a gap that nobody will find until two farmers disagree.
 *
 * So everything here is READ-ONLY. A feature's geometry is kept as the
 * text it arrived as, carried around but never parsed into something the
 * app could accidentally rewrite. What this module produces is a list of
 * attributes, and a report of where they disagree with the DLR.
 */

/** One feature, with its attributes read and its geometry left alone. */
data class Parcel(
    val name: String,
    val attributes: Map<String, String>,
    /** exactly as it appeared in the file; never edited, never rewritten */
    val geometryRaw: String = "",
    val ringCount: Int = 0,
) {
    fun value(vararg keys: String): String {
        for (k in keys) {
            attributes.entries.firstOrNull {
                Headings.tidy(it.key) == Headings.tidy(k)
            }?.let { if (it.value.isNotBlank()) return it.value.trim() }
        }
        return ""
    }

    val surveyNo: String get() = value("survey", "sy no", "syno", "survey no", "sno")
    val subDivision: String get() = value("subdiv", "sub division", "subdivision", "sub")
    val lpm: String get() = value("lpm", "lpmno", "lpm no")
    val extent: String get() = value("extent", "area", "ac", "acres")
}

object Kml {
    private val PLACEMARK = Regex("<Placemark\\b[\\s\\S]*?</Placemark>",
        RegexOption.IGNORE_CASE)
    private val NAME = Regex("<name\\b[^>]*>([\\s\\S]*?)</name>",
        RegexOption.IGNORE_CASE)
    private val SIMPLE = Regex(
        "<SimpleData\\s+name=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</SimpleData>",
        RegexOption.IGNORE_CASE)
    private val DATA = Regex(
        "<Data\\s+name=\"([^\"]+)\"[^>]*>[\\s\\S]*?<value>([\\s\\S]*?)</value>[\\s\\S]*?</Data>",
        RegexOption.IGNORE_CASE)
    private val RING = Regex("<coordinates\\b", RegexOption.IGNORE_CASE)
    private val GEOM = Regex(
        "<(Polygon|LineString|Point|MultiGeometry)\\b[\\s\\S]*?</\\1>",
        RegexOption.IGNORE_CASE)

    /** Every placemark's attributes. Geometry is copied, not interpreted. */
    fun read(text: String): List<Parcel> {
        val out = ArrayList<Parcel>()
        for (m in PLACEMARK.findAll(text)) {
            val block = m.value
            val attrs = LinkedHashMap<String, String>()
            for (d in SIMPLE.findAll(block)) attrs[d.groupValues[1]] = clean(d.groupValues[2])
            for (d in DATA.findAll(block)) attrs[d.groupValues[1]] = clean(d.groupValues[2])
            val name = NAME.find(block)?.groupValues?.get(1)?.let { clean(it) } ?: ""
            val geom = GEOM.find(block)?.value ?: ""
            out.add(Parcel(name, attrs, geom, RING.findAll(block).count()))
        }
        return out
    }

    private fun clean(raw: String): String =
        raw.replace("<![CDATA[", "").replace("]]>", "")
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&apos;", "'")
            .trim()
}

object GeoJson {
    /** Every feature's properties. The geometry object is not altered. */
    fun read(text: String): List<Parcel> {
        val root = Json.parse(text)
        val features = root.arr("features")
        val out = ArrayList<Parcel>(features.size)
        for (f in features) {
            if (f !is Json.Obj) continue
            val props = LinkedHashMap<String, String>()
            (f.obj("properties") as? Json.Obj)?.fields?.forEach { (k, v) ->
                props[k] = when (v) {
                    is Json.Str -> v.value
                    is Json.Num -> Json.numberText(v.value)
                    is Json.Bool -> v.value.toString()
                    else -> ""
                }
            }
            val geom = f["geometry"]
            val rings = countRings(geom)
            out.add(Parcel(props["name"] ?: "", props,
                if (geom == null) "" else Json.write(geom, 0), rings))
        }
        return out
    }

    private fun countRings(g: Json?): Int {
        val coords = g?.get("coordinates") as? Json.Arr ?: return 0
        return when (g.str("type").lowercase()) {
            "polygon" -> coords.items.size
            "multipolygon" -> coords.items.sumOf { (it as? Json.Arr)?.items?.size ?: 0 }
            else -> 1
        }
    }
}

/**
 * A shapefile's attribute table (.dbf), which is all this app reads of a
 * shapefile. The .shp beside it holds the geometry and is not opened,
 * which is the simplest possible guarantee that nothing moves it.
 */
object Dbf {
    data class Field(val name: String, val type: Char, val length: Int)

    data class Result(
        val fields: List<Field>,
        val rows: List<Map<String, String>>,
        val deleted: Int,
    )

    fun read(bytes: ByteArray): Result {
        if (bytes.size < 32) throw JsonError("That .dbf file is too short to read.")
        val headerLength = u16(bytes, 8)
        val recordLength = u16(bytes, 10)
        val recordCount = u32(bytes, 4)
        if (headerLength < 33 || recordLength < 1)
            throw JsonError("That .dbf file's header does not make sense.")

        val fields = ArrayList<Field>()
        var at = 32
        while (at + 32 <= headerLength - 1 && bytes[at] != 0x0D.toByte()) {
            val name = String(bytes, at, 11, Charsets.ISO_8859_1)
                .trimEnd('\u0000', ' ')
            val type = bytes[at + 11].toInt().toChar()
            val length = bytes[at + 16].toInt() and 0xFF
            if (name.isNotEmpty()) fields.add(Field(name, type, length))
            at += 32
        }

        val rows = ArrayList<Map<String, String>>()
        var deleted = 0
        var offset = headerLength
        for (n in 0 until recordCount) {
            if (offset + recordLength > bytes.size) break
            val flag = bytes[offset].toInt().toChar()
            var p = offset + 1
            val row = LinkedHashMap<String, String>()
            for (f in fields) {
                if (p + f.length > bytes.size) break
                val raw = String(bytes, p, f.length, Charsets.UTF_8).trim()
                row[f.name] = raw
                p += f.length
            }
            if (flag == '*') deleted++ else rows.add(row)
            offset += recordLength
        }
        return Result(fields, rows, deleted)
    }

    private fun u16(b: ByteArray, at: Int): Int =
        (b[at].toInt() and 0xFF) or ((b[at + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, at: Int): Int =
        (b[at].toInt() and 0xFF) or ((b[at + 1].toInt() and 0xFF) shl 8) or
            ((b[at + 2].toInt() and 0xFF) shl 16) or
            ((b[at + 3].toInt() and 0xFF) shl 24)
}

/** Matching the map to the register, and saying how sure the match is. */
object Correlate {

    data class Pair(
        val rowNumber: Int,
        val surveyNo: String,
        val subDivision: String,
        val lpm: String,
        val dlrExtent: String,
        val mapExtent: String,
        val confidence: Confidence,
        val why: String,
    ) {
        val variation: Double? get() = Extent.variation(dlrExtent, mapExtent)
        val needsReview: Boolean get() = confidence != Confidence.CERTAIN
    }

    enum class Confidence { CERTAIN, LIKELY, UNCERTAIN, NONE }

    /**
     * One pair per DLR record. A record with no parcel is reported as
     * such rather than left out, and nothing is matched on a guess: a
     * survey number that appears twice in the map is UNCERTAIN, for a
     * person to settle.
     */
    fun match(
        records: List<Khata.GovtRow>,
        parcels: List<Parcel>,
        dlrExtentOf: (Int) -> String = { "" },
        tolerance: Double = 0.02,
    ): List<Pair> {
        val bySurveySub = HashMap<String, MutableList<Parcel>>()
        val byLpm = HashMap<String, MutableList<Parcel>>()
        for (p in parcels) {
            val key = p.surveyNo.trim() + "/" + p.subDivision.trim()
            bySurveySub.getOrPut(key) { ArrayList() }.add(p)
            if (p.lpm.isNotBlank()) byLpm.getOrPut(p.lpm.trim()) { ArrayList() }.add(p)
        }
        val out = ArrayList<Pair>(records.size)
        for (r in records) {
            val dlr = dlrExtentOf(r.rowNumber)
            val onLpm = byLpm[r.lpm.trim()].orEmpty()
            val onSurvey = bySurveySub[r.surveyNo.trim() + "/" + r.subDivision.trim()]
                .orEmpty()
            val (hit, confidence, why) = when {
                onLpm.size == 1 -> Triple(onLpm[0], Confidence.CERTAIN,
                    "the LPM number is in the map once")
                onSurvey.size == 1 -> Triple(onSurvey[0], Confidence.LIKELY,
                    "matched on survey number and subdivision")
                onLpm.size > 1 -> Triple(onLpm[0], Confidence.UNCERTAIN,
                    "the LPM number appears ${onLpm.size} times in the map")
                onSurvey.size > 1 -> Triple(onSurvey[0], Confidence.UNCERTAIN,
                    "that survey number and subdivision appear " +
                        "${onSurvey.size} times")
                else -> Triple(null, Confidence.NONE,
                    "nothing in the map has that survey number")
            }
            val mapExtent = hit?.extent ?: ""
            var level = confidence
            val gap = Extent.variation(dlr, mapExtent)
            val note = if (gap != null && Math.abs(gap) > tolerance) {
                if (level == Confidence.CERTAIN) level = Confidence.LIKELY
                why + "; the extents differ by %.1f%%".format(gap * 100)
            } else why
            out.add(Pair(r.rowNumber, r.surveyNo, r.subDivision, r.lpm,
                dlr, mapExtent, level, note))
        }
        return out
    }

    /** What a correlation run amounts to, for the top of the report. */
    fun summary(pairs: List<Pair>): List<Finding> {
        val out = ArrayList<Finding>()
        val none = pairs.filter { it.confidence == Confidence.NONE }
        val unsure = pairs.filter { it.confidence == Confidence.UNCERTAIN }
        val certain = pairs.count { it.confidence == Confidence.CERTAIN }
        out.add(Finding(Level.NOTE, "correlation",
            "$certain of ${pairs.size} records matched one parcel exactly"))
        if (unsure.isNotEmpty()) {
            out.add(Finding(Level.WARN, "correlation",
                "${unsure.size} records matched more than one parcel",
                "these are kept in the review list and nothing is written",
                rows = unsure.map { it.rowNumber }))
        }
        if (none.isNotEmpty()) {
            out.add(Finding(Level.WARN, "correlation",
                "${none.size} records have no parcel in the map",
                rows = none.map { it.rowNumber }))
        }
        out.add(Finding(Level.NOTE, "geometry",
            "No coordinate was read, changed or written",
            "this app reads attributes only; the geometry in the file is " +
                "left exactly as it is"))
        return out
    }
}
