package ap.webland.core

/**
 * Khata numbers and pattadar names.
 *
 * Two rules here have already cost real work to get right, so they are
 * written down once and used everywhere:
 *
 * A NOTIONAL khata is a long number that begins with 10. Those are the
 * placeholder khatas a resurvey throws up and they do not belong in a
 * DLR run. A number beginning 2000 is a GOVERNMENT khata and is exactly
 * right for government land - an earlier version treated every long
 * khata as notional and pulled 134 government records out of a run.
 *
 * Names are merged only when the relationship matches too. "దాటి అప్పన్న"
 * in two rows is one person if the father's name agrees and two people if
 * it does not, and a register that merges them is wrong in a way nobody
 * can see afterwards.
 */
object Khata {

    /** A long khata beginning with 10: a resurvey placeholder. */
    fun isNotional(khata: String?): Boolean {
        val k = (khata ?: "").trim()
        return k.length >= 6 && k.all { it.isDigit() } && k.startsWith("10")
    }

    /** A government khata - 2000xxxx. Correct for government land. */
    fun isGovernment(khata: String?): Boolean {
        val k = (khata ?: "").trim()
        return k.length >= 6 && k.all { it.isDigit() } && k.startsWith("2000")
    }

    fun isBlank(khata: String?): Boolean = (khata ?: "").trim().isEmpty()

    /** An ordinary village khata: not notional, not government, not empty. */
    fun isOrdinary(khata: String?): Boolean =
        !isBlank(khata) && !isNotional(khata) && !isGovernment(khata)

    /**
     * Khata numbers to use for records that have none, carrying on from
     * the highest ordinary khata already in the village.
     *
     * Nothing is written into a record here. The caller gets the numbers
     * and shows them for approval, because a khata number invented by a
     * program and accepted without a look is a khata number nobody can
     * account for later.
     */
    fun nextNumbers(existing: Collection<String>, howMany: Int): List<String> {
        val used = existing.mapNotNull { it.trim().toIntOrNull() }.toMutableSet()
        val ordinary = existing.filter { isOrdinary(it) }
            .mapNotNull { it.trim().toIntOrNull() }
        var n = (ordinary.maxOrNull() ?: 0)
        val out = ArrayList<String>(howMany)
        while (out.size < howMany) {
            n++
            if (n in used) continue              // never a duplicate
            used.add(n)
            out.add(n.toString())
        }
        return out
    }

    /** Every khata used more than once, with the rows that use it. */
    fun duplicates(rows: List<DlrRecord>): Map<String, List<Int>> {
        val by = LinkedHashMap<String, MutableList<Int>>()
        for (r in rows) {
            val k = r.khata.trim()
            if (k.isEmpty()) continue
            by.getOrPut(k) { ArrayList() }.add(r.rowNumber)
        }
        return by.filterValues { it.size > 1 }
    }

    // ------------------------------------------------------------- names
    /** A name with its spacing tidied, for comparison only. */
    fun tidy(name: String?): String =
        (name ?: "").trim().split(Regex("\\s+")).joinToString(" ")

    fun sameName(a: String?, b: String?): Boolean =
        tidy(a).isNotEmpty() && tidy(a) == tidy(b)

    /**
     * May these two rows be treated as the same person?
     *
     * Only when the name agrees AND the relationship agrees. A blank
     * relationship on either side is not agreement - it is the absence
     * of it, so the answer is no.
     */
    fun samePerson(
        nameA: String?, relationA: String?,
        nameB: String?, relationB: String?,
    ): Boolean {
        if (!sameName(nameA, nameB)) return false
        val ra = tidy(relationA)
        val rb = tidy(relationB)
        if (ra.isEmpty() || rb.isEmpty()) return false
        return ra == rb
    }

    /**
     * One display name for a joint cultivation, with the others kept.
     *
     * The portal takes one name per record. The office's practice is to
     * enter the first khatadar and mark joint cultivation as "No", then
     * correct it afterwards - so this returns the name to enter and the
     * full list to put in the change-later report. Nothing is thrown
     * away.
     */
    data class Joint(val enter: String, val all: List<String>) {
        val isJoint: Boolean get() = all.size > 1
        fun report(): String = all.joinToString(" / ")
    }

    fun joint(names: List<String>): Joint {
        val clean = names.map { tidy(it) }.filter { it.isNotEmpty() }
        return Joint(clean.firstOrNull() ?: "", clean)
    }

    // ------------------------------- government land: one LPM per survey
    /**
     * The sheet asks for one LPM per survey number / subdivision on
     * government land. This reports where that is not so; it does not
     * merge anything.
     */
    fun govtLpmClashes(
        rows: List<GovtRow>,
    ): Map<String, List<Int>> {
        val by = LinkedHashMap<String, MutableList<Int>>()
        for (r in rows) {
            val key = r.surveyNo.trim() + " / " + r.subDivision.trim()
            by.getOrPut(key) { ArrayList() }.add(r.rowNumber)
        }
        return by.filterValues { it.size > 1 }
    }

    data class GovtRow(
        val rowNumber: Int,
        val surveyNo: String,
        val subDivision: String,
        val lpm: String,
    )

    // ----------------------------------------------------------- findings
    /** What the khata column says about a file, in the usual shape. */
    fun check(rows: List<DlrRecord>): List<Finding> {
        val out = ArrayList<Finding>()
        if (rows.isEmpty()) return out

        val notional = rows.filter { isNotional(it.khata) }.map { it.rowNumber }
        if (notional.isNotEmpty()) {
            out.add(Finding(
                Level.WARN, "khata",
                "${notional.size} record(s) still carry a notional khata",
                "a long khata beginning with 10 is a resurvey placeholder, " +
                    "not a khata the register can keep",
                rows = notional,
                fix = "Put the real khata in, or take these rows out of the " +
                    "run. The app will not change a khata number itself."))
        }

        val blank = rows.filter { isBlank(it.khata) }.map { it.rowNumber }
        if (blank.isNotEmpty()) {
            out.add(Finding(
                Level.WARN, "khata",
                "${blank.size} record(s) have no khata number",
                rows = blank,
                fix = "The Khata page can suggest numbers carrying on from " +
                    "the last one in the village, for you to approve."))
        }

        val govt = rows.count { isGovernment(it.khata) }
        if (govt > 0) {
            out.add(Finding(
                Level.NOTE, "khata",
                "$govt record(s) use a government khata (2000…)",
                "those are correct for government land and stay in the run"))
        }

        val dup = duplicates(rows)
        if (dup.isNotEmpty()) {
            val shown = dup.keys.take(4).joinToString(", ")
            out.add(Finding(
                Level.NOTE, "khata",
                "${dup.size} khata number(s) appear in more than one record",
                "which is ordinary where one khatadar holds several plots " +
                    "($shown…)",
                rows = dup.values.flatten().sorted()))
        }
        return out
    }
}
