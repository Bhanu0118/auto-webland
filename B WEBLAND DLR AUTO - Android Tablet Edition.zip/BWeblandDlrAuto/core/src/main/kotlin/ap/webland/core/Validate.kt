package ap.webland.core

/**
 * The questions asked BEFORE anything is played.
 *
 * Everything here could be discovered by simply running the automation
 * and watching it go wrong. The reason not to is arithmetic: a recording
 * that is missing one column mapping does not fail on row one - it
 * succeeds on row one with a blank in it, and on row two, and on row
 * eight hundred. By the time anybody notices, the portal holds eight
 * hundred wrong records and there is no undo.
 *
 * So the checks run first, they run on the whole recording, and one kind
 * of problem stops the run outright rather than warning about it. The
 * rule for deciding which: if the automation would RUN and produce
 * something wrong, it is a STOP. If it would fail visibly, it is a WARN,
 * because a visible failure is its own report.
 *
 * Ported from recorder/validate.py.
 */
object Validate {

    /** Everything worth knowing before pressing Play on a .bwa recording. */
    fun check(
        auto: Automation,
        table: Table? = null,
        browserOpen: Boolean = true,
        passwordGiven: Boolean = false,
    ): List<Finding> {
        val found = ArrayList<Finding>()
        val live = auto.live()

        if (live.isEmpty()) {
            found.add(Finding(Level.STOP, "steps", "There are no steps to play",
                "every step is switched off, or nothing was recorded",
                fix = "Record something first."))
        } else {
            found.add(Finding(Level.NOTE, "steps", "${live.size} steps"))
        }
        val off = auto.steps.size - live.size
        if (off > 0) found.add(Finding(Level.NOTE, "steps",
            "$off steps are switched off"))

        for (step in live) {
            if (step.act.needsTarget && step.target.isEmpty) {
                found.add(Finding(Level.STOP, "steps",
                    "Step ${step.id} does not say which box it means",
                    step.describe(), fix = "Delete this step, or record it again."))
                continue
            }
            if (step.act.needsTarget) {
                val (word, why) = step.target.strength()
                if (word == "none") {
                    found.add(Finding(Level.STOP, "steps",
                        "Step ${step.id} cannot find its box", why,
                        fix = "Record this step again."))
                } else if (word == "weak") {
                    found.add(Finding(Level.WARN, "steps",
                        "Step ${step.id} is identified only by position", why,
                        fix = "It will probably work, but re-record it if it fails."))
                }
            }
            if (step.act == Act.WAIT && step.wait == Wait.SECONDS) {
                found.add(Finding(Level.WARN, "steps",
                    "Step ${step.id} waits a fixed time",
                    "a fixed wait is too long on a fast day and too short on a " +
                        "slow one",
                    fix = "Change it to wait for the page or for the save."))
            }
            if (step.timeoutMs < 3_000) {
                found.add(Finding(Level.WARN, "steps",
                    "Step ${step.id} gives up after " +
                        "%.1f seconds".format(step.timeoutMs / 1000.0),
                    fix = "The portal is often slower than that."))
            }
        }

        // duplicated steps, which usually means a double click was recorded
        val seen = HashMap<String, String>()
        for (step in live) {
            val key = listOf(step.act.key, step.meaning.key,
                step.target.id.ifBlank { step.label() }, step.value).joinToString("|")
            val before = seen[key]
            if (before != null && (step.act == Act.CLICK || step.act == Act.TYPE)) {
                found.add(Finding(Level.WARN, "steps",
                    "Step ${step.id} looks like a repeat of $before",
                    step.describe(),
                    fix = "Delete one of them if it was recorded twice."))
            }
            seen[key] = step.id
        }

        // a recording that saves more than once per row is worth a word
        val writes = auto.writes()
        when {
            writes.size > 1 -> found.add(Finding(Level.WARN, "save",
                "This saves ${writes.size} times in one row",
                "each one makes a record in the portal",
                fix = "Check that is really what you want before running the " +
                    "whole file."))
            writes.size == 1 -> found.add(Finding(Level.NOTE, "save",
                "Saves once per row"))
            else -> found.add(Finding(Level.NOTE, "save",
                "Nothing in this recording saves anything",
                "it fills the form but never presses Save or Add"))
        }

        // a save with nothing waiting on it cannot be verified
        live.forEachIndexed { i, step ->
            if (step.meaning.writes) {
                val after = live.getOrNull(i + 1)
                if (after == null || after.act != Act.WAIT) {
                    found.add(Finding(Level.WARN, "save",
                        "Step ${step.id} saves and does not wait for an answer",
                        "without a wait, the next row starts before the portal " +
                            "has replied and nothing can be verified",
                        fix = "Add a 'wait for the save confirmation' after it."))
                }
            }
        }

        found.addAll(data(auto.variables(), auto.mapping, table))

        // ---- the secrets
        val needs = live.filter { it.secret }
        if (needs.isNotEmpty()) {
            if (!passwordGiven) {
                found.add(Finding(Level.STOP, "password",
                    "This recording types a password",
                    "the password was never recorded, so it has to be given " +
                        "for this run",
                    fix = "Type it into the box on the Play page."))
            } else {
                found.add(Finding(Level.NOTE, "password",
                    "A password will be supplied for this run and not saved " +
                        "anywhere"))
            }
        }

        if (!browserOpen) {
            found.add(Finding(Level.STOP, "browser", "The portal page is not open",
                fix = "Open the portal and sign in on the Run page first."))
        } else {
            found.add(Finding(Level.NOTE, "browser", "The portal page is open"))
        }

        for (note in auto.trouble.take(5)) {
            found.add(Finding(Level.WARN, "file", "When this was opened: $note"))
        }
        return found
    }

    /** The same questions for a UI.Vision macro and its CSV. */
    fun check(program: UvProgram, table: Table?, browserOpen: Boolean = true):
        List<Finding> {
        val found = ArrayList<Finding>(program.notes)
        if (program.steps.isEmpty()) {
            found.add(Finding(Level.STOP, "steps", "That macro has no steps in it"))
        } else {
            found.add(Finding(Level.NOTE, "steps",
                "${program.steps.size} commands, ${program.writeCount} of which " +
                    "press Add or Save"))
        }
        if (program.writeCount > 1) {
            found.add(Finding(Level.WARN, "save",
                "This macro presses Add or Save ${program.writeCount} times per row",
                "each one makes a record in the portal"))
        }
        val wanted = columnsUsed(program)
        if (wanted.isNotEmpty() && table == null) {
            found.add(Finding(Level.STOP, "data", "This macro needs its CSV",
                "it reads column " + wanted.sorted().joinToString(", "),
                fix = "Choose the CSV file this macro was made with."))
        } else if (table != null) {
            val most = wanted.maxOrNull() ?: 0
            if (most > table.columns.size) {
                found.add(Finding(Level.STOP, "data",
                    "The macro reads column $most and the file has only " +
                        "${table.columns.size}",
                    fix = "Choose the right CSV, or the one the macro was " +
                        "written for."))
            }
            val s = table.summary()
            found.add(Finding(Level.NOTE, "data",
                "${s.rows} rows, ${s.columns} columns"))
            if (s.empty > 0) {
                found.add(Finding(Level.WARN, "data",
                    "${s.empty} rows are completely empty",
                    fix = "They will be attempted and will fail."))
            }
            if (s.rows == 0) {
                found.add(Finding(Level.STOP, "data", "The data file has no rows in it"))
            }
            for (note in s.trouble) found.add(Finding(Level.WARN, "data", note))
        }
        if (!browserOpen) {
            found.add(Finding(Level.STOP, "browser", "The portal page is not open",
                fix = "Open the portal and sign in on the Run page first."))
        }
        return found
    }

    /** Which CSV columns a macro reads. */
    fun columnsUsed(program: UvProgram): Set<Int> {
        val out = LinkedHashSet<Int>()
        for (s in program.steps) {
            for (field in listOf(s.raw.target, s.raw.value)) {
                for (m in Regex("\\$\\{!COL(\\d+)}").findAll(field)) {
                    m.groupValues[1].toIntOrNull()?.let { out.add(it) }
                }
            }
        }
        return out
    }

    private fun data(
        wanted: List<String>,
        mapping: Map<String, String>,
        table: Table?,
    ): List<Finding> {
        val found = ArrayList<Finding>()
        if (wanted.isNotEmpty() && table == null) {
            found.add(Finding(Level.STOP, "data", "This recording needs a data file",
                "it uses " + wanted.take(6).joinToString(", ") { "{{$it}}" },
                fix = "Choose the Excel or CSV file."))
            return found
        }
        if (table == null) return found

        if (wanted.isNotEmpty()) {
            val missing = wanted.filter { name ->
                val column = mapping[name] ?: name
                column !in table.columns && Bind.loosely(column, table.columns) == null
            }
            if (missing.isNotEmpty()) {
                found.add(Finding(Level.STOP, "data",
                    "${missing.size} of the values have no column",
                    missing.joinToString(", ") { "{{$it}}" },
                    fix = "Map them on the Data page."))
            } else {
                found.add(Finding(Level.NOTE, "data",
                    "All ${wanted.size} values are mapped"))
            }
            for (name in wanted) {
                val column = mapping[name] ?: name
                if (column in table.columns) {
                    val blank = table.blankIn(column)
                    if (blank.isNotEmpty() && blank.size == table.count()) {
                        found.add(Finding(Level.WARN, "data",
                            "Column \"$column\" is empty in every row",
                            "every record would get a blank there",
                            fix = "Check the file, or map {{$name}} to another " +
                                "column."))
                    } else if (blank.size > table.count() * 0.3) {
                        found.add(Finding(Level.WARN, "data",
                            "Column \"$column\" is empty in ${blank.size} of " +
                                "${table.count()} rows"))
                    }
                }
            }
        }
        val s = table.summary()
        found.add(Finding(Level.NOTE, "data", "${s.rows} rows, ${s.columns} columns"))
        if (s.empty > 0) {
            found.add(Finding(Level.WARN, "data",
                "${s.empty} rows are completely empty",
                fix = "They will be attempted and will fail."))
        }
        if (s.rows == 0) found.add(Finding(Level.STOP, "data",
            "The data file has no rows in it"))
        for (note in s.trouble) found.add(Finding(Level.WARN, "data", note))
        return found
    }

    fun summary(findings: List<Finding>): String {
        val stops = findings.count { it.level == Level.STOP }
        val warns = findings.count { it.level == Level.WARN }
        return when {
            stops > 0 -> "$stops thing${if (stops == 1) "" else "s"} must be " +
                "fixed before this can run."
            warns > 0 -> "Ready to run. $warns thing${if (warns == 1) "" else "s"} " +
                "worth a look first."
            else -> "Ready to run."
        }
    }

    fun mayRun(findings: List<Finding>): Boolean =
        findings.none { it.level == Level.STOP }
}
