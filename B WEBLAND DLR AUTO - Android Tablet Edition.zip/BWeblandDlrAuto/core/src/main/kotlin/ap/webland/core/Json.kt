package ap.webland.core

/**
 * A small, strict JSON reader and writer.
 *
 * The app reads two kinds of file that come from somewhere else: a .bwa
 * recording and a UI.Vision macro. Both are data, and the whole point of
 * reading them as data is that nothing in them can run. A parser is the
 * place that promise is kept or lost, so this one is deliberately plain:
 * it knows the seven JSON shapes and nothing else, it refuses a file that
 * is too big or nested too deep, and it never evaluates anything.
 *
 * It is here rather than taken from a library so that the core module has
 * no dependencies at all and can be compiled and tested on its own.
 */
sealed class Json {
    data class Str(val value: String) : Json()
    data class Num(val value: Double) : Json()
    data class Bool(val value: Boolean) : Json()
    object Null : Json()
    data class Arr(val items: List<Json>) : Json()
    data class Obj(val fields: Map<String, Json>) : Json()

    // ---- reading a field without caring whether it is there
    operator fun get(key: String): Json? = (this as? Obj)?.fields?.get(key)

    fun str(key: String, fallback: String = ""): String =
        when (val v = this[key]) {
            is Str -> v.value
            is Num -> numberText(v.value)
            is Bool -> v.value.toString()
            else -> fallback
        }

    fun int(key: String, fallback: Int = 0): Int =
        when (val v = this[key]) {
            is Num -> v.value.toInt()
            is Str -> v.value.trim().toDoubleOrNull()?.toInt() ?: fallback
            else -> fallback
        }

    fun bool(key: String, fallback: Boolean = false): Boolean =
        when (val v = this[key]) {
            is Bool -> v.value
            is Str -> v.value.equals("true", true)
            is Num -> v.value != 0.0
            else -> fallback
        }

    fun arr(key: String): List<Json> = (this[key] as? Arr)?.items ?: emptyList()

    fun obj(key: String): Json? = this[key] as? Obj

    /** Every field of an object as text, in the file's own order. */
    fun textMap(key: String): Map<String, String> {
        val o = obj(key) as? Obj ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((k, v) in o.fields) if (v is Str) out[k] = v.value
        return out
    }

    companion object {
        const val MAX_BYTES = 8 * 1024 * 1024
        const val MAX_DEPTH = 32

        /** A number written back the way a person wrote it: 3 not 3.0. */
        fun numberText(d: Double): String {
            if (d.isNaN() || d.isInfinite()) return "0"
            return if (d == Math.floor(d) && Math.abs(d) < 1e15)
                d.toLong().toString() else d.toString()
        }

        fun parse(text: String): Json {
            if (text.length > MAX_BYTES)
                throw JsonError("That file is too large to be a recording.")
            val p = Reader(text)
            p.skipBom()
            val v = p.value(0)
            p.ws()
            if (!p.done()) throw JsonError("Extra text after the end of the file.")
            return v
        }

        fun write(v: Json, indent: Int = 1): String {
            val sb = StringBuilder()
            put(sb, v, indent, 0)
            return sb.toString()
        }

        private fun put(sb: StringBuilder, v: Json, step: Int, depth: Int) {
            val pad = if (step > 0) " ".repeat(step * (depth + 1)) else ""
            val padEnd = if (step > 0) " ".repeat(step * depth) else ""
            val nl = if (step > 0) "\n" else ""
            when (v) {
                is Str -> sb.append(quote(v.value))
                is Num -> sb.append(numberText(v.value))
                is Bool -> sb.append(if (v.value) "true" else "false")
                is Null -> sb.append("null")
                is Arr -> {
                    if (v.items.isEmpty()) { sb.append("[]"); return }
                    sb.append('[').append(nl)
                    v.items.forEachIndexed { i, item ->
                        sb.append(pad)
                        put(sb, item, step, depth + 1)
                        if (i < v.items.size - 1) sb.append(',')
                        sb.append(nl)
                    }
                    sb.append(padEnd).append(']')
                }
                is Obj -> {
                    if (v.fields.isEmpty()) { sb.append("{}"); return }
                    sb.append('{').append(nl)
                    val keys = v.fields.keys.toList()
                    keys.forEachIndexed { i, k ->
                        sb.append(pad).append(quote(k)).append(':')
                        if (step > 0) sb.append(' ')
                        put(sb, v.fields.getValue(k), step, depth + 1)
                        if (i < keys.size - 1) sb.append(',')
                        sb.append(nl)
                    }
                    sb.append(padEnd).append('}')
                }
            }
        }

        fun quote(s: String): String {
            val sb = StringBuilder(s.length + 2)
            sb.append('"')
            for (c in s) when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append("\\u").append(
                    "%04x".format(c.code))
                else -> sb.append(c)
            }
            sb.append('"')
            return sb.toString()
        }

        // ---- handy builders, so callers never touch the classes directly
        fun of(vararg pairs: Pair<String, Json>): Json =
            Obj(LinkedHashMap<String, Json>().apply { pairs.forEach { put(it.first, it.second) } })

        fun s(v: String): Json = Str(v)
        fun n(v: Int): Json = Num(v.toDouble())
        fun b(v: Boolean): Json = Bool(v)
        fun a(items: List<Json>): Json = Arr(items)
        fun map(m: Map<String, String>): Json =
            Obj(LinkedHashMap<String, Json>().apply {
                m.forEach { (k, v) -> put(k, Str(v)) }
            })
    }

    private class Reader(val text: String) {
        var i = 0
        fun done() = i >= text.length
        fun skipBom() { if (text.startsWith("﻿")) i = 1 }
        fun ws() {
            while (i < text.length && text[i].isWhitespace()) i++
        }

        fun value(depth: Int): Json {
            if (depth > MAX_DEPTH) throw JsonError("That file is nested too deeply.")
            ws()
            if (done()) throw JsonError("The file ends where a value was expected.")
            return when (text[i]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> Str(string())
                't' -> { word("true"); Bool(true) }
                'f' -> { word("false"); Bool(false) }
                'n' -> { word("null"); Null }
                else -> number()
            }
        }

        fun obj(depth: Int): Json {
            i++                                  // {
            val out = LinkedHashMap<String, Json>()
            ws()
            if (!done() && text[i] == '}') { i++; return Obj(out) }
            while (true) {
                ws()
                if (done() || text[i] != '"')
                    throw JsonError("A name in quotes was expected at character $i.")
                val key = string()
                ws()
                if (done() || text[i] != ':')
                    throw JsonError("A colon was expected after \"$key\".")
                i++
                out[key] = value(depth + 1)
                ws()
                if (done()) throw JsonError("The file ends inside a set of fields.")
                when (text[i]) {
                    ',' -> i++
                    '}' -> { i++; return Obj(out) }
                    else -> throw JsonError("A comma or } was expected at character $i.")
                }
            }
        }

        fun arr(depth: Int): Json {
            i++                                  // [
            val out = ArrayList<Json>()
            ws()
            if (!done() && text[i] == ']') { i++; return Arr(out) }
            while (true) {
                out.add(value(depth + 1))
                ws()
                if (done()) throw JsonError("The file ends inside a list.")
                when (text[i]) {
                    ',' -> i++
                    ']' -> { i++; return Arr(out) }
                    else -> throw JsonError("A comma or ] was expected at character $i.")
                }
            }
        }

        fun string(): String {
            i++                                  // opening quote
            val sb = StringBuilder()
            while (true) {
                if (done()) throw JsonError("The file ends inside a piece of text.")
                val c = text[i++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (done()) throw JsonError("The file ends after a backslash.")
                        when (val e = text[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > text.length)
                                    throw JsonError("A \\u escape is cut short.")
                                val hex = text.substring(i, i + 4)
                                i += 4
                                sb.append(hex.toInt(16).toChar())
                            }
                            else -> throw JsonError("Unknown escape \\$e.")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun number(): Json {
            val start = i
            if (!done() && (text[i] == '-' || text[i] == '+')) i++
            while (!done() && (text[i].isDigit() || text[i] == '.' ||
                        text[i] == 'e' || text[i] == 'E' ||
                        text[i] == '-' || text[i] == '+')) i++
            val raw = text.substring(start, i)
            return Num(raw.toDoubleOrNull()
                ?: throw JsonError("\"$raw\" is not a number."))
        }

        fun word(w: String) {
            if (!text.startsWith(w, i)) throw JsonError("Unexpected text at character $i.")
            i += w.length
        }
    }
}

class JsonError(message: String) : Exception(message)
