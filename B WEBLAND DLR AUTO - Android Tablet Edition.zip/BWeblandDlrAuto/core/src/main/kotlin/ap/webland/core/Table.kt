package ap.webland.core

/**
 * The spreadsheet, once it is in memory, and the two jobs done with it:
 * matching a heading to a field, and putting a row's values into a step.
 *
 * One decision here is worth stating plainly. When a step asks for
 * {{Khata}} and the row has no Khata column, the text is left exactly as
 * it was written and the miss is reported. It is NOT replaced with a
 * blank: a blank looks like a deliberate empty value, goes into the
 * portal as one, and the run carries on filling eight hundred records
 * with a hole in them.
 */

/** One row: column name to cell text, in the file's own order. */
typealias Row = Map<String, String>

class Table(
    val columns: List<String>,
    val rows: List<Row>,
    /** anything odd noticed while reading the file */
    val trouble: List<String> = emptyList(),
    val sheetName: String = "",
    /** the spreadsheet line each row came from, for every report */
    val lineNumbers: List<Int> = rows.indices.map { it + 2 },
) {
    fun count(): Int = rows.size

    fun cell(index: Int, column: String): String =
        rows.getOrNull(index)?.get(column)?.trim() ?: ""

    fun lineOf(index: Int): Int = lineNumbers.getOrElse(index) { index + 2 }

    /** Which rows have nothing in this column. */
    fun blankIn(column: String): List<Int> {
        if (column !in columns) return emptyList()
        return rows.indices.filter { (rows[it][column] ?: "").trim().isEmpty() }
    }

    fun emptyRows(): List<Int> =
        rows.indices.filter { i -> rows[i].values.all { it.trim().isEmpty() } }

    fun summary(): Summary {
        val empty = emptyRows().size
        return Summary(rows.size, columns.size, rows.size - empty, empty, trouble)
    }

    data class Summary(
        val rows: Int,
        val columns: Int,
        val usable: Int,
        val empty: Int,
        val trouble: List<String>,
    )

    /** Rows where the same value appears in a column more than once. */
    fun duplicatesIn(column: String): Map<String, List<Int>> {
        if (column !in columns) return emptyMap()
        val by = LinkedHashMap<String, MutableList<Int>>()
        rows.forEachIndexed { i, r ->
            val v = (r[column] ?: "").trim()
            if (v.isNotEmpty()) by.getOrPut(v) { ArrayList() }.add(i)
        }
        return by.filterValues { it.size > 1 }
    }

    companion object {
        /** A table from rows of cells, the first row being the headings. */
        fun of(cells: List<List<String>>, sheetName: String = ""): Table {
            if (cells.isEmpty()) return Table(emptyList(), emptyList(),
                listOf("The sheet is empty."), sheetName)
            val trouble = ArrayList<String>()
            val head = cells[0].mapIndexed { i, h ->
                val t = h.trim()
                if (t.isEmpty()) "Column ${i + 1}" else t
            }
            val seen = HashMap<String, Int>()
            val columns = head.map { h ->
                val n = seen.getOrDefault(h, 0) + 1
                seen[h] = n
                if (n == 1) h else {
                    trouble.add("Two columns are both called \"$h\"; the " +
                        "second is used as \"$h ($n)\".")
                    "$h ($n)"
                }
            }
            val rows = ArrayList<Row>(cells.size - 1)
            val lines = ArrayList<Int>(cells.size - 1)
            for (i in 1 until cells.size) {
                val r = LinkedHashMap<String, String>()
                columns.forEachIndexed { c, name ->
                    r[name] = cells[i].getOrElse(c) { "" }
                }
                rows.add(r)
                lines.add(i + 1)
            }
            return Table(columns, rows, trouble, sheetName, lines)
        }
    }
}

/** Reading and writing CSV, including the BOM that UI.Vision writes. */
object Csv {
    fun parse(text: String): List<List<String>> {
        val body = text.removePrefix("﻿")
        val out = ArrayList<List<String>>()
        var field = StringBuilder()
        var row = ArrayList<String>()
        var quoted = false
        var i = 0
        while (i < body.length) {
            val c = body[i]
            when {
                quoted && c == '"' && i + 1 < body.length && body[i + 1] == '"' -> {
                    field.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                !quoted && c == ',' -> { row.add(field.toString()); field = StringBuilder() }
                !quoted && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < body.length && body[i + 1] == '\n') i++
                    row.add(field.toString()); field = StringBuilder()
                    out.add(row); row = ArrayList()
                }
                else -> field.append(c)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) {
            row.add(field.toString())
            out.add(row)
        }
        return out.filter { line -> line.any { it.isNotEmpty() } }
    }

    fun write(cells: List<List<String>>, bom: Boolean = true): String {
        val sb = StringBuilder()
        if (bom) sb.append('﻿')
        for (row in cells) {
            sb.append(row.joinToString(",") { quote(it) })
            sb.append("\r\n")
        }
        return sb.toString()
    }

    fun quote(v: String): String =
        if (v.any { it == ',' || it == '"' || it == '\n' || it == '\r' })
            "\"" + v.replace("\"", "\"\"") + "\""
        else v
}

/** Putting a row's values into a recorded step. */
object Bind {
    private val VAR = Regex("\\{\\{([^}]{1,60})\\}\\}")

    /** Every {{Column}} named in a value, in the order they appear. */
    fun namesIn(text: String?): List<String> =
        VAR.findAll(text ?: "").map { it.groupValues[1].trim() }.toList()

    fun hasVariable(text: String?): Boolean = VAR.containsMatchIn(text ?: "")

    /**
     * The step's value with the row's cells in it. A name the row does
     * not have is left as written and added to `missing`.
     */
    fun resolve(text: String?, row: Row, missing: MutableList<String>? = null): String {
        if (text.isNullOrEmpty()) return text ?: ""
        return VAR.replace(text) { m ->
            val key = m.groupValues[1].trim()
            when {
                row.containsKey(key) -> row[key] ?: ""
                else -> {
                    val loose = loosely(key, row.keys)
                    if (loose != null) row[loose] ?: "" else {
                        missing?.add(key)
                        m.value                   // left exactly as written
                    }
                }
            }
        }
    }

    fun loosely(key: String, names: Collection<String>): String? {
        val want = Headings.tidy(key)
        return names.firstOrNull { Headings.tidy(it) == want }
    }
}

/** Matching a spreadsheet heading to a field the app wants. */
object Headings {
    private val DROP = Regex("[^a-z0-9]+")
    private val NOISE = setOf(
        "the", "of", "no", "number", "name", "value", "field", "col",
        "column", "details", "detail", "please", "enter", "select")

    const val HIGH = 70
    const val MAYBE = 40

    /** A heading reduced to what it actually says. */
    fun tidy(text: String?): String {
        val low = DROP.replace((text ?: "").lowercase(), " ").trim()
        val words = low.split(" ").filter { it.isNotEmpty() }
        val keep = words.filter { it !in NOISE }
        return (if (keep.isEmpty()) words else keep).joinToString(" ")
    }

    data class Match(val field: String, val column: String?, val score: Int) {
        val verdict: String get() = when {
            column != null && score >= HIGH -> "high"
            column != null && score >= MAYBE -> "check"
            else -> "none"
        }
        val why: String get() = when (verdict) {
            "high" -> "names match"
            "check" -> "close, but please confirm"
            else -> "nothing in the file looks like this"
        }
        val certain: Boolean get() = verdict == "high"
    }

    /** How well one heading answers one wanted field. 0 to 100. */
    fun score(hint: ColumnHint, heading: String): Int {
        val tidied = tidy(heading)
        if (tidied.isEmpty()) return 0
        val words = tidied.split(" ").toSet()
        if (hint.avoid.any { it in tidied }) return 0
        hint.hints.forEachIndexed { rank, group ->
            val all = group.all { needle ->
                words.any { it.startsWith(needle) } || needle in tidied
            }
            if (all) {
                // A heading that IS the hint, word for word, is strong
                // evidence however far down the list it sits: a column
                // called "Name" answers the name field even though
                // "pattadar name" is looked for first. Only a partial
                // match pays the full penalty for being a later guess.
                val exact = tidied == group.joinToString(" ")
                val base = if (exact) 100 - rank * 4 else 100 - rank * 12 - 6
                return base.coerceIn(1, 100)
            }
        }
        // the field's own label, written out
        if (tidy(hint.label) == tidied) return HIGH
        return 0
    }

    /** One column for each wanted field, best first, nothing used twice. */
    fun match(hints: List<ColumnHint>, columns: List<String>): List<Match> {
        val taken = HashSet<String>()
        val out = ArrayList<Match>()
        val ranked = hints.map { hint ->
            hint to columns.map { it to score(hint, it) }
                .sortedByDescending { it.second }
        }
        for ((hint, options) in ranked) {
            val pick = options.firstOrNull { it.second > 0 && it.first !in taken }
            if (pick == null) out.add(Match(hint.key, null, 0))
            else {
                taken.add(pick.first)
                out.add(Match(hint.key, pick.first, pick.second))
            }
        }
        return out
    }
}
