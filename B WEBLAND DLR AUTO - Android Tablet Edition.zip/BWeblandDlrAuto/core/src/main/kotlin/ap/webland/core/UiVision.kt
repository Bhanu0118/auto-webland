package ap.webland.core

/**
 * Reading the UI.Vision macros the surveyor already has.
 *
 * There are thousands of records' worth of proven macros for this
 * village work - "NIVAGAM PATTA ADD.json" and its CSV enter 3,454
 * records - and an Android app that could not run them would be asking
 * for all of that to be built again. So this module reads that format,
 * and the runner next door plays it.
 *
 * It is read as data, under the same gate as a .bwa recording:
 *
 *  - the command must be one of a fixed list, or it is refused;
 *  - `executeScript` is NEVER run. Two script shapes that these macros
 *    use are recognised and replaced by something the app does natively
 *    (pad an extent to three decimals; wait for a dropdown's list to
 *    arrive). Any other script is dropped and reported. There is no path
 *    from a macro file to code in this app;
 *  - `if` nesting must balance, or the file is refused rather than half
 *    understood.
 *
 * Two of UI.Vision's own limits are reported but not copied, because
 * copying a limitation into a new program is how a bug outlives the
 * thing that caused it:
 *
 *  - one UI.Vision build reads only !COL1 … !COL20 and answers
 *    'Internal variable "!COL21" not supported'. With !ERRORIGNORE on,
 *    the `if` holding it falls through and a whole block is skipped in
 *    silence. This app reads every column; the check below still warns,
 *    so the file stays usable on a laptop too.
 *  - UI.Vision hands a CSV cell over as a number, so 0.680 is typed as
 *    0.68. This app types the cell's own text, so an extent keeps its
 *    three decimals without a repair script.
 */

/** One line of a UI.Vision macro. */
data class UvCommand(
    val command: String,
    val target: String = "",
    val value: String = "",
    val description: String = "",
) {
    fun toJson(): Json = Json.of(
        "Command" to Json.s(command),
        "Target" to Json.s(target),
        "Value" to Json.s(value),
        "Description" to Json.s(description))
}

class UvMacro(
    var name: String = "Untitled",
    val commands: MutableList<UvCommand> = ArrayList(),
) {
    fun toJson(): Json = Json.of(
        "Name" to Json.s(name),
        "CreationDate" to Json.s(""),
        "Commands" to Json.a(commands.map { it.toJson() }))

    fun write(): String = Json.write(toJson(), indent = 2)

    /** The CSV this macro reads, if it names one. */
    fun csvName(): String =
        commands.firstOrNull { it.command.equals("csvRead", true) }?.target ?: ""

    companion object {
        const val MAX_COMMANDS = 20_000

        fun read(text: String): UvMacro {
            val raw = Json.parse(text)
            if (raw !is Json.Obj) throw JsonError("That file does not hold a macro.")
            val list = raw["Commands"]
            if (list !is Json.Arr) throw JsonError("That macro has no Commands in it.")
            if (list.items.size > MAX_COMMANDS)
                throw JsonError("That macro has ${list.items.size} commands. " +
                    "The limit is $MAX_COMMANDS.")
            val macro = UvMacro(raw.str("Name").ifBlank { "Untitled" }.take(120))
            for (one in list.items) {
                if (one !is Json.Obj) continue
                macro.commands.add(UvCommand(
                    command = one.str("Command").trim(),
                    target = one.str("Target"),
                    value = one.str("Value"),
                    description = one.str("Description")))
            }
            return macro
        }
    }
}

/** How a UI.Vision target names its box. */
data class Selector(val kind: String, val value: String) {
    val isEmpty: Boolean get() = value.isBlank()

    override fun toString(): String = "$kind=$value"

    companion object {
        val KINDS = listOf("id", "name", "css", "xpath", "linktext", "link",
            "partiallinktext", "label", "value", "text")

        fun of(raw: String?): Selector {
            val s = (raw ?: "").trim()
            if (s.isEmpty()) return Selector("none", "")
            val cut = s.indexOf('=')
            if (cut > 0) {
                val kind = s.substring(0, cut).trim().lowercase()
                if (kind in KINDS) return Selector(kind, s.substring(cut + 1))
            }
            // a bare //… is an xpath; anything else is treated as an id
            return if (s.startsWith("/") || s.startsWith("(")) Selector("xpath", s)
            else Selector("id", s)
        }
    }
}

/** What a compiled macro turned out to be, and what was refused. */
class UvProgram(
    val name: String,
    val steps: List<UvStep>,
    val notes: List<Finding>,
    val csvName: String,
) {
    val writeCount: Int get() = steps.count { it.writes }

    fun mayRun(): Boolean = notes.none { it.level == Level.STOP }
}

/**
 * One command after compiling: the same data, with the parts the runner
 * needs worked out once instead of on every row of a 3,000-row file.
 */
data class UvStep(
    val line: Int,
    val op: UvOp,
    val raw: UvCommand,
    val selector: Selector = Selector("none", ""),
    /** for `if`: the index just past its `endif` */
    val jumpTo: Int = -1,
    val writes: Boolean = false,
)

enum class UvOp {
    OPEN, CLICK, TYPE, SELECT, PAUSE, STORE, CSV_READ, WAIT_VISIBLE,
    WAIT_PRESENT, WAIT_TEXT, WAIT_SAVE, WAIT_LIST, WAIT_EMPTY, PAD_EXTENTS,
    DIALOGS, CHECK_RADIO, IF, ELSE, ENDIF, ECHO, COMMENT, THROW, FRAME,
    SCREENSHOT, REFRESH, UPLOAD,
}

object UiVision {
    /** The column numbers a UI.Vision build is sure to read. */
    const val SAFE_COLUMNS = 20

    /** Commands this app knows. Anything else is refused. */
    private val KNOWN = mapOf(
        "open" to UvOp.OPEN,
        "click" to UvOp.CLICK,
        "clickandwait" to UvOp.CLICK,
        "clickat" to UvOp.CLICK,
        "type" to UvOp.TYPE,
        "sendkeys" to UvOp.TYPE,
        "xtype" to UvOp.TYPE,
        "select" to UvOp.SELECT,
        "selectandwait" to UvOp.SELECT,
        "pause" to UvOp.PAUSE,
        "store" to UvOp.STORE,
        "storevalue" to UvOp.STORE,
        "storetext" to UvOp.STORE,
        "csvread" to UvOp.CSV_READ,
        "waitforelementvisible" to UvOp.WAIT_VISIBLE,
        "waitforvisible" to UvOp.WAIT_VISIBLE,
        "waitforelementpresent" to UvOp.WAIT_PRESENT,
        "waitfortextpresent" to UvOp.WAIT_TEXT,
        "if" to UvOp.IF,
        "if_v2" to UvOp.IF,
        "else" to UvOp.ELSE,
        "endif" to UvOp.ENDIF,
        "echo" to UvOp.ECHO,
        "comment" to UvOp.COMMENT,
        "throwerror" to UvOp.THROW,
        "selectframe" to UvOp.FRAME,
        "captureentirepagescreenshot" to UvOp.SCREENSHOT,
        "refresh" to UvOp.REFRESH,
        "selectwindow" to UvOp.COMMENT,
    )

    /** Buttons whose click makes a record in the portal. */
    private val WRITE_IDS = listOf("btnadd", "btnsave", "btnsubmit", "btndigi")

    /**
     * Compile a macro into something the runner can play, collecting
     * everything the person should know first.
     */
    fun compile(macro: UvMacro): UvProgram {
        val notes = ArrayList<Finding>()
        val steps = ArrayList<UvStep>()

        for ((i, c) in macro.commands.withIndex()) {
            val line = i + 1
            val key = c.command.trim().lowercase()
            if (key.isEmpty()) continue
            val op = KNOWN[key]
            if (op == null) {
                if (key == "executescript" || key == "executescript_sandbox" ||
                    key == "executeasyncscript"
                ) {
                    val replaced = script(c, line)
                    if (replaced != null) {
                        steps.add(replaced)
                        notes.add(Finding(
                            Level.NOTE, "script", "Line $line does in the app " +
                                "what the macro did with a script",
                            when (replaced.op) {
                                UvOp.PAD_EXTENTS ->
                                    "the extents are padded to three decimals " +
                                        "before they are typed, so no repair is needed"
                                UvOp.WAIT_LIST ->
                                    "it waits for the dropdown's own list to arrive"
                                UvOp.WAIT_EMPTY ->
                                    "it waits for that box to empty"
                                UvOp.WAIT_PRESENT ->
                                    "it waits for that box to appear"
                                UvOp.CHECK_RADIO ->
                                    "it ticks that choice, and reads back that it " +
                                        "is ticked"
                                UvOp.DIALOGS ->
                                    "the app answers the portal's own confirm and " +
                                        "alert boxes itself, so nothing waits for OK"
                                else -> ""
                            }))
                    } else {
                        notes.add(Finding(
                            Level.WARN, "script",
                            "Line $line holds a script, which is not run",
                            "this app never runs code out of a macro file. If " +
                                "that line did something the record needs, say " +
                                "what it was and it can be built in.",
                            fix = "The step is skipped; the rest of the macro runs."))
                    }
                } else if (key == "while" || key == "do" || key == "times" ||
                    key == "gotolabel" || key == "label"
                ) {
                    notes.add(Finding(
                        Level.STOP, "loop",
                        "Line $line is a loop ($key), which is refused",
                        "a macro that can jump about cannot be checked before " +
                            "it runs, and this one enters land records"))
                } else {
                    notes.add(Finding(
                        Level.WARN, "command",
                        "Line $line is \"${c.command.take(30)}\", which this " +
                            "app does not know",
                        "the step is skipped rather than guessed at"))
                }
                continue
            }

            val sel = if (op in setOf(UvOp.CLICK, UvOp.TYPE, UvOp.SELECT,
                    UvOp.WAIT_VISIBLE, UvOp.WAIT_PRESENT, UvOp.WAIT_LIST,
                    UvOp.UPLOAD)
            ) Selector.of(c.target) else Selector("none", "")

            val writes = op == UvOp.CLICK && WRITE_IDS.any {
                sel.value.lowercase().contains(it)
            }
            steps.add(UvStep(line, op, c, sel, writes = writes))
        }

        // ---- the if / else / endif nesting must balance
        val stack = ArrayList<Int>()
        val elseOf = HashMap<Int, Int>()
        val jumps = HashMap<Int, Int>()
        steps.forEachIndexed { index, s ->
            when (s.op) {
                UvOp.IF -> stack.add(index)
                UvOp.ELSE -> {
                    val open = stack.lastOrNull()
                    if (open == null) {
                        notes.add(Finding(Level.STOP, "if",
                            "Line ${s.line} has an else with no if before it"))
                    } else if (elseOf.containsKey(open)) {
                        notes.add(Finding(Level.STOP, "if",
                            "Line ${s.line} is a second else for the same if"))
                    } else elseOf[open] = index
                }
                UvOp.ENDIF -> {
                    val open = stack.removeLastOrNull()
                    if (open == null) {
                        notes.add(Finding(Level.STOP, "if",
                            "Line ${s.line} has an endif with no if before it"))
                    } else {
                        val e = elseOf[open]
                        jumps[open] = e ?: index
                        if (e != null) jumps[e] = index
                    }
                }
                else -> {}
            }
        }
        for (open in stack) {
            notes.add(Finding(Level.STOP, "if",
                "Line ${steps[open].line} opens an if that is never closed"))
        }
        val linked = steps.mapIndexed { index, s ->
            if (s.op == UvOp.IF || s.op == UvOp.ELSE)
                s.copy(jumpTo = jumps[index] ?: -1) else s
        }

        // ---- every `if` must be a comparison this app can read
        for (s in linked) {
            if (s.op != UvOp.IF) continue
            val shape = s.raw.target.trim()
            val looksLikeOne = Regex("^.*?(==|!=|>=|<=|>|<).*$").matches(shape)
            val bareNumber = shape.removeSurrounding("\"").toDoubleOrNull() != null ||
                Regex("^\\$\\{[^}]+}$").matches(shape)
            if (!looksLikeOne && !bareNumber) {
                notes.add(Finding(
                    Level.STOP, "if",
                    "Line ${s.line} asks \"${shape.take(40)}\", which is not a " +
                        "comparison",
                    "this app compares two values and does no arithmetic, so a " +
                        "condition it cannot read is refused instead of guessed"))
            }
        }

        notes.addAll(portability(macro))
        if (linked.none { it.writes }) {
            notes.add(Finding(
                Level.NOTE, "save",
                "Nothing in this macro presses Add or Save",
                "it fills the form and stops, which is right for a dry run"))
        }
        return UvProgram(macro.name, linked, notes, macro.csvName())
    }

    /**
     * The scripts these macros use, recognised by WHAT THEY DO and then
     * done natively. The script itself is never run.
     *
     * Every shape in the surveyor's own macros is here: waiting for a
     * dropdown's list, waiting for a box to empty or to appear, padding
     * the extents, ticking Joint Cultivation = No, and switching off the
     * portal's confirm boxes. Anything else returns null and is dropped
     * with a warning, because a script this app cannot read is a script
     * it must not pretend to understand.
     */
    private fun script(c: UvCommand, line: Int): UvStep? {
        val body = c.target.lowercase()
        if (body.startsWith("window.confirm") || body.startsWith("window.alert") ||
            body.startsWith("window.onbeforeunload")
        ) return UvStep(line, UvOp.DIALOGS, c)

        val padding = body.contains("indexof('.')") ||
            (body.contains("substring(0,3)") && body.contains("extent"))
        if (padding) return UvStep(line, UvOp.PAD_EXTENTS, c)

        val id = Regex("getelementbyid\\('([^']+)'\\)").find(body)
            ?.groupValues?.get(1) ?: ""
        val sel = Selector("id", idOf(c.target, id))

        if (body.contains("options.length")) return UvStep(line, UvOp.WAIT_LIST, c, sel)
        if (body.contains(".checked=true") || body.contains(".checked = true"))
            return UvStep(line, UvOp.CHECK_RADIO, c, sel)
        if (body.contains(".value===''") || body.contains(".value === ''") ||
            body.contains(".value==\"\"")
        ) return UvStep(line, UvOp.WAIT_EMPTY, c, sel)
        // the plainest probe of all: is this box on the page at all
        if (id.isNotEmpty() && !body.contains("=") ||
            (id.isNotEmpty() && Regex("getelementbyid\\('[^']+'\\)\\s*\\?\\s*1")
                .containsMatchIn(body))
        ) return UvStep(line, UvOp.WAIT_PRESENT, c, sel)
        return null
    }

    /** The element id out of a script, with its original capitals. */
    private fun idOf(original: String, lowered: String): String {
        if (lowered.isEmpty()) return ""
        val at = original.lowercase().indexOf(lowered)
        return if (at < 0) lowered else original.substring(at, at + lowered.length)
    }

    /** What would bite this file on a laptop, even though it runs here. */
    fun portability(macro: UvMacro): List<Finding> {
        val out = ArrayList<Finding>()
        val high = LinkedHashSet<Int>()
        val inIf = LinkedHashSet<Int>()
        for (c in macro.commands) {
            for (field in listOf(c.target, c.value)) {
                for (m in Regex("\\$\\{!COL(\\d+)}").findAll(field)) {
                    val n = m.groupValues[1].toIntOrNull() ?: continue
                    if (n > SAFE_COLUMNS) high.add(n)
                    if (c.command.trim().equals("if", true)) inIf.add(n)
                }
            }
        }
        if (high.isNotEmpty()) {
            out.add(Finding(
                Level.WARN, "uivision",
                "This macro uses column ${high.sorted().joinToString(", ")}",
                "this app reads them, but one UI.Vision build stops at " +
                    "!COL$SAFE_COLUMNS and answers \"Internal variable not " +
                    "supported\" - with error-ignore on, the block holding it " +
                    "is skipped in silence",
                fix = "Keep the CSV to $SAFE_COLUMNS columns if the same file " +
                    "has to run in UI.Vision on a laptop."))
        }
        if (inIf.isNotEmpty()) {
            out.add(Finding(
                Level.NOTE, "uivision",
                "An `if` reads a CSV column directly",
                "UI.Vision does not put a column into an `if`, so a laptop " +
                    "needs `store` first; this app reads it either way"))
        }
        return out
    }

    // ------------------------------------------------- writing one out
    /**
     * A UI.Vision macro built from a .bwa recording, so work done on the
     * tablet can still be run on the laptop.
     */
    fun fromAutomation(auto: Automation, csvName: String = ""): UvMacro {
        val m = UvMacro(auto.name)
        m.commands.add(UvCommand("store", "true", "!ERRORIGNORE"))
        m.commands.add(UvCommand("store", "2", "!TIMEOUT_WAIT"))
        if (csvName.isNotBlank()) {
            m.commands.add(UvCommand("store", "\${!LOOP}", "!csvReadLineNumber"))
            m.commands.add(UvCommand("csvRead", csvName))
        }
        var column = 0
        val columnOf = HashMap<String, Int>()
        for (name in auto.variables()) columnOf[name] = ++column
        fun bound(text: String): String =
            Bind.namesIn(text).fold(text) { acc, n ->
                acc.replace("{{$n}}", "\${!COL${columnOf[n] ?: 1}}")
            }
        for (s in auto.live()) {
            val target = if (s.target.id.isNotBlank()) "id=${s.target.id}"
            else if (s.target.css.isNotBlank()) "css=${s.target.css}"
            else if (s.target.xpath.isNotBlank()) "xpath=${s.target.xpath}"
            else ""
            when (s.act) {
                Act.OPEN -> m.commands.add(UvCommand("open", s.value))
                Act.CLICK -> m.commands.add(UvCommand("click", target))
                Act.TYPE -> m.commands.add(UvCommand("type", target, bound(s.value)))
                Act.SELECT -> m.commands.add(
                    UvCommand("select", target, "label=" + bound(s.value)))
                Act.WAIT -> when (s.wait) {
                    Wait.SECONDS -> m.commands.add(
                        UvCommand("pause", s.waitFor.ifBlank { "500" }))
                    Wait.VISIBLE, Wait.ELEMENT -> m.commands.add(
                        UvCommand("waitForElementVisible", target))
                    else -> m.commands.add(UvCommand("pause", "500"))
                }
                Act.COMMENT -> m.commands.add(UvCommand("comment", "", s.value))
                else -> m.commands.add(UvCommand("comment", "",
                    "${s.act.key} is not written to a UI.Vision macro"))
            }
        }
        return m
    }
}
