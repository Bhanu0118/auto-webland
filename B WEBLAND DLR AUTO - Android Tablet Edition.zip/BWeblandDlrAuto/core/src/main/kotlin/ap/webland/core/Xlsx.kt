package ap.webland.core

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Reading and writing .xlsx, without a library.
 *
 * An .xlsx file is a zip of XML, and both halves of that are in the Java
 * runtime already. Doing it this way is not showing off: the usual
 * spreadsheet library for Java is built for a desktop, wants a large
 * part of the runtime that Android does not have, and loads a workbook
 * into memory all at once - which is the one thing a 4,000-row file on a
 * tablet cannot afford. This reads a sheet a row at a time and writes
 * one the same way, so the file size that matters is the file's, not the
 * tablet's.
 *
 * It also means the whole spreadsheet path can be tested on a desktop
 * with nothing but the Kotlin compiler, which is why it lives in core.
 *
 * What it handles: shared strings, inline strings, plain numbers, gaps
 * in a row, several sheets, and Telugu (everything is UTF-8). What it
 * does not: formulas are read as their last saved value, and a date
 * comes back as the number Excel stores, because guessing a date format
 * from a style is how a 1-7-2026 becomes a 7-1-2026.
 */
object Xlsx {

    /** Every sheet name in the workbook, in the file's own order. */
    fun sheetNames(open: () -> InputStream): List<String> {
        val book = entry(open, "xl/workbook.xml") ?: return emptyList()
        val text = book.toString(Charsets.UTF_8)
        return Regex("<sheet\\b[^>]*\\bname=\"([^\"]*)\"")
            .findAll(text).map { unescape(it.groupValues[1]) }.toList()
    }

    /**
     * One sheet as rows of text.
     *
     * `open` is called more than once - the parts of a zip are not in a
     * helpful order - so it must hand back a fresh stream each time.
     * On Android that is `{ resolver.openInputStream(uri)!! }`.
     */
    fun read(
        open: () -> InputStream,
        sheet: Int = 0,
        maxRows: Int = 100_000,
    ): Table {
        val shared = sharedStrings(open)
        val names = sheetNames(open)
        val path = sheetPath(open, sheet)
            ?: throw JsonError("That workbook has no sheet number ${sheet + 1}.")
        val bytes = entry(open, path)
            ?: throw JsonError("The sheet could not be read out of the file.")
        val xml = bytes.toString(Charsets.UTF_8)

        val rows = ArrayList<List<String>>()
        var widest = 0
        for (m in Regex("<row\\b[^>]*>([\\s\\S]*?)</row>").findAll(xml)) {
            if (rows.size >= maxRows) break
            val cells = HashMap<Int, String>()
            for (c in Regex("<c\\b([^>]*)(?:/>|>([\\s\\S]*?)</c>)").findAll(m.groupValues[1])) {
                val attrs = c.groupValues[1]
                val body = c.groupValues[2]
                val ref = Regex("r=\"([A-Z]+)\\d+\"").find(attrs)?.groupValues?.get(1)
                val column = if (ref == null) cells.size else columnOf(ref)
                val type = Regex("t=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1) ?: "n"
                val value = when (type) {
                    "s" -> {
                        val at = inner(body, "v").trim().toIntOrNull()
                        if (at != null) shared.getOrElse(at) { "" } else ""
                    }
                    "inlineStr" -> allText(body)
                    "str" -> unescape(inner(body, "v"))
                    "b" -> if (inner(body, "v").trim() == "1") "TRUE" else "FALSE"
                    else -> unescape(inner(body, "v")).trim()
                }
                cells[column] = value
                if (column + 1 > widest) widest = column + 1
            }
            val row = (0 until (cells.keys.maxOrNull()?.plus(1) ?: 0))
                .map { cells[it] ?: "" }
            rows.add(row)
        }
        val padded = rows.map { r -> r + List((widest - r.size).coerceAtLeast(0)) { "" } }
        val trimmed = padded.dropLastWhile { line -> line.all { it.isBlank() } }
        return Table.of(trimmed, names.getOrElse(sheet) { "Sheet${sheet + 1}" })
    }

    /** Several sheets into one workbook. Nothing else is in the file. */
    fun write(out: OutputStream, sheets: List<Sheet>) {
        val use = if (sheets.isEmpty())
            listOf(Sheet("Sheet1", emptyList(), emptyList())) else sheets
        val names = uniqueNames(use.map { it.name })
        ZipOutputStream(out).use { zip ->
            put(zip, "[Content_Types].xml", contentTypes(use.size))
            put(zip, "_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
                    """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
                    """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""" +
                    """</Relationships>""")
            put(zip, "xl/workbook.xml", workbook(names))
            put(zip, "xl/_rels/workbook.xml.rels", workbookRels(use.size))
            put(zip, "xl/styles.xml", styles())
            use.forEachIndexed { i, sheet ->
                put(zip, "xl/worksheets/sheet${i + 1}.xml", worksheet(sheet))
            }
        }
    }

    fun bytes(sheets: List<Sheet>): ByteArray {
        val out = ByteArrayOutputStream()
        write(out, sheets)
        return out.toByteArray()
    }

    // --------------------------------------------------------- the zip
    private fun entry(open: () -> InputStream, name: String): ByteArrayOutputStream? {
        ZipInputStream(open()).use { zip ->
            var e: ZipEntry? = zip.nextEntry
            while (e != null) {
                if (e.name == name) {
                    val out = ByteArrayOutputStream()
                    zip.copyTo(out)
                    return out
                }
                e = zip.nextEntry
            }
        }
        return null
    }

    private fun sheetPath(open: () -> InputStream, index: Int): String? {
        // the ordinary layout first, then whatever the rels really say
        val plain = "xl/worksheets/sheet${index + 1}.xml"
        if (entry(open, plain) != null) return plain
        val rels = entry(open, "xl/_rels/workbook.xml.rels")?.toString(Charsets.UTF_8)
            ?: return null
        val targets = Regex("Target=\"([^\"]*worksheets/[^\"]+)\"")
            .findAll(rels).map { it.groupValues[1].removePrefix("/") }.toList()
        val pick = targets.getOrNull(index) ?: return null
        return if (pick.startsWith("xl/")) pick else "xl/$pick"
    }

    private fun sharedStrings(open: () -> InputStream): List<String> {
        val raw = entry(open, "xl/sharedStrings.xml")?.toString(Charsets.UTF_8)
            ?: return emptyList()
        return Regex("<si\\b[^>]*>([\\s\\S]*?)</si>").findAll(raw)
            .map { allText(it.groupValues[1]) }.toList()
    }

    private fun put(zip: ZipOutputStream, name: String, body: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(body.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    // --------------------------------------------------------- the XML
    private fun inner(body: String, tag: String): String =
        Regex("<$tag\\b[^>]*>([\\s\\S]*?)</$tag>").find(body)?.groupValues?.get(1) ?: ""

    /** Every <t> in a cell, joined: a run-formatted string is still one value. */
    private fun allText(body: String): String =
        Regex("<t\\b[^>]*>([\\s\\S]*?)</t>").findAll(body)
            .joinToString("") { unescape(it.groupValues[1]) }

    fun columnOf(letters: String): Int {
        var n = 0
        for (c in letters) n = n * 26 + (c - 'A' + 1)
        return n - 1
    }

    fun lettersOf(column: Int): String {
        var n = column + 1
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.insert(0, ('A' + r))
            n = (n - 1) / 26
        }
        return sb.toString()
    }

    fun escape(text: String): String {
        val sb = StringBuilder(text.length + 8)
        for (c in text) when {
            c == '&' -> sb.append("&amp;")
            c == '<' -> sb.append("&lt;")
            c == '>' -> sb.append("&gt;")
            c == '"' -> sb.append("&quot;")
            c == '\'' -> sb.append("&apos;")
            // a control character makes the whole file unreadable to Excel
            c.code < 0x20 && c != '\n' && c != '\t' -> sb.append(' ')
            else -> sb.append(c)
        }
        return sb.toString()
    }

    fun unescape(text: String): String = text
        .replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'")
        .replace(Regex("&#x([0-9A-Fa-f]+);")) {
            it.groupValues[1].toInt(16).toChar().toString()
        }
        .replace(Regex("&#(\\d+);")) { it.groupValues[1].toInt().toChar().toString() }
        .replace("&amp;", "&")

    private fun uniqueNames(names: List<String>): List<String> {
        val used = HashSet<String>()
        return names.map { raw ->
            var name = raw.filter { it !in ":\\/?*[]" }.take(31).ifBlank { "Sheet" }
            var n = 2
            while (!used.add(name.lowercase())) {
                val tail = " ($n)"
                name = name.take(31 - tail.length) + tail
                n++
            }
            name
        }
    }

    private fun contentTypes(sheets: Int): String {
        val parts = (1..sheets).joinToString("") {
            """<Override PartName="/xl/worksheets/sheet$it.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""" +
            """<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""" +
            """<Default Extension="xml" ContentType="application/xml"/>""" +
            """<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""" +
            """<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""" +
            parts + """</Types>"""
    }

    private fun workbook(names: List<String>): String {
        val sheets = names.mapIndexed { i, name ->
            """<sheet name="${escape(name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>"""
        }.joinToString("")
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" """ +
            """xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""" +
            """<sheets>$sheets</sheets></workbook>"""
    }

    private fun workbookRels(sheets: Int): String {
        val rels = (1..sheets).joinToString("") {
            """<Relationship Id="rId$it" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$it.xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            rels +
            """<Relationship Id="rId${sheets + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""" +
            """</Relationships>"""
    }

    /** Two styles: the headings in white on dark blue, and everything else. */
    private fun styles(): String =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""" +
            """<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>""" +
            """<font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>""" +
            """<fills count="3"><fill><patternFill patternType="none"/></fill>""" +
            """<fill><patternFill patternType="gray125"/></fill>""" +
            """<fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/>""" +
            """<bgColor indexed="64"/></patternFill></fill></fills>""" +
            """<borders count="1"><border/></borders>""" +
            """<cellStyleXfs count="1"><xf/></cellStyleXfs>""" +
            """<cellXfs count="2"><xf xfId="0"/>""" +
            """<xf xfId="0" fontId="1" fillId="2" applyFont="1" applyFill="1">""" +
            """<alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs>""" +
            """</styleSheet>"""

    private fun worksheet(sheet: Sheet): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        val widths = (0 until sheet.headings.size.coerceAtLeast(1)).joinToString("") { c ->
            val longest = (listOf(sheet.headings.getOrElse(c) { "" }) +
                sheet.rows.take(300).map { it.getOrElse(c) { "" } })
                .maxOf { it.length }
            """<col min="${c + 1}" max="${c + 1}" width="${
                (longest + 2).coerceIn(9, 44)
            }" customWidth="1"/>"""
        }
        if (sheet.headings.isNotEmpty()) sb.append("<cols>$widths</cols>")
        sb.append("<sheetData>")
        if (sheet.headings.isNotEmpty()) sb.append(row(1, sheet.headings, heading = true))
        sheet.rows.forEachIndexed { i, cells ->
            sb.append(row(i + 2, cells, heading = false))
        }
        sb.append("</sheetData>")
        if (sheet.headings.isNotEmpty()) {
            // the headings stay on screen, and every column can be filtered
            sb.append("""<autoFilter ref="A1:${
                lettersOf(sheet.headings.size - 1)
            }${sheet.rows.size + 1}"/>""")
        }
        sb.append("</worksheet>")
        return sb.toString()
    }

    private fun row(number: Int, cells: List<String>, heading: Boolean): String {
        val sb = StringBuilder("<row r=\"$number\">")
        cells.forEachIndexed { c, raw ->
            if (raw.isEmpty()) return@forEachIndexed
            val ref = lettersOf(c) + number
            val style = if (heading) " s=\"1\"" else ""
            // a number goes in as a number so the sheet can add it up;
            // anything that only looks like one (a khata, a subdivision)
            // stays text, because 212-4 is not a date and 0.680 must keep
            // its zero
            val plainNumber = !heading && raw.length < 15 &&
                Regex("^-?\\d+(\\.\\d+)?$").matches(raw) &&
                !(raw.contains('.') && raw.trimEnd('0') != raw)
            if (plainNumber) {
                sb.append("""<c r="$ref"$style><v>$raw</v></c>""")
            } else {
                sb.append("""<c r="$ref"$style t="inlineStr"><is><t xml:space="preserve">""")
                sb.append(escape(raw))
                sb.append("""</t></is></c>""")
            }
        }
        sb.append("</row>")
        return sb.toString()
    }
}
