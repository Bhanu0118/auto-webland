package ap.webland.core

/**
 * The DLR instruction sheet, as checks rather than as silent changes.
 *
 * "DLR నమోదులలో పాటించాల్సిన సూచనలు" has nineteen numbered items. Ten of
 * them are the land-nature table, and those are in Presets. The other
 * nine are rules about the record itself: which rights go with which kind
 * of land, which LPM series a non-agricultural plot belongs to, which
 * khata a Social Welfare acquisition takes.
 *
 * Those nine are NOT applied automatically, and that is deliberate.
 *
 * A rule like "a non-agricultural LPM is numbered from 3,00,001" is about
 * what the surveyor decided, not about what a program can work out. If
 * the app renumbered an LPM on its own it would be altering the record
 * the office prepared, on a guess, in a register that has no undo. So
 * every rule here reads the file and SAYS what it sees. The person
 * decides; the program only makes sure they cannot not-know.
 *
 * Each finding carries the sheet's own number, so anybody can look it up.
 */

enum class Level(val mark: String) { STOP("✗"), WARN("⚠"), NOTE("•") }

data class Finding(
    val level: Level,
    /** the sheet's own numbering, e.g. "19.1", "13", "14 / 15" */
    val rule: String,
    val title: String,
    val detail: String = "",
    val rows: List<Int> = emptyList(),
    val fix: String = "",
) {
    fun line(): String {
        val where = if (rows.isEmpty()) "" else {
            val shown = rows.take(8).joinToString(", ")
            val more = if (rows.size > 8) " … and ${rows.size - 8} more" else ""
            "   (rows $shown$more)"
        }
        val why = if (detail.isBlank()) "" else "  —  $detail"
        return "${level.mark}  DLR ${rule.padEnd(4)} $title$why$where"
    }
}

/** The least a rule check needs to know about one record. */
interface DlrRecord {
    val rowNumber: Int
    val lpm: String
    val khata: String
}

data class SimpleRecord(
    override val rowNumber: Int,
    override val lpm: String,
    override val khata: String,
) : DlrRecord

object DlrRules {

    /**
     * Rule 13 names what goes in the 3,00,001 series, and it is a short
     * list: houses, house sites, any other BUILDINGS, non-endowment
     * temples, non-wakf mosques, dargahs, industries, layouts. Rule 16.3
     * adds new house colonies recorded as gramakhantam.
     *
     * A canal, a hill, a banjar, a grazing ground and a road are none of
     * those. They are not farmed either - but "not farmed" and "rule 13"
     * are different things, and the sheet only says the second about
     * structures. Keying this off land_use being Non-Agriculture made it
     * fire on almost every government-land run, and a warning that
     * appears every time is a warning nobody reads.
     */
    val NON_AGRI_CLASSES = listOf("Govt. Building", "Gramakhantam")

    /** The rights the sheet says this land takes, and which rule says so. */
    fun expectedRights(p: LandPreset?): Pair<String, String> {
        if (p == null || !p.isGovt) return "" to "19.6"
        if (p.subNature.contains("D-Patta") || p.id == "dpatta")
            return (PortalWords.RIGHTS_BY_LAND["dpatta"] ?: "") to "19.2"
        return (PortalWords.RIGHTS_BY_LAND["govt"] ?: "") to "19.1"
    }

    /**
     * Is this one of the kinds rule 13 puts in its own LPM series?
     * Judged on the classification alone; land use is deliberately not
     * consulted.
     */
    fun looksNonAgri(p: LandPreset?): Boolean {
        val one = p?.subClass ?: return false
        return NON_AGRI_CLASSES.any { one.lowercase().startsWith(it.lowercase()) }
    }

    /** Read a run before it starts, against the sheet. */
    fun check(preset: LandPreset?, records: List<DlrRecord> = emptyList()): List<Finding> {
        val out = ArrayList<Finding>()
        val p = preset ?: return out

        // ---- rule 19: the rights box
        val (want, rule) = expectedRights(p)
        val have = p.rights.trim()
        if (want.isNotEmpty() && have.isEmpty()) {
            out.add(Finding(
                Level.WARN, rule,
                "This land should carry Rights = \"$want\"",
                "the sheet says government land takes that; this preset " +
                    "leaves the box alone, so it keeps whatever is already in it",
                fix = "Choose one of the newer DLR presets, or set the rights " +
                    "on the portal yourself."))
        } else if (want.isNotEmpty() && have != want) {
            out.add(Finding(
                Level.WARN, rule,
                "The rights here are \"$have\"; the sheet says \"$want\""))
        } else if (want.isNotEmpty()) {
            out.add(Finding(Level.NOTE, rule, "Rights = $want, as the sheet has it"))
        }

        // ---- rule 11: is the nature sub-category one the sheet names
        val sub = p.subNature.trim()
        if (p.isGovt && sub.isNotEmpty() &&
            sub !in PortalWords.NATURE_SUB.values
        ) {
            out.add(Finding(
                Level.NOTE, "11",
                "Land Nature Sub-Category is \"$sub\"",
                "the sheet names Settlement, Acquired, Allotted (D-Patta) " +
                    "and Relinquished; this is something else, which may be " +
                    "right for this land"))
        }

        // ---- what the preset used to be, before the sheet
        p.supersededBy?.let { newer ->
            if (newer.isNotEmpty()) {
                out.add(Finding(
                    Level.WARN, "1-10",
                    "This preset predates the instruction sheet",
                    "the sheet's own row for this land is \"$newer\"",
                    fix = "Have a look at that one before running a whole file."))
            } else {
                out.add(Finding(
                    Level.NOTE, "1-10",
                    "The sheet has no row for this land",
                    "so this preset is the office's own, not the sheet's"))
            }
        }

        // ---- rule 13: the non-agricultural LPM series
        if (looksNonAgri(p) && records.isNotEmpty()) {
            val low = records.filter {
                val n = it.lpm.trim().replace(",", "").toIntOrNull()
                n != null && n < PortalWords.NON_AGRI_LPM_FROM
            }.map { it.rowNumber }
            if (low.isNotEmpty()) {
                val from = grouped(PortalWords.NON_AGRI_LPM_FROM)
                out.add(Finding(
                    Level.WARN, "13",
                    "${low.size} record(s) are non-agricultural but numbered " +
                        "below $from",
                    "the sheet gives houses, buildings, embankments and the " +
                        "like their own LPM series starting at $from",
                    rows = low,
                    fix = "If these really are non-agricultural, the LPM " +
                        "numbers belong in that series. The app will not " +
                        "renumber them — that is the office's decision."))
            } else {
                out.add(Finding(
                    Level.NOTE, "13",
                    "Every LPM is in the non-agricultural series"))
            }
        }

        // ---- rule 17: Social Welfare Land Acquisition
        if (records.isNotEmpty()) {
            val swla = records
                .filter { it.khata.trim() == PortalWords.SWLA_KHATA }
                .map { it.rowNumber }
            if (swla.isNotEmpty()) {
                out.add(Finding(
                    Level.NOTE, "17",
                    "${swla.size} record(s) use the SWLA khata " +
                        PortalWords.SWLA_KHATA,
                    "the sheet says Social Welfare acquisitions take their " +
                        "own LPM and are never clubbed with a gramakhantam",
                    rows = swla))
            }
        }

        // ---- rules 14 and 15: endowment and wakf are never clubbed
        if (p.id == "endowment" || p.id == "wakf") {
            out.add(Finding(
                Level.WARN, "14 / 15",
                "Endowment and Wakf land gets an LPM of its own",
                "the sheet says these must never share an LPM with any other " +
                    "land, and the details come from the Commissioner's office"))
        }

        return out
    }

    fun summary(findings: List<Finding>): String {
        val stops = findings.count { it.level == Level.STOP }
        val warns = findings.count { it.level == Level.WARN }
        return when {
            stops > 0 -> "$stops thing(s) must be settled before this runs."
            warns > 0 -> "The DLR sheet has $warns thing(s) worth checking first."
            else -> "Nothing in the DLR sheet contradicts this run."
        }
    }

    fun mayRun(findings: List<Finding>): Boolean =
        findings.none { it.level == Level.STOP }

    /** 300001 -> "3,00,001", the way the sheet writes it. */
    fun grouped(n: Int): String {
        val s = n.toString()
        if (s.length <= 3) return s
        val head = s.dropLast(3)
        val tail = s.takeLast(3)
        val parts = ArrayList<String>()
        var rest = head
        while (rest.length > 2) {
            parts.add(0, rest.takeLast(2))
            rest = rest.dropLast(2)
        }
        if (rest.isNotEmpty()) parts.add(0, rest)
        return parts.joinToString(",") + "," + tail
    }
}
