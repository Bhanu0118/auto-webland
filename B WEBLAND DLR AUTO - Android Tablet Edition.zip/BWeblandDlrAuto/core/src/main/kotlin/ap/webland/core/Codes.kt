package ap.webland.core

/**
 * Every named failure, what it means in both languages, and the one
 * thing the app is allowed to offer the person afterwards.
 *
 * The table carries an invariant that the Windows application enforces
 * when the table is built, and this port keeps it in the same place: a
 * failure whose severity is REVIEW may never recommend a retry. REVIEW
 * means the record MAY already be in the portal; offering "try it again"
 * there is how a land register gets two of the same record. The check
 * runs in `init`, so a careless edit fails the first time the app is
 * started rather than in front of a surveyor.
 *
 * Ported from webland_codes.py. The Telugu wording is the application's
 * own, carried across unchanged.
 */

enum class Severity(val rank: Int) {
    INFO(0),
    /** it did not work; trying again is reasonable */
    FAILED(1),
    /** a person must look before anything else happens */
    REVIEW(2),
    /** the run cannot carry on at all */
    FATAL(3),
}

enum class Category {
    SESSION, PAGE, LOOKUP, FIELD, VERIFICATION, SAVE, NETWORK, FILE,
    LICENCE, UNKNOWN,
}

enum class Advice {
    NONE, START, SELECT_FILE, SELECT_WORKFLOW, WAIT, REVIEW_RECORD,
    RETRY_FAILED, RESUME, LOGIN, REGISTER, CONTACT_ADMIN, CHECK_PAGE,
    FIX_FILE, DONE,
}

data class Fault(
    val code: String,
    val category: Category,
    val severity: Severity,
    val advice: Advice,
    val en: String,
    val te: String,
    val technical: String = "",
) {
    fun human(telugu: Boolean): String = if (telugu) te else en

    /** Is offering "try it again" honest for this failure? */
    fun mayRetry(): Boolean =
        severity == Severity.FAILED && advice in Codes.RETRY_ADVICE
}

object Codes {
    /** Advice that asks the portal to take the record again. */
    val RETRY_ADVICE = setOf(Advice.RETRY_FAILED, Advice.RESUME)

    const val SESSION_EXPIRED = "SESSION_EXPIRED"
    const val LOGIN_FAILED = "LOGIN_FAILED"
    const val PAGE_NOT_FOUND = "PAGE_NOT_FOUND"
    const val PAGE_IDENTITY_UNKNOWN = "PAGE_IDENTITY_UNKNOWN"
    const val SURVEY_NOT_FOUND = "SURVEY_NOT_FOUND"
    const val RANGE_NOT_FOUND = "RANGE_NOT_FOUND"
    const val ROW_NOT_FOUND = "ROW_NOT_FOUND"
    const val ROW_NOT_VERIFIED = "ROW_NOT_VERIFIED"
    const val FIELD_MISMATCH = "FIELD_MISMATCH"
    const val FIELD_LOCKED = "FIELD_LOCKED"
    const val KHATA_NOT_FOUND = "KHATA_NOT_FOUND"
    const val SAVE_UNKNOWN = "SAVE_UNKNOWN"
    const val SAVE_CONFIRMED = "SAVE_CONFIRMED"
    const val SAVE_REFUSED = "SAVE_REFUSED"
    const val DUPLICATE_RECORD = "DUPLICATE_RECORD"
    const val NETWORK_ERROR = "NETWORK_ERROR"
    const val TIMEOUT = "TIMEOUT"
    const val PORTAL_ERROR = "PORTAL_ERROR"
    const val EXCEL_ERROR = "EXCEL_ERROR"
    const val PDF_ERROR = "PDF_ERROR"
    const val CHECKPOINT_ERROR = "CHECKPOINT_ERROR"
    const val DIGITAL_SIGN_ERROR = "DIGITAL_SIGN_ERROR"
    const val LICENSE_BLOCKED = "LICENSE_BLOCKED"
    const val LICENSE_EXPIRED = "LICENSE_EXPIRED"
    const val MACHINE_MISMATCH = "MACHINE_MISMATCH"
    const val REGISTRATION_REQUIRED = "REGISTRATION_REQUIRED"
    const val UNKNOWN_ERROR = "UNKNOWN_ERROR"

    private val table: List<Fault> = listOf(
        Fault("SESSION_EXPIRED", Category.SESSION, Severity.FATAL, Advice.LOGIN,
            en = "The portal signed you out. Sign in again in the same Chrome window, open the page, and press Start — it carries on from where it stopped.",
            te = "పోర్టల్ లాగౌట్ చేసింది. అదే Chrome లో మళ్ళీ లాగిన్ అయ్యి, ఆ పేజీ తెరిచి, Start నొక్కండి — ఆగిన చోటు నుంచే కొనసాగుతుంది.",
            technical = "session cookie rejected or login page returned"),
        Fault("LOGIN_FAILED", Category.SESSION, Severity.FATAL, Advice.LOGIN,
            en = "The portal did not accept the sign-in. Sign in by hand in Chrome first, then press Start.",
            te = "పోర్టల్ లాగిన్ తీసుకోలేదు. ముందు Chrome లో మీరే లాగిన్ అయ్యి, తర్వాత Start నొక్కండి.",
            technical = "login form still present after submit"),
        Fault("PAGE_NOT_FOUND", Category.PAGE, Severity.FAILED, Advice.CHECK_PAGE,
            en = "The page this task needs was not open. Open the right page in Chrome and press 'Page test' to check it.",
            te = "ఈ పనికి కావలసిన పేజీ తెరిచి లేదు. Chrome లో సరైన పేజీ తెరిచి, 'Page test' నొక్కి చూడండి.",
            technical = "required anchors absent from every frame"),
        Fault("PAGE_IDENTITY_UNKNOWN", Category.PAGE, Severity.REVIEW, Advice.CHECK_PAGE,
            en = "This does not look like the page it should be, and I will not type into a page I cannot name. Check Chrome, then press 'Page test'.",
            te = "ఇది ఉండాల్సిన పేజీలా లేదు. ఏ పేజీనో తెలియకుండా టైప్ చేయను. Chrome చూసి, 'Page test' నొక్కండి.",
            technical = "page score below threshold or tied between frames"),
        Fault("SURVEY_NOT_FOUND", Category.LOOKUP, Severity.FAILED, Advice.FIX_FILE,
            en = "That survey number was not in the portal's list. Check the spelling in the Excel file against the list on the page.",
            te = "ఆ సర్వే నంబరు పోర్టల్ జాబితాలో లేదు. Excel లో ఉన్నది పేజీలో ఉన్న జాబితాతో సరిపోల్చి చూడండి.",
            technical = "option not present in survey dropdown"),
        Fault("RANGE_NOT_FOUND", Category.LOOKUP, Severity.FAILED, Advice.FIX_FILE,
            en = "That range was not offered for this survey number. Check the Excel file against what the page lists.",
            te = "ఈ సర్వే నంబరుకి ఆ range రాలేదు. పేజీలో ఉన్నదానితో Excel సరిపోల్చండి.",
            technical = "option not present in range dropdown"),
        Fault("KHATA_NOT_FOUND", Category.LOOKUP, Severity.FAILED, Advice.FIX_FILE,
            en = "The portal found nothing for that khata number, so the holder boxes never appeared. Check the khata number for this record.",
            te = "ఆ ఖాతా నంబరుకి పోర్టల్‌లో ఏమీ రాలేదు, అందుకే holder బాక్సులు రాలేదు. ఈ రికార్డు ఖాతా నంబరు చూడండి.",
            technical = "khata lookup returned no holder rows"),
        Fault("ROW_NOT_FOUND", Category.LOOKUP, Severity.FAILED, Advice.CHECK_PAGE,
            en = "The row this record belongs to was not on the grid. Check the page is showing the right survey number and range.",
            te = "ఈ రికార్డు వరుస గ్రిడ్‌లో కనిపించలేదు. పేజీలో సరైన సర్వే నంబరు, range ఉన్నాయా చూడండి.",
            technical = "row key not found in grid after reload"),
        Fault("ROW_NOT_VERIFIED", Category.VERIFICATION, Severity.REVIEW, Advice.REVIEW_RECORD,
            en = "The row was filled, but reading it back did not confirm it. Look at this row in the portal before doing anything else with it.",
            te = "వరుస నింపాము కానీ తిరిగి చదివితే నిర్ధారణ కాలేదు. ఈ వరుసను పోర్టల్‌లో ఒకసారి చూసిన తర్వాతే ముందుకు వెళ్ళండి.",
            technical = "row read-back did not match what was written"),
        Fault("FIELD_MISMATCH", Category.FIELD, Severity.REVIEW, Advice.REVIEW_RECORD,
            en = "A box did not keep the value that was typed into it. That record needs looking at before it is trusted.",
            te = "టైప్ చేసిన విలువ ఒక బాక్సులో నిలవలేదు. ఆ రికార్డు నమ్మే ముందు ఒకసారి చూడాలి.",
            technical = "read-back differed from written value"),
        Fault("FIELD_LOCKED", Category.FIELD, Severity.FAILED, Advice.REVIEW_RECORD,
            en = "The portal filled that box itself and will not let it be changed. The app kept the portal's value. If it is wrong, it has to be fixed on the portal.",
            te = "ఆ బాక్సును పోర్టలే నింపింది, మార్చనివ్వదు. యాప్ పోర్టల్ విలువనే ఉంచింది. తప్పుంటే పోర్టల్‌లోనే సరిచేయాలి.",
            technical = "element readonly or disabled"),
        Fault("SAVE_CONFIRMED", Category.SAVE, Severity.INFO, Advice.NONE,
            en = "Saved, and the portal confirmed it.",
            te = "సేవ్ అయ్యింది, పోర్టల్ నిర్ధారించింది.",
            technical = "positive save confirmation observed"),
        Fault("SAVE_REFUSED", Category.SAVE, Severity.FAILED, Advice.FIX_FILE,
            en = "The portal looked at the record and refused it. Its own message is in the log — that says which value it did not like.",
            te = "పోర్టల్ రికార్డు చూసి తిరస్కరించింది. దాని సందేశం log లో ఉంది — ఏ విలువ నచ్చలేదో అది చెబుతుంది.",
            technical = "portal validation message after save"),
        Fault("SAVE_UNKNOWN", Category.SAVE, Severity.REVIEW, Advice.REVIEW_RECORD,
            en = "Save was pressed, but the portal gave no answer either way. It may or may not be in. Check this one in the portal before saving it again — saving twice makes two records.",
            te = "Save నొక్కాము కానీ పోర్టల్ ఏమీ చెప్పలేదు. లోపలికి వెళ్ళిందో లేదో తెలియదు. మళ్ళీ save చేసే ముందు పోర్టల్‌లో చూడండి — రెండుసార్లు save చేస్తే రెండు రికార్డులు అవుతాయి.",
            technical = "no confirmation and no error after save"),
        Fault("DUPLICATE_RECORD", Category.SAVE, Severity.INFO, Advice.NONE,
            en = "That record is already in the portal, so it was left alone.",
            te = "ఆ రికార్డు పోర్టల్‌లో ఇప్పటికే ఉంది, అందుకే ముట్టుకోలేదు.",
            technical = "portal reported duplicate"),
        Fault("NETWORK_ERROR", Category.NETWORK, Severity.FAILED, Advice.RETRY_FAILED,
            en = "The portal could not be reached. Check the internet, then retry the ones that failed.",
            te = "పోర్టల్ అందలేదు. ఇంటర్నెట్ చూసి, కానివాటిని retry చేయండి.",
            technical = "network request failed"),
        Fault("TIMEOUT", Category.NETWORK, Severity.FAILED, Advice.RETRY_FAILED,
            en = "The portal took too long to answer. On a slow day, set the speed to 'Careful' in Settings and retry the ones that failed.",
            te = "పోర్టల్ సమాధానం రావడానికి చాలా సమయం పట్టింది. నెమ్మదిగా ఉన్న రోజు Settings లో వేగం 'Careful' పెట్టి retry చేయండి.",
            technical = "wait exceeded its budget"),
        Fault("PORTAL_ERROR", Category.NETWORK, Severity.FAILED, Advice.RETRY_FAILED,
            en = "The portal returned an error of its own. Usually it is busy; retry the failed ones in a few minutes.",
            te = "పోర్టల్ దాని సొంత error ఇచ్చింది. సాధారణంగా busy గా ఉన్నప్పుడు వస్తుంది; కాసేపాగి retry చేయండి.",
            technical = "server error page"),
        Fault("EXCEL_ERROR", Category.FILE, Severity.FAILED, Advice.FIX_FILE,
            en = "The Excel file could not be read as expected. Check the columns matched correctly on the Data page.",
            te = "Excel ఫైల్ సరిగ్గా చదవలేకపోయాం. Data పేజీలో కాలమ్‌లు సరిగ్గా కలిశాయా చూడండి.",
            technical = "workbook read or column mapping failed"),
        Fault("PDF_ERROR", Category.FILE, Severity.FAILED, Advice.FIX_FILE,
            en = "The PDF could not be attached. Choose a smaller PDF in Settings, or use the blank page that comes with the app.",
            te = "PDF జత చేయలేకపోయాం. Settings లో చిన్న PDF ఎంచుకోండి, లేదా యాప్‌తో వచ్చే ఖాళీ పేజీ వాడండి.",
            technical = "file input rejected the attachment"),
        Fault("CHECKPOINT_ERROR", Category.FILE, Severity.FAILED, Advice.START,
            en = "The saved position could not be read, so the run cannot pick up where it stopped. Starting again from the first record is safe — records already in the portal are recognised and skipped.",
            te = "ఆగిన చోటు చదవలేకపోయాం, కాబట్టి అక్కడి నుంచి కొనసాగించలేం. మొదటి నుంచి మొదలుపెట్టడం సురక్షితమే — పోర్టల్‌లో ఉన్నవి గుర్తించి వదిలేస్తుంది.",
            technical = "checkpoint missing or failed its identity check"),
        Fault("DIGITAL_SIGN_ERROR", Category.VERIFICATION, Severity.REVIEW, Advice.REVIEW_RECORD,
            en = "The signing could not be confirmed. Look at the portal and see which rows actually carry a signature before signing anything again.",
            te = "సంతకం అయిందో లేదో నిర్ధారణ కాలేదు. మళ్ళీ సంతకం చేసే ముందు, పోర్టల్‌లో ఏ వరుసలకు సంతకం పడిందో చూడండి.",
            technical = "sign state could not be read back"),
        Fault("LICENSE_BLOCKED", Category.LICENCE, Severity.FATAL, Advice.CONTACT_ADMIN,
            en = "The administrator has blocked this copy. Contact him with the registration ID shown on the licence screen.",
            te = "ఈ కాపీని నిర్వాహకుడు ఆపేశారు. లైసెన్స్ స్క్రీన్‌లో ఉన్న registration ID తో ఆయన్ని సంప్రదించండి.",
            technical = "server returned BLOCKED"),
        Fault("LICENSE_EXPIRED", Category.LICENCE, Severity.FATAL, Advice.CONTACT_ADMIN,
            en = "This registration has expired. Contact the administrator to renew it.",
            te = "ఈ registration గడువు ముగిసింది. పునరుద్ధరణకు నిర్వాహకుడిని సంప్రదించండి.",
            technical = "server returned EXPIRED"),
        Fault("MACHINE_MISMATCH", Category.LICENCE, Severity.FATAL, Advice.CONTACT_ADMIN,
            en = "This registration belongs to a different computer. The administrator has to move it to this one.",
            te = "ఈ registration వేరే కంప్యూటర్‌ది. నిర్వాహకుడు దీన్ని ఈ కంప్యూటర్‌కి మార్చాలి.",
            technical = "machine_id did not match the registered one"),
        Fault("REGISTRATION_REQUIRED", Category.LICENCE, Severity.FATAL, Advice.REGISTER,
            en = "This copy has not been registered yet. Fill in the registration screen — your details go to the administrator's own spreadsheet.",
            te = "ఈ కాపీ ఇంకా register కాలేదు. registration స్క్రీన్ నింపండి — మీ వివరాలు నిర్వాహకుడి స్ప్రెడ్‌షీట్‌కే వెళ్తాయి.",
            technical = "no registration id on this machine"),
        Fault("UNKNOWN_ERROR", Category.UNKNOWN, Severity.FAILED, Advice.CHECK_PAGE,
            en = "Something went wrong that I do not have a name for. If only one record failed, the rest carry on. If several fail in a row, press Stop, check the portal page, and press 'Page test'.",
            te = "పేరు తెలియని సమస్య వచ్చింది. ఒక్క రికార్డే ఆగితే మిగతావి కొనసాగుతాయి. వరుసగా చాలా ఆగితే Stop నొక్కి, పోర్టల్ పేజీ చూసి, 'Page test' నొక్కండి.",
            technical = "unclassified failure")
    )

    val ALL: Map<String, Fault>

    init {
        val bad = table.filter {
            it.severity == Severity.REVIEW && it.advice in RETRY_ADVICE
        }
        require(bad.isEmpty()) {
            "A REVIEW failure may not recommend a retry: " +
                bad.joinToString { it.code + " -> " + it.advice }
        }
        val out = LinkedHashMap<String, Fault>()
        for (f in table) out[f.code] = f
        ALL = out
    }

    fun of(code: String): Fault = ALL[code] ?: ALL.getValue(UNKNOWN_ERROR)

    /** The worst thing that happened decides what the run may offer. */
    fun worst(codes: Collection<String>): Fault? =
        codes.mapNotNull { ALL[it] }.maxByOrNull { it.severity.rank }
}
