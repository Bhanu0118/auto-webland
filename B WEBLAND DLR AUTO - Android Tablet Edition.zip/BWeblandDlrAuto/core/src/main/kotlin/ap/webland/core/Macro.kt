package ap.webland.core

/**
 * What a recorded step is, and the file a recording lives in.
 *
 * A recorded automation is DATA and nothing else. It lists actions to
 * take; it contains no code, no expressions, no formulas, and nothing
 * that loads one is permitted to execute anything it finds inside. That
 * is not a style preference - a .bwa file is a thing people send each
 * other, and a file format that can run code is a file format that will
 * eventually run somebody else's.
 *
 * So loading is a gate, not a parse. Every action must be one of a fixed
 * list. Every field must be of the expected type. Anything unrecognised
 * is dropped and reported, never carried along in the hope it is
 * harmless.
 *
 * The second rule is about secrets. A recorder watching somebody sign in
 * watches them type their password. The value of a password field is
 * NEVER stored - not in the file, not in the log, not in an error
 * message. What is stored is a note that a secret belongs there, and the
 * person supplies it at the moment of replay.
 *
 * Ported from recorder/model.py; the format is unchanged, so a recording
 * made on the Windows application opens here and the other way round.
 */

enum class Act(val title: String, val mark: String) {
    OPEN("Open page", "🌐"),
    CLICK("Click", "🖱"),
    DOUBLE_CLICK("Double click", "🖱"),
    RIGHT_CLICK("Right click", "🖱"),
    HOVER("Hover", "👆"),
    TYPE("Type", "⌨"),
    CLEAR("Clear", "⌫"),
    PRESS("Press key", "⌨"),
    SELECT("Choose", "🔽"),
    CHECK("Tick", "☑"),
    UNCHECK("Untick", "☐"),
    UPLOAD("Attach file", "📎"),
    WAIT("Wait", "⏳"),
    BACK("Go back", "←"),
    FORWARD("Go forward", "→"),
    RELOAD("Reload", "↻"),
    COMMENT("Note", "💬");

    /** The word written in the file. */
    val key: String get() = name.lowercase()

    val needsTarget: Boolean get() = this in NEEDS_TARGET
    val takesValue: Boolean get() = this in TAKES_VALUE

    companion object {
        val NEEDS_TARGET = setOf(CLICK, DOUBLE_CLICK, RIGHT_CLICK, HOVER,
            TYPE, CLEAR, PRESS, SELECT, CHECK, UNCHECK, UPLOAD)
        val TAKES_VALUE = setOf(TYPE, SELECT, PRESS, OPEN, UPLOAD, WAIT, COMMENT)

        fun of(word: String?): Act? =
            entries.firstOrNull { it.key == (word ?: "").trim().lowercase() }
    }
}

/**
 * Never a bare number of seconds where a condition will do. A recorded
 * pause of 137ms tells you nothing about what was being waited for; a
 * named condition survives a slow day and a fast one alike.
 */
enum class Wait(val says: String) {
    ELEMENT("for the box to exist"),
    VISIBLE("for it to be visible"),
    ENABLED("for it to be usable"),
    GONE("for it to go away"),
    TEXT("for the words to appear"),
    URL("for the address to change"),
    PAGE("for the page to finish loading"),
    NAVIGATION("for the page to change"),
    SAVE_CONFIRMATION("for the portal to confirm the save"),
    SECONDS("a fixed time (better to wait for something)");

    val key: String get() = name.lowercase()

    companion object {
        fun of(word: String?): Wait? =
            entries.firstOrNull { it.key == (word ?: "").trim().lowercase() }
    }
}

/**
 * A click on Save is not the same as a click on Add, even though both
 * are clicks. Knowing which is which is what lets replay wait for the
 * right thing afterwards, and what stops a Save being retried blindly.
 */
enum class Meaning {
    NONE, SAVE, ADD, NEW, SUBMIT, SEARCH, DELETE, CANCEL;

    val key: String get() = if (this == NONE) "" else name

    /** A step that changes the record in the portal. */
    val writes: Boolean get() = this in WRITING

    companion object {
        val WRITING = setOf(SAVE, ADD, SUBMIT, DELETE)

        /** Words on a button, longest first so "save and new" wins. */
        private val WORDS = listOf(
            "save and new" to SAVE, "save & new" to SAVE, "update" to SAVE,
            "submit" to SUBMIT, "save" to SAVE, "add record" to ADD,
            "add new" to NEW, "add" to ADD, "new" to NEW,
            "search" to SEARCH, "find" to SEARCH, "go" to SEARCH,
            "delete" to DELETE, "remove" to DELETE,
            "cancel" to CANCEL, "close" to CANCEL, "back" to CANCEL)

        fun of(word: String?): Meaning =
            entries.firstOrNull { it.name == (word ?: "").trim().uppercase() }
                ?: NONE

        /** What a button's words mean, if anything. */
        fun ofText(text: String?): Meaning {
            val low = (text ?: "").lowercase().split(Regex("\\s+"))
                .filter { it.isNotEmpty() }.joinToString(" ")
            if (low.isEmpty()) return NONE
            for ((word, meaning) in WORDS) if (word in low) return meaning
            return NONE
        }
    }
}

/**
 * How a step finds its box. Several candidates are kept, best first,
 * because an id that works today may be gone after a portal change and
 * the label beside the box usually is not.
 */
data class Target(val parts: Map<String, String> = emptyMap()) {
    val id: String get() = parts["id"] ?: ""
    val css: String get() = parts["css"] ?: ""
    val xpath: String get() = parts["xpath"] ?: ""
    val label: String get() = parts["label"] ?: ""
    val text: String get() = parts["text"] ?: ""
    val name: String get() = parts["name"] ?: ""

    val isEmpty: Boolean get() = parts.values.none { it.isNotBlank() }

    /** What this step is about, in the person's words. */
    fun spoken(): String {
        for (key in listOf("label", "name", "aria", "placeholder", "text", "id_tail")) {
            val got = (parts[key] ?: "").trim()
            if (got.isNotEmpty()) return got.take(60)
        }
        return "(that box)"
    }

    /**
     * How safely this box can be found again.
     *
     * "strong"  an id or a name the portal gave it
     * "fair"    a label, or words on the element
     * "weak"    position only: it will probably work and may not
     * "none"    nothing usable
     */
    fun strength(): Pair<String, String> = when {
        id.isNotBlank() -> "strong" to "found by its own id"
        name.isNotBlank() -> "strong" to "found by its form name"
        label.isNotBlank() -> "fair" to "found by the label beside it"
        text.isNotBlank() -> "fair" to "found by the words on it"
        css.isNotBlank() || xpath.isNotBlank() ->
            "weak" to "found only by where it sits on the page"
        else -> "none" to "nothing in the recording says which box this is"
    }

    fun toJson(): Json = Json.map(parts)

    companion object {
        val KEYS = listOf("id", "name", "css", "xpath", "label", "text",
            "aria", "placeholder", "id_tail", "tag", "index", "frame")

        fun of(raw: Json?): Target {
            val out = LinkedHashMap<String, String>()
            val obj = raw as? Json.Obj ?: return Target(out)
            for ((k, v) in obj.fields) {
                if (k !in KEYS) continue
                when (v) {
                    is Json.Str -> out[k] = v.value.take(400)
                    is Json.Num -> out[k] = Json.numberText(v.value)
                    else -> {}
                }
            }
            return Target(out)
        }
    }
}

/** One recorded action. */
data class Step(
    var id: String = "",
    val act: Act = Act.CLICK,
    val target: Target = Target(),
    var value: String = "",
    val meaning: Meaning = Meaning.NONE,
    val wait: Wait = if (act.needsTarget) Wait.VISIBLE else Wait.PAGE,
    val waitFor: String = "",
    val timeoutMs: Int = 15_000,
    val enabled: Boolean = true,
    val secret: Boolean = false,
    val optional: Boolean = false,
    val note: String = "",
    val screenshotOnFail: Boolean = true,
) {
    init {
        // a secret's value is never carried, whatever was passed in
        if (secret) value = Macro.SECRET_MARK
        value = value.take(400)
    }

    fun label(): String = target.spoken()

    /** One line, readable by somebody who has never seen a selector. */
    fun describe(): String = when (act) {
        Act.WAIT -> "${act.mark}  ${act.title.padEnd(12)} ${wait.says}" +
            if (waitFor.isNotBlank()) " — $waitFor" else ""
        Act.BACK, Act.FORWARD, Act.RELOAD -> "${act.mark}  ${act.title}"
        Act.OPEN -> "${act.mark}  ${act.title.padEnd(12)} ${value.take(70)}"
        Act.COMMENT -> "${act.mark}  ${value.take(70)}"
        Act.TYPE, Act.SELECT, Act.UPLOAD -> {
            val shown = if (secret) Macro.SECRET_MARK else value
            "${act.mark}  ${act.title.padEnd(12)} ${label()} = \"${shown.take(40)}\""
        }
        Act.PRESS ->
            "${act.mark}  ${act.title.padEnd(12)} ${value.ifBlank { "Enter" }} in ${label()}"
        else -> {
            val extra = if (meaning == Meaning.NONE) "" else "  [${meaning.key}]"
            "${act.mark}  ${act.title.padEnd(12)} \"${label()}\"$extra"
        }
    }

    /** Only what differs from the ordinary is written, so a recording
     *  stays readable by a person opening it in a text editor. */
    fun toJson(): Json {
        val out = LinkedHashMap<String, Json>()
        out["id"] = Json.s(id)
        out["action"] = Json.s(act.key)
        out["target"] = target.toJson()
        out["value"] = Json.s(if (secret) Macro.SECRET_MARK else value)
        out["wait"] = Json.s(wait.key)
        out["timeout"] = Json.n(timeoutMs)
        out["enabled"] = Json.b(enabled)
        if (meaning != Meaning.NONE) out["semantic"] = Json.s(meaning.key)
        if (waitFor.isNotBlank()) out["wait_for"] = Json.s(waitFor)
        if (secret) out["secret"] = Json.b(true)
        if (optional) out["optional"] = Json.b(true)
        if (note.isNotBlank()) out["note"] = Json.s(note)
        if (!screenshotOnFail) out["screenshot_on_fail"] = Json.b(false)
        return Json.Obj(out)
    }

    companion object {
        /**
         * A step out of a file, or null if it is not one. Anything
         * unexpected is refused here rather than allowed in and dealt
         * with later; `trouble` collects the reasons.
         */
        fun of(raw: Json, trouble: MutableList<String>): Step? {
            if (raw !is Json.Obj) {
                trouble.add("a step that is not a set of fields")
                return null
            }
            val act = Act.of(raw.str("action"))
            if (act == null) {
                trouble.add("unknown action \"${raw.str("action").take(30)}\"")
                return null
            }
            val targetRaw = raw["target"]
            if (targetRaw != null && targetRaw !is Json.Obj && targetRaw !is Json.Null) {
                trouble.add("a step whose target is not a set of fields")
                return null
            }
            val valueRaw = raw["value"]
            if (valueRaw != null && valueRaw !is Json.Str && valueRaw !is Json.Num &&
                valueRaw !is Json.Null
            ) {
                trouble.add("a step whose value is not text")
                return null
            }
            // A file is not allowed to carry a password. The removal is
            // reported here, where the value still exists to notice; the
            // step itself never holds it, because Step's own init
            // replaces a secret's value with the mark.
            if (raw.bool("secret", false) && raw.str("value") != Macro.SECRET_MARK &&
                raw.str("value").isNotEmpty()
            ) trouble.add("a password was found in the file and removed")

            return Step(
                id = raw.str("id"),
                act = act,
                target = Target.of(targetRaw),
                value = raw.str("value"),
                meaning = Meaning.of(raw.str("semantic")),
                wait = Wait.of(raw.str("wait"))
                    ?: if (act.needsTarget) Wait.VISIBLE else Wait.PAGE,
                waitFor = raw.str("wait_for").take(200),
                timeoutMs = raw.int("timeout", 15_000).coerceIn(1_000, 180_000),
                enabled = raw.bool("enabled", true),
                secret = raw.bool("secret", false),
                optional = raw.bool("optional", false),
                note = raw.str("note").take(200),
                screenshotOnFail = raw.bool("screenshot_on_fail", true),
            )
        }
    }
}

/** A recording: its steps, and what it is bound to. */
class Automation(var name: String = "Untitled") {
    val steps: MutableList<Step> = ArrayList()
    var createdAt: String = ""
    var appVersion: String = ""
    /** remembered, never embedded */
    var dataFile: String = ""
    var sheet: String = ""
    /** step value name -> spreadsheet column */
    var mapping: MutableMap<String, String> = LinkedHashMap()
    var startUrl: String = ""
    var beginner: Boolean = true
    var screenshots: Boolean = true
    var stopAfterFailures: Int = 5
    /** what was refused when this was loaded */
    val trouble: MutableList<String> = ArrayList()

    fun nextId(): String {
        var n = steps.size + 1
        while (true) {
            val key = "step_%03d".format(n)
            if (steps.none { it.id == key }) return key
            n++
        }
    }

    fun add(step: Step, at: Int? = null): Step {
        if (step.id.isBlank()) step.id = nextId()
        if (at == null) steps.add(step)
        else steps.add(at.coerceIn(0, steps.size), step)
        return step
    }

    fun byId(key: String): Step? = steps.firstOrNull { it.id == key }
    fun indexOf(key: String): Int = steps.indexOfFirst { it.id == key }

    fun remove(key: String): Step? {
        val i = indexOf(key)
        return if (i < 0) null else steps.removeAt(i)
    }

    fun move(key: String, by: Int): Boolean {
        val i = indexOf(key)
        if (i < 0) return false
        val j = (i + by).coerceIn(0, steps.size - 1)
        if (i == j) return false
        steps.add(j, steps.removeAt(i))
        return true
    }

    fun duplicate(key: String): Step? {
        val step = byId(key) ?: return null
        val copy = step.copy(id = "")
        return add(copy, indexOf(key) + 1)
    }

    fun live(): List<Step> = steps.filter { it.enabled }

    /** The steps that change something in the portal. */
    fun writes(): List<Step> = live().filter { it.meaning.writes }

    /** Every {{Column}} named anywhere in this recording, in order. */
    fun variables(): List<String> {
        val seen = LinkedHashSet<String>()
        for (s in steps) {
            seen.addAll(Bind.namesIn(s.value))
            seen.addAll(Bind.namesIn(s.waitFor))
        }
        return seen.toList()
    }

    fun toJson(): Json {
        val out = LinkedHashMap<String, Json>()
        out["format"] = Json.s(Macro.FORMAT)
        out["version"] = Json.n(Macro.VERSION)
        out["name"] = Json.s(name)
        out["created_at"] = Json.s(createdAt)
        out["app_version"] = Json.s(appVersion)
        out["start_url"] = Json.s(startUrl)
        out["data_file"] = Json.s(dataFile)
        out["sheet"] = Json.s(sheet)
        out["mapping"] = Json.map(mapping)
        out["settings"] = Json.of(
            "beginner" to Json.b(beginner),
            "screenshots" to Json.b(screenshots),
            "stop_after_failures" to Json.n(stopAfterFailures))
        out["steps"] = Json.a(steps.map { it.toJson() })
        return Json.Obj(out)
    }

    fun write(): String = Json.write(toJson(), indent = 1)
}

object Macro {
    const val FORMAT = "B_WEBLAND_AUTOMATION"
    const val VERSION = 1
    const val EXT = ".bwa"
    const val MAX_BYTES = 8 * 1024 * 1024
    const val MAX_STEPS = 2000
    const val SECRET_MARK = "{{PASSWORD}}"

    /**
     * Read a recording. Never executes anything.
     *
     * Everything about this function assumes the file came from somebody
     * else: it is checked for size before it is read, parsed as data,
     * and every part of it is examined before it is kept.
     */
    fun read(text: String): Automation {
        if (text.length > MAX_BYTES)
            throw JsonError("That file is too large to be a recording.")
        val raw = Json.parse(text)
        if (raw !is Json.Obj) throw JsonError("That file does not hold a recording.")
        if (raw.str("format") != FORMAT)
            throw JsonError("That file is not a B Webland recording.")
        val version = raw.int("version", 0)
        if (version < 1)
            throw JsonError("That recording has no version and cannot be read.")
        if (version > VERSION)
            throw JsonError(
                "That recording was made by a newer version of the app " +
                    "(it says version $version; this one understands $VERSION).")

        val auto = Automation(raw.str("name").ifBlank { "Untitled" }.take(80))
        auto.createdAt = raw.str("created_at").take(40)
        auto.appVersion = raw.str("app_version").take(20)
        auto.startUrl = safeUrl(raw.str("start_url"), auto.trouble)
        auto.dataFile = raw.str("data_file").take(400)
        auto.sheet = raw.str("sheet").take(100)

        for ((k, v) in raw.textMap("mapping")) auto.mapping[k.take(60)] = v.take(80)
        raw.obj("settings")?.let { s ->
            auto.beginner = s.bool("beginner", auto.beginner)
            auto.screenshots = s.bool("screenshots", auto.screenshots)
            auto.stopAfterFailures =
                s.int("stop_after_failures", auto.stopAfterFailures)
                    .coerceIn(1, 1000)
        }

        val steps = raw["steps"]
        if (steps !is Json.Arr) throw JsonError("That recording has no steps in it.")
        if (steps.items.size > MAX_STEPS)
            throw JsonError("That recording has ${steps.items.size} steps. " +
                "The limit is $MAX_STEPS.")
        for (one in steps.items) Step.of(one, auto.trouble)?.let { auto.add(it) }

        // A recording is not allowed to carry a secret, whoever wrote it.
        for (step in auto.steps) {
            if (step.secret && step.value != SECRET_MARK) {
                step.value = SECRET_MARK
                auto.trouble.add("a password was found in the file and removed")
            }
        }
        return auto
    }

    /** A web address, or nothing. No file://, no javascript:, no data:. */
    fun safeUrl(value: String?, trouble: MutableList<String>): String {
        val url = (value ?: "").trim().take(500)
        if (url.isEmpty()) return ""
        val low = url.lowercase()
        if (low.startsWith("http://") || low.startsWith("https://")) return url
        trouble.add("an address that is not http or https was removed")
        return ""
    }

    /** A recording's name, made safe to use as a file name. */
    fun safeName(name: String?): String {
        val keep = (name ?: "").filter { it.isLetterOrDigit() || it in " _-." }
        val one = keep.split(Regex("\\s+")).filter { it.isNotEmpty() }
            .joinToString(" ").take(60)
        return one.ifBlank { "Untitled" }
    }
}
