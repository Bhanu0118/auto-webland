// Generated from the reference application's own webland_config.py so
// that not one of the 32 land-type rows is retyped by hand. Do not edit
// the values here to fix a portal change - the portal's own word is what
// a dropdown must match, and PortalWords.kt is where a correction goes.
package ap.webland.core

/** One row of the land-nature table: the whole dropdown chain for a kind
 *  of land, exactly as the Windows application has it. */
data class LandPreset(
    val id: String,
    val te: String,
    val en: String,
    val nature: String,
    val classification: String,
    val broadNature: String,
    val subNature: String,
    val subNatureA: String,
    val subNatureB: String,
    val broadClass: String,
    val subClass: String,
    val subClassA: String,
    val subClassText: String,
    val landUse: String,
    val irrigation: String,
    val rights: String,
    val action: String,
    /** "P" fill the pattadar boxes, "E" fill the enjoyer boxes. */
    val holder: String,
    /** true when this row comes from the DLR instruction sheet. */
    val fromDlrSheet: Boolean = false,
    /** set when the sheet has replaced this preset: the newer id, or ""
     *  when the sheet has no row for this land at all. */
    val supersededBy: String? = null,
) {
    val isGovt: Boolean get() = broadNature == PortalWords.GOVT_NATURE
}

object Presets {
    val ALL: List<LandPreset> = listOf(
    LandPreset(id = "dry", te = "మెట్ట (పుంజ)", en = "Dry",
        nature = "పట్టా", classification = "పుంజ",
        broadNature = "Patta Land", subNature = "", subNatureA = "", subNatureB = "",
        broadClass = "Dry", subClass = "-", subClassA = "", subClassText = "",
        landUse = "Agriculture", irrigation = "Minor", rights = "Ancestral", action = "Addition of Survey No",
        holder = "P", fromDlrSheet = false, supersededBy = null),
    LandPreset(id = "irrigated-dry", te = "మానవారి", en = "Irrigated Dry",
        nature = "పట్టా", classification = "మానవారి",
        broadNature = "Patta Land", subNature = "", subNatureA = "", subNatureB = "",
        broadClass = "Irrigated Dry", subClass = "", subClassA = "", subClassText = "",
        landUse = "Agriculture", irrigation = "Minor", rights = "Ancestral", action = "Addition of Survey No",
        holder = "P", fromDlrSheet = false, supersededBy = null),
    LandPreset(id = "wet", te = "నంజ", en = "Wet",
        nature = "పట్టా", classification = "నంజ",
        broadNature = "Patta Land", subNature = "", subNatureA = "", subNatureB = "",
        broadClass = "Wet", subClass = "Medium/Minor Irrigation", subClassA = "", subClassText = "",
        landUse = "Agriculture", irrigation = "Minor", rights = "Ancestral", action = "Addition of Survey No",
        holder = "P", fromDlrSheet = false, supersededBy = null),
    LandPreset(id = "dpatta", te = "డి.పట్టా", en = "D-Patta (Assigned)",
        nature = "డి.పట్టా", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land Alloted", subNatureA = "Assigned (D-Patta)", subNatureB = "Agriculture",
        broadClass = "UnAssessed(U)", subClass = "", subClassA = "", subClassText = "",
        landUse = "Agriculture", irrigation = "Minor", rights = "Assignment", action = "Addition of Survey No",
        holder = "P", fromDlrSheet = false, supersededBy = null),
    LandPreset(id = "lc-land", te = "ఎల్.సి. భూమి", en = "LC Land (Ceiling Surplus)",
        nature = "డి.పట్టా", classification = "నంజ",
        broadNature = "Govt Land", subNature = "Govt.Land-Ceiling Surplus/ULC", subNatureA = "", subNatureB = "",
        broadClass = "Wet", subClass = "Medium/Minor Irrigation", subClassA = "", subClassText = "",
        landUse = "Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "P", fromDlrSheet = false, supersededBy = null),
    LandPreset(id = "grazing", te = "పశువుల బీడు", en = "Grazing Land",
        nature = "ప్ర.భూమి", classification = "పశువుల బీడు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Grazing Ground/Topu/Mandabailu etc.", subClassA = "", subClassText = "Grazing Land",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = false, supersededBy = "grazing-dlr"),
    LandPreset(id = "gayalu", te = "గయాలు", en = "Gayalu",
        nature = "ప్ర.భూమి", classification = "గయాలు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Assessed Waste(AW)", subClass = "", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = false, supersededBy = ""),
    LandPreset(id = "nadhi", te = "నది", en = "Nadhi (River)",
        nature = "ప్ర.భూమి", classification = "నది",
        broadNature = "Govt Land", subNature = "Govt.Land-Relinquished", subNatureA = "", subNatureB = "",
        broadClass = "Dry", subClass = "-", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = false, supersededBy = "river"),
    LandPreset(id = "karakatta", te = "వంశధార కరకట్ట", en = "Vamsadara Karakatta",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Land acquired", subNatureA = "", subNatureB = "",
        broadClass = "Dry", subClass = "-", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = false, supersededBy = ""),
    LandPreset(id = "reservoir-old", te = "రిజర్వాయర్", en = "Reservoir  (old chain, before the DLR sheet)",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Land acquired", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Reservoir", subClassText = "Reservoir",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = false, supersededBy = "reservoir"),
    LandPreset(id = "canal", te = "కాలువ / బోదె", en = "Waterbody — Canal",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Canal", subClassText = "Canal",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "canal-man", te = "పొలాల్లో తీసిన కాలువలు", en = "Waterbody — Canal (Man Made)",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Canal (Man Made)", subClassText = "Canal (Man Made)",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "vagu", te = "వాగు / వంక", en = "Waterbody — Vagu/Vanka/Yeru",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Vagu/Vanka/Yeru", subClassText = "Vagu/Vanka/Yeru",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "river", te = "నది", en = "Waterbody — River",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "River", subClassText = "River",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "tank", te = "చెరువు / కుంట / బండ / కోనేరు", en = "Waterbody — Tank/Cheruvu/Kunta",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Tank/Cheruvu/Kunta", subClassText = "Tank/Cheruvu/Kunta",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "reservoir", te = "రిజర్వాయర్", en = "Waterbody — Reservoir",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Reservoir", subClassText = "Reservoir",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "drainage", te = "మురుగు నీటి కాలువ", en = "Waterbody — Drainage",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Drainage", subClassText = "Drainage",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "water-other", te = "ఇతరములు (నీటి వనరు)", en = "Waterbody — Others",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "WaterBody", subClassA = "Others", subClassText = "Others",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "hill", te = "కొండ / రాళ్లగుట్ట / మెట్ట", en = "Hill / Gutta",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Hill / Gutta", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "nh", te = "జాతీయ రహదారి", en = "Road — National Highways",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "National Highways", subClassText = "National Highways",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "sh", te = "రాష్ట్ర రహదారులు", en = "Road — State Highways",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "State Highways", subClassText = "State Highways",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "district-road", te = "జిల్లా రోడ్", en = "Road — District Road",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "District Road", subClassText = "District Road",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "gp-road", te = "గ్రామ పంచాయతీ రోడ్లు", en = "Road — GP (Grama Panchayat) Road",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "GP (Grama Panchayat) Road", subClassText = "GP (Grama Panchayat) Road",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "puntha", te = "పుంత / బండి జాడ / కాలిబాట", en = "Road — Puntha/Bandi Jada/Kalibaata",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "Puntha/Bandi Jada/Kalibaata", subClassText = "Puntha/Bandi Jada/Kalibaata",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "road-other", te = "ఇతరములు (రోడ్డు)", en = "Road — Others",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Road", subClassA = "Others", subClassText = "Others",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "burial", te = "శ్మశానం / వల్లకాడు", en = "Burial Grounds",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Burial Grounds", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "gramakhantam", te = "గ్రామఖంటం", en = "Gramakhantam",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Gramakhantam", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "railways", te = "రైల్వే లైన్ / రైల్వే స్థలములు", en = "Railways",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Railways", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "bandula-doddy", te = "పశువుల కట్టు సత్రాలు", en = "Bandula Doddy",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Bandula Doddy", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "grazing-dlr", te = "పశువుల బీడు / మంద బయలు", en = "Grazing Ground/Topu/Mandabailu",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Grazing Ground/Topu/Mandabailu etc.", subClassA = "", subClassText = "Grazing Land",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "govt-building", te = "ప్రభుత్వ భవనములు", en = "Govt. Building",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Govt. Building", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null),
    LandPreset(id = "banjar", te = "బంజరు", en = "Banjar",
        nature = "ప్ర.భూమి", classification = "పోరంబోకు",
        broadNature = "Govt Land", subNature = "Govt.Land-Settlement", subNatureA = "", subNatureB = "",
        broadClass = "Poramboke(P)", subClass = "Banjar", subClassA = "", subClassText = "",
        landUse = "Non-Agriculture", irrigation = "Minor", rights = "Govt. Lands", action = "Addition of Survey No",
        holder = "E", fromDlrSheet = true, supersededBy = null)
    )

    fun byId(id: String): LandPreset? = ALL.firstOrNull { it.id == id }
    fun fromSheet(): List<LandPreset> = ALL.filter { it.fromDlrSheet }
    fun older(): List<LandPreset> = ALL.filter { !it.fromDlrSheet }
}

/** The ids of the boxes on each portal page. The site really does
 *  misspell "Calssification"; that is not a typo here. */
object PortalFields {
    val ADD: Map<String, String> = mapOf(
        "add_link" to "Add Record",
        "ready" to "//*[@id=\"divexst\"]/h2",
        "lpm" to "grAddRecord_txtlpmno_0",
        "lpm_extent" to "grAddRecord_txtlpmnoExtent_0",
        "total_extent" to "grAddRecord_txttotalextent_0",
        "syno" to "grAddRecord_txtwebsysno_0",
        "subdiv" to "grAddRecord_txtwebsubno_0",
        "nature" to "grAddRecord_ddlLandNature1_0",
        "classification" to "grAddRecord_ddlLandClassification1_0",
        "bnature" to "grAddRecord_ddlBroadCategory_LandNature1_0",
        "snature" to "grAddRecord_ddlSubCategory_LandNature1_0",
        "snature_a" to "grAddRecord_ddlSubCategory_LandNature1_SubA_0",
        "snature_b" to "grAddRecord_ddlSubCategory_LandNature1_SubB_0",
        "bclass" to "grAddRecord_ddlBroadCategory_LandCalssification1_0",
        "sclass" to "grAddRecord_ddlSubCategory_LandClassification1_0",
        "sclass_a" to "grAddRecord_ddlSubCategory_LandClassification1_SubA_0",
        "sclass_text" to "grAddRecord_txtlSubCategory_LandClassification1_0",
        "land_use" to "grAddRecord_ddlnatureoflanduse_0",
        "irrigation" to "grAddRecord_ddlSourceOfIrrigiAdd_0",
        "khata" to "grAddRecord_txtkhatano_0",
        "khata_btn" to "grAddRecord_btnKhata_0",
        "pat_name" to "grAddRecord_txtPattadarName_0",
        "pat_name2" to "grAddRecord_txtpattdarname_0",
        "pat_fname" to "grAddRecord_txtpattadarFname_0",
        "pat_extent" to "grAddRecord_txtpattadarExtent_0",
        "enj_name" to "grAddRecord_txtEnjoyerName_0",
        "enj_fname" to "grAddRecord_txtEnjoyerFname_0",
        "enj_extent" to "grAddRecord_txtEnjoyerExtent_0",
        "rights" to "grAddRecord_ddlrightsreq_0",
        "action" to "grAddRecord_ddlactionreq_0",
        "joint_no" to "grAddRecord_rbllistcultivate_add_0_1_0",
        "add_btn" to "btnAdd"
    )
    val VS: Map<String, String> = mapOf(
        "surveyno" to "ddlsurveyno",
        "rowrange" to "ddlRowRange",
        "subdiv" to "txtNSubDivisionNo",
        "chaltha" to "txtChaltha",
        "lpm" to "txtLPMNO",
        "lpmext" to "txtLPMNOExtent",
        "remarks" to "ddlremarks",
        "desc" to "txtDesremarks",
        "save" to "btnsave",
        "check" to "chckSelect",
        "action" to "ddlAction",
        "submit" to "btnsubmit"
    )
    val VRO: Map<String, String> = mapOf(
        "surveyno" to "ddlsurveyno",
        "rowrange" to "ddlRowRange",
        "bnature" to "ddlBroadCategory_LandNature_GT",
        "snature" to "ddlSubCategory_LandNature1_GT",
        "bclass" to "ddlBroadCategory_LandClassification_GT",
        "sclass" to "ddlSubCategory_LandClassification1_GT",
        "landuse" to "ddlnatureoflanduse",
        "irrigation" to "ddlSourceOfIrrigi",
        "enature" to "ddlENature_GT"
    )
    val SIGN: Map<String, String> = mapOf(
        "lpmlist" to "ddlLPMno",
        "bulk" to "btnbulkdigital",
        "sign" to "btndigi"
    )
}

object PortalWords {
    const val START_URL = "https://webland2.ap.gov.in/POLR6/loginpage.aspx"
    const val GOVT_NATURE = "Govt Land"
    const val GOVT_SETTLEMENT = "Govt.Land-Settlement"
    const val PORAMBOKE = "Poramboke(P)"
    const val GOVT_RIGHTS = "Govt. Lands"
    const val ACTION_ADD = "Addition of Survey No"

    /** Rule 19 - which rights go with which kind of land. */
    val RIGHTS_BY_LAND: Map<String, String> = mapOf(
        "govt" to "Govt. Lands",
        "dpatta" to "Assignment",
        "endowment" to "Endowment Lands",
        "wakf" to "Wakf Lands",
        "inam" to "Inam Lands",
        "private" to ""
    )

    /** Rule 11 - the Land Nature Sub-Category a government land takes. */
    val NATURE_SUB: Map<String, String> = mapOf(
        "settlement" to "Govt.Land-Settlement",
        "acquired" to "Govt.Land-Acquired",
        "dpatta_agri" to "Govt.Land-Allotted (D-Patta), Agriculture",
        "dpatta_house" to "Govt.Land-Allotted (D-Patta), House Site Patta",
        "relinquished" to "Govt.Land-Relinquished"
    )

    /** Rule 13 - the non-agricultural LPM series starts here. */
    const val NON_AGRI_LPM_FROM = 300001

    /** Rule 17 - Social Welfare Land Acquisition has one khata. */
    const val SWLA_KHATA = "20001701"
}

/** A column this app wants, and the header words that find it. */
data class ColumnHint(
    val key: String,
    val label: String,
    val hints: List<List<String>>,
    val avoid: List<String>,
)

object Columns {
    val COMMON: List<ColumnHint> = listOf(
    ColumnHint("lpm", "LPM No", listOf(listOf("lpm", "no"), listOf("lpmno"), listOf("lpm")), listOf("extent", "ext")),
    ColumnHint("extent", "LPM Extent", listOf(listOf("lpm", "extent"), listOf("lpmext"), listOf("extent")), listOf()),
    ColumnHint("syno", "Sy. No", listOf(listOf("sy", "no"), listOf("syno"), listOf("survey", "no"), listOf("survey")), listOf("sub")),
    ColumnHint("subdiv", "Sub Div", listOf(listOf("sub", "div"), listOf("subdiv"), listOf("sub", "division")), listOf()),
    ColumnHint("khata", "Khata No", listOf(listOf("khata"), listOf("khatha")), listOf()),
    ColumnHint("name", "Name / Name", listOf(listOf("pattadar", "name"), listOf("pattadhar", "name"), listOf("enjoyer", "name"), listOf("name")), listOf("father", "relation")),
    ColumnHint("fname", "Father name / Father", listOf(listOf("relation"), listOf("father"), listOf("fname")), listOf()),
    ColumnHint("hextent", "Pattadar extent", listOf(listOf("pattadar", "extent"), listOf("pattadhar", "extent"), listOf("enjoyer", "extent"), listOf("holder", "extent")), listOf("lpm", "total"))
    )
    val VS_EXTRA: List<ColumnHint> = listOf(
    ColumnHint("chaltha", "Chaltha No", listOf(listOf("chaltha"), listOf("chalta"), listOf("chalth")), listOf()),
    ColumnHint("remarks", "Remarks", listOf(listOf("remark")), listOf("desc", "description")),
    ColumnHint("desc", "Description of Remarks", listOf(listOf("description"), listOf("desc", "remark"), listOf("desremarks")), listOf()),
    ColumnHint("rowrange", "Records Range", listOf(listOf("record", "range"), listOf("rowrange"), listOf("range")), listOf())
    )
}
