package ap.webland.core

/**
 * Playing a macro, row by row, honestly.
 *
 * The logic lives here, with no browser in it, so that all of it can be
 * tested against a pretend page. Whatever drives a real WebView only has
 * to answer the questions in `PageHost`.
 *
 * Three promises are kept in this file.
 *
 * A step that does not work is tried ONCE more and then left behind: the
 * run carries on to the end of the row rather than stopping in the
 * middle of a half-filled form. Whatever did not verify is written into
 * the row's result, so it can be looked at afterwards instead of being
 * discovered in the register.
 *
 * A value is read back out of the box after it is put in. An extent is
 * compared as a number, so 0.68 and 0.680 are the same; a dropdown is
 * compared by the words showing in it. A box that will not take its
 * value is not quietly accepted.
 *
 * A save is never repeated on a maybe. If the portal does not answer, or
 * answers in a way that only suggests the record went in, the row is
 * NEEDS_REVIEW and no machine touches it again.
 */

/** Everything the runner needs from a page, and nothing more. */
interface PageHost {
    fun exists(sel: Selector): Boolean
    fun visible(sel: Selector): Boolean
    fun optionCount(sel: Selector): Int
    fun click(sel: Selector): Boolean
    fun type(sel: Selector, text: String): Boolean
    fun select(sel: Selector, label: String): Boolean
    /**
     * What the box holds now: an input's value, the words showing in a
     * dropdown, or "CHECKED" / "" for a radio button or a tick box.
     */
    fun readBack(sel: Selector): String
    fun pageText(): String
    fun pageMessage(): String
    fun url(): String
    fun open(url: String)
    fun refresh()
    fun frame(name: String)
    fun hasPasswordBox(): Boolean
    fun screenshot(tag: String): String
    fun sleep(ms: Long)
    fun now(): Long
    fun log(line: String)
}

/** One thing that did not land where it should have. */
data class Miss(
    val line: Int,
    val box: String,
    val wanted: String,
    val got: String,
    val why: String,
)

class UvRunner(
    private val program: UvProgram,
    private val host: PageHost,
    private val table: Table?,
    /** pad an extent to three decimals before typing it */
    private val padExtents: Boolean = true,
    private val decimals: Int = 3,
    private val stopped: () -> Boolean = { false },
) {
    /** UI.Vision's own internal variables, plus whatever the macro stores. */
    private val vars = HashMap<String, String>()
    private var timeoutMs: Long = 10_000
    private var ignoreErrors = true

    val misses = ArrayList<Miss>()

    class Stopped : Exception("Stopped")

    // ------------------------------------------------------------ one row
    fun runRow(rowIndex: Int, lineNumber: Int = rowIndex + 2): RowResult {
        val result = RowResult(lineNumber, RowState.RUNNING)
        misses.clear()
        vars.clear()
        timeoutMs = 10_000
        ignoreErrors = true
        vars["!LOOP"] = lineNumber.toString()
        vars["!csvReadLineNumber"] = lineNumber.toString()
        val row = table?.rows?.getOrNull(rowIndex)
        if (row != null) {
            table.columns.forEachIndexed { i, name ->
                vars["!COL${i + 1}"] = row[name] ?: ""
            }
            for ((name, cell) in row) vars[name] = cell
        }

        val started = host.now()
        var saveSeen: SaveOutcome? = null
        var typedLpm = ""

        try {
            var i = 0
            val steps = program.steps
            while (i < steps.size) {
                if (stopped()) throw Stopped()
                val s = steps[i]
                when (s.op) {
                    UvOp.IF -> {
                        if (!truth(s)) { i = (if (s.jumpTo >= 0) s.jumpTo else i); i++; continue }
                    }
                    UvOp.ELSE -> {
                        // reached only when the `if` above it was true, so
                        // the else-body is skipped: jump to its endif
                        i = if (s.jumpTo >= 0) s.jumpTo else i
                        i++
                        continue
                    }
                    UvOp.ENDIF, UvOp.COMMENT, UvOp.CSV_READ -> {}
                    UvOp.PAUSE -> host.sleep(number(s.raw.target, 300))
                    UvOp.STORE -> store(s)
                    UvOp.ECHO -> host.log(fill(s.raw.target))
                    UvOp.THROW -> {
                        val why = fill(s.raw.target).ifBlank { "the macro stopped" }
                        result.state = RowState.FAILED
                        result.code = Codes.PORTAL_ERROR
                        result.message = why
                        result.stepId = "line ${s.line}"
                        return finish(result, started)
                    }
                    UvOp.OPEN -> host.open(fill(s.raw.target).ifBlank { fill(s.raw.value) })
                    UvOp.REFRESH -> host.refresh()
                    UvOp.FRAME -> host.frame(fill(s.raw.target))
                    UvOp.SCREENSHOT -> result.screenshot = host.screenshot("line${s.line}")
                    UvOp.WAIT_VISIBLE -> waitFor(s) { host.visible(sel(s)) }
                    UvOp.WAIT_PRESENT -> waitFor(s) { host.exists(sel(s)) }
                    UvOp.WAIT_LIST -> waitFor(s) { host.optionCount(sel(s)) > 1 }
                    UvOp.WAIT_EMPTY -> waitFor(s) { host.readBack(sel(s)).isBlank() }
                    UvOp.DIALOGS ->
                        host.log("the app answers the portal's confirm and alert " +
                            "boxes itself; nothing waits for OK")
                    UvOp.CHECK_RADIO -> {
                        attempt(s, "tick") { host.click(sel(s)) }
                        verify(s, "CHECKED", numeric = false, override = true)
                    }
                    UvOp.WAIT_TEXT -> {
                        val want = fill(s.raw.value).ifBlank { fill(s.raw.target) }
                        waitFor(s) { want.isNotBlank() && want in host.pageText() }
                    }
                    UvOp.PAD_EXTENTS ->
                        host.log("extents are padded before typing; nothing to repair")
                    UvOp.CLICK -> {
                        if (s.writes) {
                            saveSeen = save(s, typedLpm)
                            if (saveSeen == SaveOutcome.SESSION) {
                                result.state = RowState.FAILED
                                result.code = Codes.SESSION_EXPIRED
                                result.message = "the portal signed us out"
                                result.stepId = "line ${s.line}"
                                return finish(result, started)
                            }
                        } else {
                            attempt(s, "click") { host.click(sel(s)) }
                        }
                    }
                    UvOp.TYPE -> {
                        val wanted = typeValue(s)
                        if (sel(s).value.lowercase().contains("txtlpmno") &&
                            !sel(s).value.lowercase().contains("extent")
                        ) typedLpm = wanted
                        if (wanted.isNotBlank() || s.raw.value.isBlank()) {
                            attempt(s, "type") { host.type(sel(s), wanted) }
                            verify(s, wanted, numeric = isExtent(sel(s)))
                        }
                    }
                    UvOp.SELECT -> {
                        val label = labelOf(fill(s.raw.value))
                        if (label.isNotBlank()) {
                            waitFor(s) { host.optionCount(sel(s)) > 1 }
                            attempt(s, "choose") { host.select(sel(s), label) }
                            verify(s, label, numeric = false)
                        }
                    }
                    UvOp.UPLOAD -> host.log("a file to attach is chosen on the Run page")
                    else -> {}
                }
                i++
            }
        } catch (e: Stopped) {
            result.state = RowState.SKIPPED
            result.message = "stopped by the person"
            return finish(result, started)
        } catch (e: Exception) {
            result.state = RowState.FAILED
            result.code = Codes.UNKNOWN_ERROR
            result.message = (e.message ?: e.toString()).take(200)
            result.screenshot = host.screenshot("row$lineNumber")
            return finish(result, started)
        }

        // ---- how did it end?
        when (saveSeen) {
            null -> {
                // nothing in this macro saves: the form was filled, no more
                result.state = if (misses.isEmpty()) RowState.SUCCESS
                else RowState.NEEDS_REVIEW
                result.code = if (misses.isEmpty()) "" else Codes.FIELD_MISMATCH
            }
            SaveOutcome.OK -> {
                // saved - but a box that never took its value means the
                // record in the portal may not say what the file says
                if (misses.isEmpty()) {
                    result.state = RowState.SUCCESS
                    result.code = Codes.SAVE_CONFIRMED
                } else {
                    result.state = RowState.NEEDS_REVIEW
                    result.code = Codes.FIELD_MISMATCH
                    result.message = "saved, but " + missLine()
                }
            }
            else -> {
                result.state = saveSeen.state()
                result.code = saveSeen.code()
                if (result.message.isBlank())
                    result.message = host.pageMessage().take(200)
            }
        }
        if (misses.isNotEmpty() && result.message.isBlank())
            result.message = missLine()
        if (result.state != RowState.SUCCESS && result.screenshot.isBlank())
            result.screenshot = host.screenshot("row$lineNumber")
        return finish(result, started)
    }

    private fun finish(r: RowResult, started: Long): RowResult {
        r.seconds = (host.now() - started) / 1000.0
        return r
    }

    private fun missLine(): String =
        misses.take(4).joinToString("; ") {
            "${it.box} wanted \"${it.wanted}\", page has \"${it.got}\""
        } + if (misses.size > 4) " and ${misses.size - 4} more" else ""

    // --------------------------------------------------------- the pieces
    private fun sel(s: UvStep): Selector =
        if (s.selector.kind == "xpath" || s.selector.kind == "css")
            Selector(s.selector.kind, fill(s.selector.value))
        else s.selector

    /** Put the row's values and the stored variables into a piece of text. */
    fun fill(text: String?): String {
        var out = text ?: ""
        if (!out.contains("\${")) return out
        var guard = 0
        while (out.contains("\${") && guard++ < 5) {
            out = Regex("\\$\\{([^}]{1,80})}").replace(out) { m ->
                val key = m.groupValues[1].trim()
                vars[key] ?: m.value
            }
        }
        return out
    }

    private fun number(text: String?, fallback: Long): Long =
        fill(text).trim().toLongOrNull() ?: fallback

    private fun labelOf(value: String): String {
        val v = value.trim()
        for (prefix in listOf("label=", "value=", "index=")) {
            if (v.lowercase().startsWith(prefix)) return v.substring(prefix.length)
        }
        return v
    }

    private fun isExtent(sel: Selector): Boolean =
        sel.value.lowercase().contains("extent")

    /** What is actually typed into a box, padded when it is an extent. */
    fun typeValue(s: UvStep): String {
        val raw = fill(s.raw.value)
        if (!padExtents || !isExtent(sel(s))) return raw
        if (Extent.tooPrecise(raw, decimals)) {
            host.log("line ${s.line}: \"$raw\" has more than $decimals decimals; " +
                "it is typed as it stands, not shortened")
            return raw
        }
        return Extent.pad(raw, decimals)
    }

    private fun store(s: UvStep) {
        val name = s.raw.value.trim()
        if (name.isEmpty()) return
        val value = fill(s.raw.target)
        when (name) {
            "!TIMEOUT_WAIT" -> timeoutMs = ((value.toDoubleOrNull() ?: 10.0) * 1000)
                .toLong().coerceIn(500, 180_000)
            "!ERRORIGNORE" -> ignoreErrors = !value.equals("false", true)
            else -> vars[name] = value
        }
    }

    /** `${g1}==1`, `${ch}!=C01` and nothing cleverer. No arithmetic. */
    fun truth(s: UvStep): Boolean {
        val text = fill(s.raw.target).trim()
        val m = Regex("^(.*?)(==|!=|>=|<=|>|<)(.*)$").find(text)
        if (m == null) {
            // a bare value: true when it is a number other than zero
            val n = text.trim('"', '\'', ' ').toDoubleOrNull()
            return n != null && n != 0.0
        }
        val a = m.groupValues[1].trim().trim('"', '\'')
        val op = m.groupValues[2]
        val b = m.groupValues[3].trim().trim('"', '\'')
        val x = a.toDoubleOrNull()
        val y = b.toDoubleOrNull()
        return if (x != null && y != null) when (op) {
            "==" -> x == y
            "!=" -> x != y
            ">=" -> x >= y
            "<=" -> x <= y
            ">" -> x > y
            else -> x < y
        } else when (op) {
            "==" -> a == b
            "!=" -> a != b
            else -> false
        }
    }

    private fun waitFor(s: UvStep, test: () -> Boolean) {
        val until = host.now() + timeoutMs
        while (host.now() < until) {
            if (stopped()) throw Stopped()
            if (test()) return
            host.sleep(120)
        }
    }

    /** Do it; if it does not work, do it once more, then carry on. */
    private fun attempt(s: UvStep, what: String, action: () -> Boolean) {
        if (action()) return
        host.sleep(250)
        if (action()) return
        misses.add(Miss(s.line, boxName(sel(s)), fill(s.raw.value), "",
            "the $what did not go through, twice"))
    }

    /** Read the value back out of the box and compare it. */
    private fun verify(
        s: UvStep,
        wanted: String,
        numeric: Boolean,
        /** a tick is put back with another click, not by typing */
        override: Boolean = false,
    ) {
        if (wanted.isBlank()) return
        if (same(host.readBack(sel(s)), wanted, numeric)) return
        // one more go, then leave it and write it down
        host.sleep(250)
        when {
            override -> host.click(sel(s))
            s.op == UvOp.SELECT -> host.select(sel(s), wanted)
            else -> host.type(sel(s), wanted)
        }
        val again = host.readBack(sel(s))
        if (!same(again, wanted, numeric)) {
            misses.add(Miss(s.line, boxName(sel(s)), wanted, again,
                when {
                    override -> "the choice did not stay ticked"
                    s.op == UvOp.SELECT -> "the list did not take that word"
                    else -> "the box did not keep that value"
                }))
        }
    }

    private fun same(got: String, wanted: String, numeric: Boolean): Boolean =
        if (numeric) Extent.same(got, wanted) else got.trim() == wanted.trim()

    private fun boxName(sel: Selector): String =
        sel.value.removePrefix("grAddRecord_").take(48)

    /**
     * Press the button, then find out what really happened.
     *
     * The LPM box is watched because the portal clears it on a save and
     * keeps it on a refusal; that is evidence either way, and it is only
     * ever used together with whatever the portal says in words.
     */
    private fun save(s: UvStep, typedLpm: String): SaveOutcome {
        if (!host.click(sel(s))) {
            host.sleep(300)
            if (!host.click(sel(s))) return SaveOutcome.NOT_SAVED
        }
        val lpmBox = Selector("id", PortalFields.ADD["lpm"] ?: "grAddRecord_txtlpmno_0")
        val until = host.now() + maxOf(timeoutMs, 30_000)
        var clearedSince = 0L
        var heldSince = 0L
        while (host.now() < until) {
            if (stopped()) throw Stopped()
            val message = host.pageMessage()
            val now = host.readBack(lpmBox)
            val cleared = now.isBlank()
            val held = typedLpm.isNotBlank() && now.trim() == typedLpm.trim()
            if (cleared && clearedSince == 0L) clearedSince = host.now()
            if (!cleared) clearedSince = 0L
            if (held && heldSince == 0L) heldSince = host.now()
            if (!held) heldSince = 0L
            val settled = when {
                clearedSince > 0L -> host.now() - clearedSince
                heldSince > 0L -> host.now() - heldSince
                else -> 0L
            }
            PortalTalk.decide(message, host.url(), held, cleared, settled,
                host.hasPasswordBox())?.let { return it }
            host.sleep(400)
        }
        return SaveOutcome.TIMEOUT
    }

    // ------------------------------------------------------- a whole run
    /**
     * Rows `from`..`to` inclusive, 1-based over the data rows.
     *
     * `onRow` is called after each one so the caller can save progress
     * and show it. Returning false from it stops the run.
     */
    fun run(
        from: Int,
        to: Int,
        onRow: (RowResult) -> Boolean,
    ): List<RowResult> {
        val out = ArrayList<RowResult>()
        val rows = table?.count() ?: 0
        var consecutive = 0
        for (n in from..to) {
            if (stopped()) break
            val index = n - 1
            if (index < 0 || index >= rows) continue
            val r = runRow(index, table?.lineOf(index) ?: (index + 2))
            out.add(r)
            consecutive = if (r.state == RowState.FAILED) consecutive + 1 else 0
            if (!onRow(r)) break
            if (consecutive >= 5) {
                host.log("five rows failed one after another; stopping so the " +
                    "rest of the file is not spent on the same problem")
                break
            }
        }
        return out
    }
}
