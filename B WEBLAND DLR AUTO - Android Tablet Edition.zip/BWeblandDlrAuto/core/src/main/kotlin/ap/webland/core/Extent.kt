package ap.webland.core

/**
 * Extents, and the one rule about them that matters more than any other:
 * the number is never changed.
 *
 * The portal wants three decimals. A file often has two, or one, or none.
 * Making 0.33 into 0.330 is adding a zero; making 0.3333 into 0.333 is
 * rounding, and rounding an extent alters a land record. So padding adds
 * zeros and nothing else, and a value with more decimals than the portal
 * takes is reported rather than quietly shortened.
 */
object Extent {

    /** 0.33 -> "0.330". Zeros are added; no digit is ever changed. */
    fun pad(raw: String?, places: Int = 3): String {
        val s = (raw ?: "").trim()
        if (s.isEmpty()) return ""
        val negative = s.startsWith("-")
        val body = if (negative) s.substring(1) else s
        if (body.isEmpty() || !body.all { it.isDigit() || it == '.' }) return s
        if (body.count { it == '.' } > 1) return s
        val whole = body.substringBefore('.')
        val frac = if (body.contains('.')) body.substringAfter('.') else ""
        if (frac.length > places) return s          // never shortened here
        val padded = frac + "0".repeat(places - frac.length)
        val sign = if (negative) "-" else ""
        return if (places == 0) "$sign$whole" else "$sign$whole.$padded"
    }

    /** True when padding would have to drop a digit to reach `places`. */
    fun tooPrecise(raw: String?, places: Int = 3): Boolean {
        val s = (raw ?: "").trim().removePrefix("-")
        if (!s.contains('.')) return false
        if (!s.all { it.isDigit() || it == '.' }) return false
        return s.substringAfter('.').length > places
    }

    /** The number, or null when the cell does not hold one. */
    fun value(raw: String?): Double? {
        val s = (raw ?: "").trim().replace(",", "")
        if (s.isEmpty()) return null
        return s.toDoubleOrNull()
    }

    fun isZero(raw: String?): Boolean {
        val v = value(raw) ?: return false
        return v == 0.0
    }

    /** Same extent written two ways: "0.68" and "0.680" are equal. */
    fun same(a: String?, b: String?): Boolean {
        val x = value(a)
        val y = value(b)
        if (x == null || y == null) return (a ?: "").trim() == (b ?: "").trim()
        return Math.abs(x - y) < 1e-9
    }

    /** The sum of a column of extents, as text with three decimals. */
    fun total(values: List<String?>, places: Int = 3): String {
        var sum = 0.0
        for (v in values) sum += value(v) ?: 0.0
        return pad(trim(sum), places)
    }

    private fun trim(d: Double): String {
        val s = "%.6f".format(d).trimEnd('0')
        return if (s.endsWith(".")) s.dropLast(1) else s
    }

    // ---------------------------------------------------------------- units
    // An acre of 100 cents, which is how the Adangal states it in this
    // district. Conversions are for the reports; the DLR boxes always
    // take the file's own number, untouched.
    const val SQM_PER_ACRE = 4046.8564224
    const val SQFT_PER_ACRE = 43560.0
    const val CENTS_PER_ACRE = 100.0
    const val HECTARES_PER_ACRE = 0.40468564224

    enum class Unit { ACRE, CENT, SQM, SQFT, HECTARE }

    fun convert(amount: Double, from: Unit, to: Unit): Double {
        val acres = when (from) {
            Unit.ACRE -> amount
            Unit.CENT -> amount / CENTS_PER_ACRE
            Unit.SQM -> amount / SQM_PER_ACRE
            Unit.SQFT -> amount / SQFT_PER_ACRE
            Unit.HECTARE -> amount / HECTARES_PER_ACRE
        }
        return when (to) {
            Unit.ACRE -> acres
            Unit.CENT -> acres * CENTS_PER_ACRE
            Unit.SQM -> acres * SQM_PER_ACRE
            Unit.SQFT -> acres * SQFT_PER_ACRE
            Unit.HECTARE -> acres * HECTARES_PER_ACRE
        }
    }

    /** How far apart two extents are, as a fraction of the first. */
    fun variation(a: String?, b: String?): Double? {
        val x = value(a) ?: return null
        val y = value(b) ?: return null
        if (x == 0.0) return if (y == 0.0) 0.0 else null
        return (y - x) / x
    }
}
