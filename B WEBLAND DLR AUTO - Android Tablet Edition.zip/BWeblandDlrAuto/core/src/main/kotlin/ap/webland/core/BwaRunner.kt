package ap.webland.core

/**
 * Playing a recording, row by row.
 *
 * This is the other half of the pair: `UvRunner` plays the UI.Vision
 * macros the surveyor already has, and this plays what the tablet's own
 * recorder made. They answer to the same `PageHost`, keep the same six
 * row states, and treat a save the same way, so a screen does not have
 * to care which kind of automation it is running.
 *
 * Where a recording differs from a macro is worth saying. A recording
 * names its values by column - {{Khata}} - rather than by number, so a
 * spreadsheet whose columns move still works. And a step knows what it
 * MEANS: the recorder noticed that the button said "Add", so this runner
 * knows to wait for the portal's answer afterwards instead of pressing
 * on and hoping.
 */
class BwaRunner(
    private val auto: Automation,
    private val host: PageHost,
    private val table: Table?,
    /** supplied for this run only, never stored */
    private val password: String = "",
    private val padExtents: Boolean = true,
    private val decimals: Int = 3,
    private val stopped: () -> Boolean = { false },
) {
    val misses = ArrayList<Miss>()

    class Stopped : Exception("Stopped")

    fun runRow(rowIndex: Int, lineNumber: Int = rowIndex + 2): RowResult {
        val result = RowResult(lineNumber, RowState.RUNNING)
        misses.clear()
        val row = table?.rows?.getOrNull(rowIndex) ?: emptyMap()
        val started = host.now()
        var saveSeen: SaveOutcome? = null
        var typedKey = ""

        try {
            for (step in auto.live()) {
                if (stopped()) throw Stopped()
                val sel = selector(step)
                when (step.act) {
                    Act.OPEN -> host.open(value(step, row))
                    Act.RELOAD -> host.refresh()
                    Act.BACK, Act.FORWARD -> host.log(
                        "${step.act.key} is not replayed: a run goes forwards")
                    Act.COMMENT -> host.log(step.value)
                    Act.WAIT -> {
                        val outcome = wait(step, sel, typedKey)
                        if (outcome != null) {
                            saveSeen = outcome
                            if (outcome == SaveOutcome.SESSION) {
                                return stop(result, started, Codes.SESSION_EXPIRED,
                                    "the portal signed us out", step.id)
                            }
                        }
                    }
                    Act.CLICK, Act.DOUBLE_CLICK -> {
                        if (step.meaning.writes) {
                            saveSeen = save(step, sel, typedKey)
                            if (saveSeen == SaveOutcome.SESSION) {
                                return stop(result, started, Codes.SESSION_EXPIRED,
                                    "the portal signed us out", step.id)
                            }
                        } else {
                            await(step, sel)
                            attempt(step, sel, "click") { host.click(sel) }
                        }
                    }
                    Act.RIGHT_CLICK, Act.HOVER -> await(step, sel)
                    Act.CLEAR -> {
                        await(step, sel)
                        attempt(step, sel, "clear") { host.type(sel, "") }
                    }
                    Act.TYPE -> {
                        val text = if (step.secret) password else typeValue(step, row, sel)
                        if (text.isEmpty() && step.secret) {
                            return stop(result, started, Codes.LOGIN_FAILED,
                                "this recording needs a password and none was given",
                                step.id)
                        }
                        if (isKeyBox(sel)) typedKey = text
                        await(step, sel)
                        attempt(step, sel, "type") { host.type(sel, text) }
                        if (!step.secret) verify(step, sel, text, isExtent(sel))
                    }
                    Act.PRESS -> host.log(
                        "a key press is not replayed; the value is typed instead")
                    Act.SELECT -> {
                        val label = value(step, row)
                        if (label.isNotBlank()) {
                            awaitList(step, sel)
                            attempt(step, sel, "choose") { host.select(sel, label) }
                            verify(step, sel, label, numeric = false)
                        }
                    }
                    Act.CHECK -> {
                        await(step, sel)
                        if (host.readBack(sel) != "CHECKED") {
                            attempt(step, sel, "tick") { host.click(sel) }
                        }
                        verify(step, sel, "CHECKED", numeric = false, byClick = true)
                    }
                    Act.UNCHECK -> {
                        await(step, sel)
                        if (host.readBack(sel) == "CHECKED") {
                            attempt(step, sel, "untick") { host.click(sel) }
                        }
                    }
                    Act.UPLOAD -> host.log(
                        "the file to attach is chosen on the Run page, not here")
                }
            }
        } catch (e: Stopped) {
            result.state = RowState.SKIPPED
            result.message = "stopped by the person"
            return finish(result, started)
        } catch (e: Exception) {
            result.screenshot = host.screenshot("row$lineNumber")
            return stop(result, started, Codes.UNKNOWN_ERROR,
                (e.message ?: e.toString()).take(200), "")
        }

        when (saveSeen) {
            null -> {
                result.state = if (misses.isEmpty()) RowState.SUCCESS
                else RowState.NEEDS_REVIEW
                result.code = if (misses.isEmpty()) "" else Codes.FIELD_MISMATCH
            }
            SaveOutcome.OK -> {
                if (misses.isEmpty()) {
                    result.state = RowState.SUCCESS
                    result.code = Codes.SAVE_CONFIRMED
                } else {
                    result.state = RowState.NEEDS_REVIEW
                    result.code = Codes.FIELD_MISMATCH
                    result.message = "saved, but " + missLine()
                }
            }
            else -> {
                result.state = saveSeen.state()
                result.code = saveSeen.code()
                result.message = host.pageMessage().take(200)
            }
        }
        if (misses.isNotEmpty() && result.message.isBlank()) result.message = missLine()
        if (result.state != RowState.SUCCESS && result.screenshot.isBlank()) {
            result.screenshot = host.screenshot("row$lineNumber")
        }
        return finish(result, started)
    }

    fun run(from: Int, to: Int, onRow: (RowResult) -> Boolean): List<RowResult> {
        val out = ArrayList<RowResult>()
        val rows = table?.count() ?: 0
        var inARow = 0
        for (n in from..to) {
            if (stopped()) break
            val index = n - 1
            if (index < 0 || index >= rows) continue
            val r = runRow(index, table?.lineOf(index) ?: (index + 2))
            out.add(r)
            inARow = if (r.state == RowState.FAILED) inARow + 1 else 0
            if (!onRow(r)) break
            if (inARow >= auto.stopAfterFailures) {
                host.log("${auto.stopAfterFailures} rows failed one after another; " +
                    "stopping so the rest of the file is not spent on the same problem")
                break
            }
        }
        return out
    }

    /** Only the rows named, for a retry of the failed ones. */
    fun runThese(lineNumbers: List<Int>, onRow: (RowResult) -> Boolean): List<RowResult> {
        val out = ArrayList<RowResult>()
        val byLine = HashMap<Int, Int>()
        val rows = table?.count() ?: 0
        for (i in 0 until rows) byLine[table?.lineOf(i) ?: (i + 2)] = i
        for (line in lineNumbers) {
            if (stopped()) break
            val index = byLine[line] ?: continue
            val r = runRow(index, line)
            out.add(r)
            if (!onRow(r)) break
        }
        return out
    }

    // --------------------------------------------------------- the parts
    private fun selector(step: Step): Selector {
        val t = step.target
        return when {
            t.id.isNotBlank() -> Selector("id", t.id)
            t.name.isNotBlank() -> Selector("name", t.name)
            t.label.isNotBlank() -> Selector("label", t.label)
            t.css.isNotBlank() -> Selector("css", t.css)
            t.xpath.isNotBlank() -> Selector("xpath", t.xpath)
            t.text.isNotBlank() -> Selector("text", t.text)
            else -> Selector("none", "")
        }
    }

    private fun value(step: Step, row: Row): String {
        val mapped = auto.mapping.entries.fold(step.value) { acc, (name, column) ->
            acc.replace("{{$name}}", "{{$column}}")
        }
        val missing = ArrayList<String>()
        val out = Bind.resolve(mapped, row, missing)
        for (name in missing) {
            host.log("{{$name}} has no column in this file, so it was left as it is")
        }
        return out
    }

    private fun typeValue(step: Step, row: Row, sel: Selector): String {
        val raw = value(step, row)
        if (!padExtents || !isExtent(sel)) return raw
        if (Extent.tooPrecise(raw, decimals)) {
            host.log("\"$raw\" has more than $decimals decimals; it is typed as it " +
                "stands, not shortened")
            return raw
        }
        return Extent.pad(raw, decimals)
    }

    private fun isExtent(sel: Selector) = sel.value.lowercase().contains("extent")

    private fun isKeyBox(sel: Selector): Boolean {
        val low = sel.value.lowercase()
        return low.contains("txtlpmno") && !low.contains("extent")
    }

    private fun await(step: Step, sel: Selector) {
        if (sel.kind == "none") return
        val until = host.now() + step.timeoutMs
        while (host.now() < until) {
            if (stopped()) throw Stopped()
            if (host.visible(sel) || host.exists(sel)) return
            host.sleep(120)
        }
    }

    private fun awaitList(step: Step, sel: Selector) {
        val until = host.now() + step.timeoutMs
        while (host.now() < until) {
            if (stopped()) throw Stopped()
            if (host.optionCount(sel) > 1) return
            host.sleep(120)
        }
    }

    private fun attempt(step: Step, sel: Selector, what: String, action: () -> Boolean) {
        if (action()) return
        host.sleep(250)
        if (action()) return
        if (step.optional) {
            host.log("step ${step.id} did not go through and is marked optional")
            return
        }
        misses.add(Miss(0, boxName(sel), step.value, "",
            "the $what did not go through, twice"))
    }

    private fun verify(
        step: Step,
        sel: Selector,
        wanted: String,
        numeric: Boolean,
        byClick: Boolean = false,
    ) {
        if (wanted.isBlank()) return
        if (same(host.readBack(sel), wanted, numeric)) return
        host.sleep(250)
        when {
            byClick -> host.click(sel)
            step.act == Act.SELECT -> host.select(sel, wanted)
            else -> host.type(sel, wanted)
        }
        val again = host.readBack(sel)
        if (!same(again, wanted, numeric) && !step.optional) {
            misses.add(Miss(0, boxName(sel), wanted, again, when {
                byClick -> "the choice did not stay ticked"
                step.act == Act.SELECT -> "the list did not take that word"
                else -> "the box did not keep that value"
            }))
        }
    }

    private fun same(got: String, wanted: String, numeric: Boolean): Boolean =
        if (numeric) Extent.same(got, wanted) else got.trim() == wanted.trim()

    private fun boxName(sel: Selector) = sel.value.removePrefix("grAddRecord_").take(48)

    /** A wait step: the only one that can decide the row's fate. */
    private fun wait(step: Step, sel: Selector, typedKey: String): SaveOutcome? {
        when (step.wait) {
            Wait.SAVE_CONFIRMATION -> return watch(step.timeoutMs.toLong(), typedKey)
            Wait.SECONDS -> host.sleep(
                (step.waitFor.toLongOrNull() ?: 1000L).coerceIn(0, 60_000))
            Wait.VISIBLE -> await(step, sel)
            Wait.ELEMENT, Wait.ENABLED -> await(step, sel)
            Wait.GONE -> {
                val until = host.now() + step.timeoutMs
                while (host.now() < until && host.exists(sel)) host.sleep(120)
            }
            Wait.TEXT -> {
                val until = host.now() + step.timeoutMs
                val want = step.waitFor
                while (host.now() < until &&
                    (want.isBlank() || !host.pageText().contains(want))
                ) host.sleep(150)
            }
            Wait.URL -> {
                val until = host.now() + step.timeoutMs
                while (host.now() < until &&
                    !host.url().lowercase().contains(step.waitFor.lowercase())
                ) host.sleep(150)
            }
            Wait.PAGE, Wait.NAVIGATION -> host.sleep(600)
        }
        return null
    }

    private fun save(step: Step, sel: Selector, typedKey: String): SaveOutcome {
        if (!host.click(sel)) {
            host.sleep(300)
            if (!host.click(sel)) return SaveOutcome.NOT_SAVED
        }
        return watch(maxOf(step.timeoutMs.toLong(), 30_000L), typedKey)
    }

    /**
     * What the Save really did.
     *
     * Pressed once, then watched. A record that may have gone in is
     * never pressed again by this app, so this is the only place that
     * decides, and it decides from the portal's words first and the
     * state of the form second.
     */
    private fun watch(timeoutMs: Long, typedKey: String): SaveOutcome {
        val keyBox = Selector("id", PortalFields.ADD["lpm"] ?: "grAddRecord_txtlpmno_0")
        val until = host.now() + timeoutMs
        var clearedSince = 0L
        var heldSince = 0L
        while (host.now() < until) {
            if (stopped()) throw Stopped()
            val message = host.pageMessage()
            val now = host.readBack(keyBox)
            val cleared = now.isBlank()
            val held = typedKey.isNotBlank() && now.trim() == typedKey.trim()
            clearedSince = if (cleared) (if (clearedSince == 0L) host.now() else clearedSince) else 0L
            heldSince = if (held) (if (heldSince == 0L) host.now() else heldSince) else 0L
            val settled = when {
                clearedSince > 0L -> host.now() - clearedSince
                heldSince > 0L -> host.now() - heldSince
                else -> 0L
            }
            PortalTalk.decide(message, host.url(), held, cleared, settled,
                host.hasPasswordBox())?.let { return it }
            host.sleep(400)
        }
        return SaveOutcome.TIMEOUT
    }

    private fun missLine(): String =
        misses.take(4).joinToString("; ") {
            "${it.box} wanted \"${it.wanted}\", page has \"${it.got}\""
        } + if (misses.size > 4) " and ${misses.size - 4} more" else ""

    private fun stop(
        r: RowResult, started: Long, code: String, message: String, stepId: String,
    ): RowResult {
        r.state = RowState.FAILED
        r.code = code
        r.message = message
        r.stepId = stepId
        return finish(r, started)
    }

    private fun finish(r: RowResult, started: Long): RowResult {
        r.seconds = (host.now() - started) / 1000.0
        return r
    }
}
