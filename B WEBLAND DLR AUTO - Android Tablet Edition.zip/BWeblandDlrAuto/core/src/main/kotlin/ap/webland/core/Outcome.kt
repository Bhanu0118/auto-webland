package ap.webland.core

/**
 * What happened to a row, and how the portal's own words are read.
 *
 * Six states, and the distinction between two of them is the whole
 * design:
 *
 *     PENDING       not attempted yet
 *     RUNNING       being attempted now
 *     SUCCESS       it went in, and the portal said so
 *     FAILED        it did not go in. Trying again is reasonable.
 *     NEEDS_REVIEW  we do not KNOW whether it went in
 *     SKIPPED       deliberately not attempted
 *
 * FAILED and NEEDS_REVIEW are not degrees of the same thing. A row that
 * may already be in the portal must never be replayed by a machine: a
 * second Save makes a second record and nobody finds out until the
 * register is wrong. So "Retry failed" retries FAILED and nothing else,
 * and no amount of convenience is allowed to blur that.
 */
enum class RowState(val mark: String) {
    PENDING("·"),
    RUNNING("▶"),
    SUCCESS("✓"),
    FAILED("✗"),
    NEEDS_REVIEW("⚠"),
    SKIPPED("–");

    /** The only state a machine may attempt again. */
    val retryable: Boolean get() = this == FAILED
}

/** What a Save really did. Never guessed from the click alone. */
enum class SaveOutcome {
    /** the record went in and the portal said so */
    OK,
    /** already there - do not keep pressing Save */
    DUPLICATE,
    /** the portal refused it and said why */
    INVALID,
    /** we have been signed out - stop everything */
    SESSION,
    /** the form still holds the record, so nothing happened */
    NOT_SAVED,
    /** the form emptied but nothing was said: evidence, not proof */
    CLEARED,
    /** no answer at all. The record may well be in. */
    TIMEOUT;

    /** The row state this outcome honestly deserves. */
    fun state(): RowState = when (this) {
        OK -> RowState.SUCCESS
        DUPLICATE, INVALID, NOT_SAVED -> RowState.FAILED
        SESSION -> RowState.FAILED
        CLEARED, TIMEOUT -> RowState.NEEDS_REVIEW
    }

    fun code(): String = when (this) {
        OK -> Codes.SAVE_CONFIRMED
        DUPLICATE -> Codes.DUPLICATE_RECORD
        INVALID, NOT_SAVED -> Codes.SAVE_REFUSED
        SESSION -> Codes.SESSION_EXPIRED
        CLEARED, TIMEOUT -> Codes.SAVE_UNKNOWN
    }
}

/**
 * Reading the portal's messages.
 *
 * The word lists are the Windows application's, carried across as they
 * are. The one that needs explaining is OK: a bare "successfully" is not
 * proof, because the portal says it about things that have nothing to do
 * with our record ("Logged in successfully"). Only a phrase that names
 * saving counts, and anything in NOT_OURS cancels it.
 */
object PortalTalk {
    val DUPLICATE = listOf(
        "already exist", "already available", "duplicate", "already entered",
        "already")

    val REFUSED = listOf(
        "required", "please enter", "please select", "invalid", "not valid",
        "should be", "cannot be", "must be", "enter the", "select the")

    val SAVED = listOf(
        "saved successfully", "inserted successfully", "added successfully",
        "updated successfully", "submitted successfully", "record saved",
        "data saved", "successfully saved", "successfully inserted",
        "successfully added", "successfully submitted", "record inserted",
        "record added", "success", "saved", "registered")

    val NOT_OURS = listOf(
        "logged in", "login successful", "deleted successfully", "logout",
        "signed in")

    val LOGIN_MARKS = listOf(
        "loginpage.aspx", "/login", "sessionexpired", "timeout.aspx")

    val LOGIN_TEXT = listOf(
        "session expired", "session has expired", "please login",
        "please log in", "your session", "re-login", "relogin",
        "invalid session", "login again")

    /** What one message from the portal means, if anything. */
    fun read(message: String?): SaveOutcome? {
        val low = (message ?: "").lowercase().trim()
        if (low.isEmpty()) return null
        if (LOGIN_TEXT.any { it in low }) return SaveOutcome.SESSION
        if (DUPLICATE.any { it in low }) return SaveOutcome.DUPLICATE
        if (SAVED.any { it in low } && NOT_OURS.none { it in low })
            return SaveOutcome.OK
        if (REFUSED.any { it in low }) return SaveOutcome.INVALID
        return null
    }

    /** Has the portal signed us out, judging by the address alone? */
    fun signedOut(url: String?): Boolean {
        val low = (url ?: "").lowercase()
        if (low.isEmpty()) return false
        return LOGIN_MARKS.any { it in low }
    }

    /**
     * The whole save decision, from what can be observed.
     *
     * @param message      what the portal is saying, if anything
     * @param url          where the browser is now
     * @param formHasValue whether the key box still holds the value we typed
     * @param formCleared  whether the key box went empty
     * @param settledMs    how long the observation has been stable
     * @param passwordBox  whether a password box is on screen
     */
    fun decide(
        message: String?,
        url: String?,
        formHasValue: Boolean,
        formCleared: Boolean,
        settledMs: Long,
        passwordBox: Boolean = false,
    ): SaveOutcome? {
        if (signedOut(url) || passwordBox) return SaveOutcome.SESSION
        read(message)?.let { return it }
        if (formCleared && settledMs > 2_500) return SaveOutcome.CLEARED
        if (formHasValue && settledMs > 4_000)
            return if (!message.isNullOrBlank()) SaveOutcome.INVALID
            else SaveOutcome.NOT_SAVED
        return null                               // keep watching
    }
}

/** One row's result, as the log and the report both need it. */
data class RowResult(
    val rowNumber: Int,
    var state: RowState = RowState.PENDING,
    var code: String = "",
    var message: String = "",
    var stepId: String = "",
    var seconds: Double = 0.0,
    var screenshot: String = "",
) {
    fun fault(): Fault? = if (code.isBlank()) null else Codes.ALL[code]
}

/** The counters the dashboard shows while a run is going. */
data class Tally(
    val total: Int = 0,
    val success: Int = 0,
    val failed: Int = 0,
    val review: Int = 0,
    val skipped: Int = 0,
    val pending: Int = 0,
) {
    val processed: Int get() = success + failed + review + skipped

    companion object {
        fun of(results: Collection<RowResult>, total: Int): Tally {
            val by = results.groupingBy { it.state }.eachCount()
            val done = by[RowState.SUCCESS] ?: 0
            val bad = by[RowState.FAILED] ?: 0
            val rev = by[RowState.NEEDS_REVIEW] ?: 0
            val skip = by[RowState.SKIPPED] ?: 0
            return Tally(total, done, bad, rev, skip,
                (total - done - bad - rev - skip).coerceAtLeast(0))
        }
    }
}
