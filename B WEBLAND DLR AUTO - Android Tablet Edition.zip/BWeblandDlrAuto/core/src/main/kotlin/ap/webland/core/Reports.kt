package ap.webland.core

/**
 * The reports, as tables of text.
 *
 * Nothing here writes a file: the Android side turns a Sheet into an
 * .xlsx or a page of a PDF. Keeping the shape of every report in the
 * core module means each one can be checked with a test rather than by
 * opening a spreadsheet and looking.
 *
 * One rule runs through all of them. A source value is never replaced by
 * a calculated one. Where the app has worked something out - a padded
 * extent, a suggested khata, a correlated parcel - the original sits in
 * its own column beside it, and the heading says which is which. A
 * surveyor can then see what the file said and what the app made of it,
 * which is the only way a correction can be argued about later.
 */

/** One sheet of a report: a name, headings, and rows. */
data class Sheet(
    val name: String,
    val headings: List<String>,
    val rows: List<List<String>>,
) {
    val isEmpty: Boolean get() = rows.isEmpty()

    fun asCells(): List<List<String>> = listOf(headings) + rows
}

object Reports {

    /** What the app changed, field by field, with the original kept. */
    fun changes(original: Row, current: Row): List<Triple<String, String, String>> {
        val out = ArrayList<Triple<String, String, String>>()
        for (key in (original.keys + current.keys)) {
            val was = (original[key] ?: "").trim()
            val now = (current[key] ?: "").trim()
            if (was != now) out.add(Triple(key, was, now))
        }
        return out
    }

    /**
     * The final DLR sheet: the file as it will be entered, with the
     * original extent kept beside the padded one.
     */
    fun finalDlr(
        table: Table,
        extentColumn: String,
        decimals: Int = 3,
    ): Sheet {
        val headings = table.columns + listOf(
            "Extent as entered ($decimals dec)", "Extent in the source file",
            "Changed by the app")
        val rows = table.rows.mapIndexed { i, r ->
            val source = (r[extentColumn] ?: "").trim()
            val padded = Extent.pad(source, decimals)
            val note = when {
                source.isBlank() -> "no extent in the file"
                Extent.tooPrecise(source, decimals) ->
                    "more than $decimals decimals - entered as it stands"
                padded != source -> "zeros added only; the value is unchanged"
                else -> ""
            }
            table.columns.map { r[it] ?: "" } + listOf(padded, source, note)
        }
        return Sheet("Final DLR", headings, rows)
    }

    /** Government land on its own, as the RSR wants it. */
    fun governmentLand(
        table: Table,
        khataColumn: String,
        natureColumn: String,
    ): Sheet {
        val headings = table.columns + listOf("Why it is here")
        val rows = ArrayList<List<String>>()
        table.rows.forEach { r ->
            val khata = (r[khataColumn] ?: "").trim()
            val nature = (r[natureColumn] ?: "").trim()
            val why = when {
                Khata.isGovernment(khata) -> "government khata ($khata)"
                nature.contains("Govt", true) -> "land nature is \"$nature\""
                else -> ""
            }
            if (why.isNotEmpty()) rows.add(table.columns.map { r[it] ?: "" } + why)
        }
        return Sheet("Government land", headings, rows)
    }

    /** Where the file has nothing and the portal needs something. */
    fun missingData(table: Table, required: List<String>): Sheet {
        val headings = listOf("Row", "Column", "What is missing") +
            table.columns.take(6)
        val rows = ArrayList<List<String>>()
        table.rows.forEachIndexed { i, r ->
            for (column in required) {
                if (column !in table.columns) continue
                if ((r[column] ?: "").trim().isEmpty()) {
                    rows.add(listOf(table.lineOf(i).toString(), column,
                        "the cell is empty") + table.columns.take(6)
                        .map { r[it] ?: "" })
                }
            }
        }
        return Sheet("Missing data", headings, rows)
    }

    /** The same value twice where it should appear once. */
    fun duplicates(table: Table, columns: List<String>): Sheet {
        val headings = listOf("Column", "Value", "Rows", "How many")
        val rows = ArrayList<List<String>>()
        for (column in columns) {
            for ((value, where) in table.duplicatesIn(column)) {
                rows.add(listOf(column, value,
                    where.map { table.lineOf(it) }.joinToString(", "),
                    where.size.toString()))
            }
        }
        return Sheet("Duplicates", headings, rows)
    }

    /** Adangal, GT, RSR, SLR, ground and DLR extents side by side. */
    fun extentVariation(
        table: Table,
        columns: Map<String, String>,
        tolerance: Double = 0.02,
    ): Sheet {
        val names = columns.keys.toList()
        val headings = listOf("Row", "LPM") + names +
            listOf("Largest gap", "Worth a look")
        val lpmColumn = columns["DLR"] ?: table.columns.firstOrNull() ?: ""
        val rows = ArrayList<List<String>>()
        table.rows.forEachIndexed { i, r ->
            val values = names.map { (r[columns.getValue(it)] ?: "").trim() }
            val numbers = values.mapNotNull { Extent.value(it) }
            if (numbers.size < 2) return@forEachIndexed
            val gap = (numbers.max() - numbers.min()) /
                (if (numbers.max() == 0.0) 1.0 else numbers.max())
            rows.add(listOf(table.lineOf(i).toString(), (r[lpmColumn] ?: ""))
                + values + listOf("%.1f%%".format(gap * 100),
                if (gap > tolerance) "yes" else ""))
        }
        return Sheet("Extent variation", headings, rows)
    }

    /** Every row that did not simply go in, and what to do about it. */
    fun errorsAndReview(results: List<RowResult>, telugu: Boolean = false): Sheet {
        val headings = listOf("Row", "State", "Code", "What happened",
            "What to do", "Step", "Seconds", "Screenshot")
        val rows = results
            .filter { it.state != RowState.SUCCESS }
            .map { r ->
                val fault = r.fault()
                listOf(r.rowNumber.toString(), r.state.name, r.code,
                    r.message.take(300),
                    fault?.human(telugu) ?: "",
                    r.stepId, "%.1f".format(r.seconds), r.screenshot)
            }
        return Sheet("Errors and review", headings, rows)
    }

    /** The run, as one page: counts first, then what needs a person. */
    fun runSummary(
        results: List<RowResult>,
        total: Int,
        startedAt: String,
        finishedAt: String,
        village: String,
        macroName: String,
        dataFile: String,
    ): Sheet {
        val t = Tally.of(results, total)
        val headings = listOf("", "")
        val worst = Codes.worst(results.mapNotNull { it.code.ifBlank { null } })
        val rows = listOf(
            listOf("Village", village),
            listOf("Macro", macroName),
            listOf("Data file", dataFile),
            listOf("Started", startedAt),
            listOf("Finished", finishedAt),
            listOf("Records in the file", total.toString()),
            listOf("Entered and confirmed", t.success.toString()),
            listOf("Failed", t.failed.toString()),
            listOf("Need review (never retried by the app)", t.review.toString()),
            listOf("Skipped", t.skipped.toString()),
            listOf("Not attempted", t.pending.toString()),
            listOf("Worst thing that happened",
                worst?.let { "${it.code} (${it.severity})" } ?: "nothing"),
            listOf("May the app retry anything itself",
                if (results.any { it.state == RowState.FAILED }) "yes, the failed rows"
                else "no"),
        )
        return Sheet("Run summary", headings, rows)
    }

    /** The correlation pairs, with the uncertain ones marked. */
    fun correlation(pairs: List<Correlate.Pair>): Sheet {
        val headings = listOf("Row", "Survey No", "Sub Div", "LPM",
            "DLR extent", "Map extent", "Difference", "Confidence",
            "Why", "Needs a person")
        val rows = pairs.map { p ->
            listOf(p.rowNumber.toString(), p.surveyNo, p.subDivision, p.lpm,
                p.dlrExtent, p.mapExtent,
                p.variation?.let { "%.1f%%".format(it * 100) } ?: "",
                p.confidence.name, p.why, if (p.needsReview) "yes" else "")
        }
        return Sheet("Correlation", headings, rows)
    }

    /** Findings from any of the check engines, as a sheet. */
    fun findings(name: String, findings: List<Finding>): Sheet =
        Sheet(name, listOf("Level", "Rule", "What", "Detail", "Rows", "What to do"),
            findings.map { f ->
                listOf(f.level.name, f.rule, f.title, f.detail,
                    f.rows.take(40).joinToString(", "), f.fix)
            })

    /** Joint cultivation: one name entered now, the rest to correct later. */
    fun jointCultivation(
        rows: List<Triple<Int, String, List<String>>>,
    ): Sheet = Sheet("Joint cultivation",
        listOf("Row", "LPM", "Name entered", "All khatadars", "How many"),
        rows.map { (line, lpm, names) ->
            val j = Khata.joint(names)
            listOf(line.toString(), lpm, j.enter, j.report(), names.size.toString())
        })
}
