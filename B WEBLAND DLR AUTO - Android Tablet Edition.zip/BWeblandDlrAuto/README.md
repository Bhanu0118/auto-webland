# B WEBLAND DLR AUTO — Android Tablet Edition

Bulk DLR entry into `webland2.ap.gov.in` (POLR6), on a tablet.

Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.
Rebuilt for Android from `B_WEBLAND_AUTO_v17.1`.

---

## Read these first

| | |
|---|---|
| `BUILD_APK.bat` | **double-click this on Windows to get the APK.** No Android Studio. It downloads what it needs into a `tools` folder beside itself and leaves `B-WEBLAND-DLR-AUTO.apk` here. `build-apk.sh` for Linux and macOS. |
| `docs/APK-TAYARU-CHEYYADAM.md` | APK ఎలా తయారు చేయాలి — three ways, in Telugu |
| `docs/STATUS.md` | **what has been run and what has not.** There is no prebuilt APK in this zip and the reason is in there. Read it before the first real record. |
| `docs/INSTALL.md` | building it in Android Studio, and running the checks |
| `docs/MANUAL-TELUGU.md` | వాడకం పుస్తకం — the manual, in Telugu |
| `docs/ARCHITECTURE.md` | how it is put together, and why |

## In one minute

```
core/   the rules, the macro engine, the spreadsheet reader, the maps.
        Plain Kotlin, no Android, no dependencies — so all of it is
        compiled and run on a desktop.  409 checks, all passing.

app/    the tablet.  Twelve screens in Compose, Room underneath, and a
        WebView that is the browser.
```

Three ways to enter a record, all of them real:

* **by the kind of land** — pick one of the 32 rows of the office's own
  land-nature table and the twelve dropdowns are filled with that row's
  words. No macro needed.
* **with a UI.Vision macro** — the ones already made for this work on a
  laptop run here unchanged. `NIVAGAM PATTA ADD` (386 commands) and
  `NIVAGAM GOVT ADD` (412) were both run through the engine; every
  command is understood.
* **by recording one** — do one record by hand and the app writes down
  what you did, keeping several ways to find each box.

## The rules it will not bend

* **An extent is never rounded.** Zeros are added to reach three
  decimals. A value with more decimals goes in exactly as it is, and
  says so in the report.
* **A record that may already be in the register is never entered
  again.** No answer from the portal is *needs review*, not *failed*,
  and "retry the failed ones" means exactly that.
* **Nothing in a macro file is ever executed.** Scripts are recognised
  by what they do and done natively; anything unrecognised is dropped
  and reported. Loops are refused.
* **A dropdown's word comes from the office's table, not a spreadsheet
  column** — and every box is read back after it is set, so a word this
  village's list has not got leaves the record for a person instead of
  being saved wrong.
* **No coordinate is ever read back, changed or written.** A map is read
  for its attributes; the `.shp` is not opened at all.
* **The app never signs.** It finds the records and stops.
* **A captcha or an OTP is never filled.** The portal is checking that a
  person is there, and a person is.
* **The source value is kept** — in the record, in every report, and in
  an audit row for every change.

## The browser, and the sign-in

The portal opens in the app's **own** browser pane, not Chrome, so the
session belongs to the app and survives a restart. The sign-in can be
remembered — type it in Settings, or sign in by hand once and tap
"Remember what is typed on the page". The password is encrypted under a
key generated inside the tablet's keystore, which never leaves it, and
is never logged, exported, shown or put in a recording. Anyone who can
unlock the tablet can use it, so keep a lock screen on the tablet;
`docs/STATUS.md` sets out the whole design.

## Running the checks without a tablet

```
./gradlew :core:coreCheck
```

or, with nothing but the Kotlin compiler:

```
kotlinc core/src -d out && kotlin -cp out ap.webland.core.test.MainKt
```
