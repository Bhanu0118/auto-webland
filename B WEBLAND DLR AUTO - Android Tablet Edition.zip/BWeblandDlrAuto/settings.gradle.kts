// B WEBLAND DLR AUTO - Android Tablet Edition
// Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "BWeblandDlrAuto"

// core  - the rules, the macro engine, the spreadsheet reader. Plain
//         Kotlin with no Android in it, so every bit of it can be run
//         and tested on a desktop.
// app   - the tablet: Compose screens, Room, the WebView that drives
//         the portal.
include(":core")
include(":app")
