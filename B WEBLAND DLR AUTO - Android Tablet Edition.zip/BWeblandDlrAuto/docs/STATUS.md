# What is finished, what is proved, and what is not

This is the honest list. The master prompt asks that no feature be
called complete until its implementation and tests show it works, so
anything below that has not been run is said to be not run.

---

## 1. What was actually run, and where

| | |
|---|---|
| Machine the project was built on | Linux, Kotlin 2.0.21, no Android SDK |
| `core` compiled | yes |
| `core` checks run | **409 checks, 409 passed, 0 failed** |
| The surveyor's real macros run through the engine | yes, three of them |
| `app/data`, `app/web`, `app/pdf` type-checked | yes, against stub Android APIs |
| `app/ui` (Compose) compiled | **no — see §4** |
| APK built | **no here — but `BUILD_APK.bat` builds one on a Windows machine in one click, and the GitHub Actions workflow builds one with nothing installed at all. See §4.** |
| Run on a tablet | **no** |
| Run against the live portal | **no** |

### The core checks

`./gradlew :core:coreCheck` runs them, and so does the Kotlin compiler
on its own. They cover: extent padding (zeros only, never rounding), all
32 presets and their chains, the instruction-sheet rules, khata rules,
the 27 failures and the REVIEW-never-retries invariant, the save-outcome
decision table, the `.bwa` gate, the UI.Vision reader, the two runners
against a fake portal (late dropdown, sticky box, word not in the list,
refusal, silence, signed out, if/else, retry-only-failed), the Add
Record form for every one of the 32 land types, the spreadsheet reader
and writer, KML, GeoJSON, DBF, and the report shapes.

### The real macros

Run against a simulated portal built from the CSV's own words:

| macro | commands | understood | CSV | rows sampled | right |
|---|---|---|---|---|---|
| NIVAGAM PATTA ADD | 386 | 386 | 3,454 rows × 20 | 4 (every chain) | 4 |
| NIVAGAM GOVT ADD | 412 | 412 | 415 rows × 20 | 7 (every chain) | 7 |
| NIVAGAM ALL CLASSIFICATIONS | 414 | 414 | 3,869 rows × 23 | 10 (every chain) | 10 |

Every command in all three is understood — including the `executeScript`
lines, which are not run but recognised: waiting for a dropdown's list,
waiting for a box to empty or appear, padding the extents, ticking Joint
Cultivation = No, and switching off the portal's confirm boxes.

The third macro reads columns 21, 22 and 23. One UI.Vision build stops
at `!COL20` and answers *Internal variable "!COL21" not supported*,
which with error-ignore on silently skips the whole block it is in —
that is the bug that left Land Classification (Sub Category) empty on
one laptop. This app reads every column, and warns that the file will
behave differently in UI.Vision on a laptop.

### The spreadsheet reader against a real file

Read a 3,454-row, 20-column workbook written by another program:
`0.680` came back as `0.680`, `212-4` stayed `212-4`, `20000102` stayed
text, and the Telugu names came back byte for byte identical to what the
other program reads.

---

## 2. Built and working, by the master prompt's own list

| § | asked for | done |
|---|---|---|
| 3 | tablet-only landscape interface, 12 places, dark/light, Telugu and English | yes |
| 4 | dashboard with counts, live progress, never shows unverified as done | yes |
| 5 | XLSX and CSV import, preview, large files, Telugu, duplicate and missing detection, original preserved, column mapping | yes |
| 6 | all the DLR record fields, the portal's own field names | yes, generated from the reference app |
| 7 | all 32 presets, govt and D-Patta rights, non-agri LPM series, SWLA khata, endowment and wakf, STOP/WARN/NOTE, and no silent change | yes |
| 8A | Tahsildar Add Record | yes — built from the land-nature table, no macro needed |
| 8B | VS correlation | reads and compares; see §3 |
| 8C | VRO ground truthing | reads and compares; see §3 |
| 8D | digital sign | lists what is ready; the app never signs — §3 |
| 9 | recorder with the full control set, beginner and expert modes | yes |
| 10 | the safety engine: page identity, save confirmation, duplicate prevention, session and network detection, NEEDS REVIEW, stop that works | yes |
| 11 | batch with row ranges, live counters, progress saved after every record, recovery | yes |
| 12 | FMB and GIS correlation | attributes only, geometry never touched — §3 |
| 13 | khata and name validation, notional khatas, khata generation, name merge | yes |
| 14 | extent units, the eight reports, source values kept | yes |
| 15 | offline-first | yes; only the portal needs the network |
| 16 | file manager through the system picker | yes |
| 17 | audit, no plaintext passwords, no data sent anywhere, delete everything | yes — the portal sign-in is encrypted under a key generated inside the tablet's keystore; see below |
| 18 | modular, no placeholders, no fake automation, no silent change | yes |
| 19 | the mandatory tests | the ones that do not need a device: §1 |
| 20 | deliverables | all but the APK: §4 |

---

## 3. Deliberately not done, and why

**The app never signs a record.** The Digital Sign screen opens the
page, lists which records are ready and which are not, and stops. A
signature is the officer saying the register is right, with their DSC. A
program cannot say that for them, and an app that pressed that button
would be forging it.

**No geometry is ever read back or written.** A KML, GeoJSON or
shapefile is read for its attributes. The `.shp` is not opened at all.
When the task is attribute correlation, moving one boundary to tidy an
attribute creates an overlap or a gap that nobody finds until two
farmers disagree.

**Nothing is renumbered, merged or corrected on its own.** An LPM in the
wrong series, a notional khata, a classification that disagrees with the
sheet: all reported, none changed. The surveyor decides and the change
is audited.

**Ground truth is not filled in.** The VRO screen reads the page and
sets it beside the register so a difference is seen. What the ground
truth says is what the VRO saw; an app that typed it would be inventing
a field visit.

**No OTP, CAPTCHA or authorisation is bypassed.** The surveyor signs in
themselves, in the app's own browser pane, and the session is theirs. A
box whose name or placeholder says captcha, otp, pin or cvv is never
filled and never read — the portal is checking that a person is there,
and a person is.

**The portal sign-in can be remembered, and here is exactly how.** It is
asked for, never assumed: either typed into the Settings page, or
captured from the portal's own sign-in page when the surveyor taps
"Remember what is typed on the page". The password is then encrypted
with AES-GCM under a 256-bit key generated inside the tablet's own
keystore, which never leaves it — on most tablets that key is in
hardware and cannot be read out at all. What the settings file holds is
the encrypted bytes, which are useless on any other tablet because
there is no key to open them with. It is never put in the page log, a
report, an audit row, a recording or an export, never shown on screen,
and never read back out of a box to be compared (a mismatch message
would carry it). "Forget it" deletes the bytes and the key.

What that does NOT protect against, and the manual says so in those
words: anybody who can unlock the tablet can press "Fill sign-in" and be
signed in as the officer, exactly as with the password manager in any
browser. The tablet's lock screen is the lock on this door. A key tied
to a fresh fingerprint on every use was considered and not used: a run
of three thousand records cannot stop to re-authenticate, and a half-
working protection that is turned off on the first busy morning is
worse than one that is described honestly.

A password typed during a *recording* is still never written into the
recording — the step says a secret belongs there, and at replay the app
uses what was typed on the Run page or, if that is empty, the saved
sign-in.

**The run needs the app in front, with the screen kept on.** A WebView
in a background service does not reliably run JavaScript, and a run that
half-works in the background is worse than one that plainly needs the
tablet awake. The screen is held awake automatically while a run is
going, and progress is saved after every record, so closing the app
costs one record.

**The licence gate is not carried over.** The Windows build can be
locked to a Control Room page. This is the surveyor's own copy; nothing
phones home, nothing is registered, and no land data leaves the tablet
except in a file exported on purpose.

---

## 4. Not done, and what it would take

**There is no APK in this zip, and the Compose UI has not been
compiled.** Both need the Android SDK and the AndroidX libraries.
`dl.google.com`, `maven.google.com` and Maven Central are all blocked on
the machine this was written on — only the Kotlin compiler could be
fetched, which is exactly why `core` is compiled and tested and the
Compose layer is not.

**Three ways to get the APK, none of them needing Android Studio**
(`docs/APK-TAYARU-CHEYYADAM.md` has this in Telugu):

1. `BUILD_APK.bat` — double-click it on a Windows machine. It downloads
   Java 17, Gradle, the Android command-line tools and platform 34 into
   a `tools` folder beside itself, builds, and leaves
   `B-WEBLAND-DLR-AUTO.apk` in the project folder. Nothing is installed
   into Windows; deleting `tools` undoes all of it. About 1.5 GB and
   15–30 minutes the first time, a minute after that.
   `build-apk.sh` does the same on Linux and macOS.
2. `.github/workflows/build-apk.yml` — push the project to a free
   GitHub repository and the APK is built for you, with nothing
   installed on any machine of yours; download it from the Actions tab.
   The workflow runs the 409 core checks first and refuses to build if
   they fail.
3. Android Studio, if anyone nearby has it: Open, Sync, Build APK.

Expect the UI layer to need small corrections on that first build — a
parameter name, an import. `core`, `data`, `web` and `pdf` are already
compiled, so a first-build error is likely to be in `ui/`; the build
scripts say as much when they stop, and print the message to send
back.

In place of a compiler, the Android half was checked mechanically:

| check | result |
|---|---|
| every file's brackets close | 36 files, pass |
| package lines match their folders | pass |
| every `Words.*` used exists | 125 used of 152, pass |
| every `model.*` exists in AppModel | 87 used, pass |
| every `prefs.*` exists in Prefs | pass |
| every `ap.webland.*` import resolves | pass |
| all 12 screens defined, the rail and the list agree, every one drawn | pass |
| every `ap.webland.core.*` name used exists | 43, pass |
| every `dao.*` exists | 34 of 37, pass |
| the manifest's classes and resources exist | pass |
| every `libs.*` is in the version catalog | 23, pass |
| `data`, `web`, `pdf`, `BWeblandApp` type-check against API stubs | pass |

**Room has one version and no migrations.** Version 1, and
`fallbackToDestructiveMigration` is deliberately NOT set: a land
register is not something to drop and rebuild because a column changed.
A schema change needs a migration written.

**Not built at all:** FMB PDF import, reference imagery, OCR, shapefile
geometry reading, and the Windows app's assistant and help system. The
KML/GeoJSON/DBF path covers attribute correlation; the rest are
extension points, not stubs — there is no button for them.

---

## 5. Before the first real record

1. Build and install on the tablet. Open it in landscape.
2. Settings: language, pace, extent decimals, and your name for the
   audit trail.
3. Files: import the DLR workbook. Check the preview counts.
4. Validation: press Check. Settle anything marked **must be fixed**.
5. DLR Data: set the kind of land on the records, or import the macro
   that already carries the chain.
6. Run: open the portal, sign in yourself, then **Test one record**.
   Look at the portal with your own eyes and confirm every one of the
   twelve boxes.
7. Only then set a range and start. Watch the first ten.

The app is built so that a record it is unsure about waits for you. That
only helps if the review list is actually read.
