# APK ఎలా తయారు చేయాలి

Android Studio అవసరం లేదు. మూడు దారులు — **మొదటిది మీకు సులభం.**

---

## దారి 1 — Windows laptop లో ఒక క్లిక్  (సిఫారసు)

మీ Windows laptop లో:

1. `BWeblandDlrAuto` ఫోల్డర్ unzip చేయండి.
2. ఆ ఫోల్డర్ లోపల **`BUILD_APK.bat`** డబుల్ క్లిక్ చేయండి.
3. అంతే. అది తనే దిగుమతి చేసుకుంటుంది:
   * Java 17 (~180 MB)
   * Gradle (~130 MB)
   * Android SDK command line tools (~130 MB)
   * Android platform 34, build tools (~600 MB)
   * తర్వాత Compose, Room libraries (~400 MB)
4. పూర్తయితే ఆ ఫోల్డర్‌లోనే **`B-WEBLAND-DLR-AUTO.apk`** వస్తుంది.

**మొదటిసారి 15–30 నిమిషాలు** (ఇంటర్నెట్ వేగం బట్టి), సుమారు **1.5 GB**
దిగుమతి. తర్వాత ఏదైనా మార్చి మళ్ళీ అదే .bat నొక్కితే **ఒక నిమిషం**లో
కొత్త APK వస్తుంది.

దిగుమతి చేసినవన్నీ ఆ ఫోల్డర్ లోపల `tools` అనే చోట పడతాయి. Windows లో
ఏమీ install కాదు. `tools` ఫోల్డర్ తీసేస్తే అంతా పోతుంది.

Linux / Mac అయితే: `./build-apk.sh`

### ఏదైనా download తప్పిపోతే

Google ఆ ఫైల్ పేరు మార్చి ఉండవచ్చు. .bat ఏ లింక్ తప్పిందో, దానికి
బదులుగా ఎక్కడ నుంచి తీసుకోవాలో చెబుతుంది. ఆ zip దిగుమతి చేసి, .bat
చెప్పిన చోట unzip చేసి, మళ్ళీ .bat నొక్కండి.

---

## దారి 2 — ఏదీ install చేయకుండా, GitHub లో

Laptop లో ఏమీ దిగుమతి చేయకూడదనుకుంటే:

1. **github.com** లో ఉచిత account చేయండి.
2. **New repository** → ఏదైనా పేరు → **Create**.
3. **uploading an existing file** నొక్కి, `BWeblandDlrAuto` ఫోల్డర్
   మొత్తం అందులో లాగి వదలండి → **Commit**.
4. పైన **Actions** tab చూడండి — build తనే మొదలవుతుంది. ఆకుపచ్చ టిక్
   వచ్చేవరకు ఆగండి (సుమారు 5 నిమిషాలు).
5. ఆ run తెరిచి, కిందున్న **B-WEBLAND-DLR-AUTO-apk** దిగుమతి చేయండి.
   Unzip చేస్తే .apk లోపల ఉంటుంది.

GitHub మిషన్‌లో Java, Android SDK ఇప్పటికే ఉంటాయి — మీరు ఏమీ దిగుమతి
చేయరు. ఫోన్ లేదా టాబ్లెట్ బ్రౌజర్ నుంచి కూడా చేయవచ్చు (అప్‌లోడ్
laptop లో సులభం).

`.github/workflows/build-apk.yml` ఫైల్ project లోపలే ఉంది — అదే ఈ పని
చేస్తుంది. అది **409 core తనిఖీలు** ముందు నడిపి, pass అయితేనే APK
కడుతుంది.

---

## దారి 3 — Android Studio ఉన్న ఎవరైనా

Open → Sync → Build → Build APK(s). అంతే.

---

## టాబ్లెట్‌లో install

1. APK ను టాబ్లెట్‌కు కాపీ చేయండి (USB, WhatsApp, Google Drive — ఏదైనా).
2. ఆ ఫైల్ నొక్కండి.
3. "ఈ మూలం నుంచి install చేయడానికి అనుమతించు" అని అడుగుతుంది —
   ఒకసారి అనుమతించండి.
4. Install → Open.

ఇది **debug APK** — debug key తో సంతకం చేసి ఉంటుంది, కాబట్టి నేరుగా
install అవుతుంది. Play Store కు పెట్టాలంటే మాత్రమే release signing
అవసరం (`docs/INSTALL.md` లో ఉంది).

---

## ఈ మిషన్‌లో APK ఎందుకు తయారు కాలేదు

నేను పని చేసే చోట `dl.google.com` (Android SDK), `maven.google.com`
(Compose, Room), Maven Central — అన్నీ బ్లాక్. Kotlin compiler ఒక్కటే
దొరికింది. అందుకే:

* **`core`** భాగం (DLR నియమాలు, మాక్రో ఇంజన్, స్ప్రెడ్‌షీట్, మ్యాప్‌లు)
  — **ఇక్కడే కంపైల్ చేసి నడిపాను: 409 తనిఖీలు pass.**
* **`data`, `web`, `pdf`** — API stub లతో **type-check చేసాను, శుభ్రం.**
* **`ui`** (Compose) — కంపైల్ చేయలేకపోయాను. మెకానికల్ తనిఖీలు 14
  pass అయ్యాయి (బ్రాకెట్లు, `Words.*`, `model.*`, screens, imports).

అంటే: మొదటి build లో లోపం వస్తే **`ui/` లోనే** వచ్చే అవకాశం ఎక్కువ —
ఒక parameter పేరు లాంటిది. ఆ message పంపండి, వెంటనే సరిచేస్తాను.
