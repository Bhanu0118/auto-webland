# Building and installing it

## The short way, with no Android Studio

**Windows:** double-click `BUILD_APK.bat` in the project folder. It
fetches Java 17, Gradle, the Android command-line tools and platform 34
into a `tools` folder beside itself, builds, and leaves
`B-WEBLAND-DLR-AUTO.apk` in the project folder. Nothing is installed
into Windows.

**Linux or macOS:** `./build-apk.sh`

**Nothing installed anywhere:** push the project to a free GitHub
repository; `.github/workflows/build-apk.yml` builds the APK and you
download it from the Actions tab.

`docs/APK-TAYARU-CHEYYADAM.md` walks through all three in Telugu.

The rest of this file is for building it in Android Studio.

## What you need

* Android Studio, any recent version (Ladybug or newer is fine)
* A JDK 17 — Android Studio ships with one
* An Android 10 or newer tablet, 10 inch or larger
* The first build needs the internet: Gradle fetches the Android SDK and
  the libraries. After that it builds offline.

## The first build

1. Unzip `BWeblandDlrAuto` anywhere.
2. Android Studio → **Open**, and choose that folder (the one holding
   `settings.gradle.kts`).
3. It will say the Gradle wrapper is missing or offer to use its own
   Gradle. Let it. The project needs Gradle 8.x; Android Studio has one.
4. Wait for **Sync**. It downloads the Android SDK 34 platform, the
   Compose libraries and Room. This takes a few minutes once.
5. **Build → Make Project.**
   `core`, `data`, `web` and `pdf` have been compiled already on another
   machine, so if the first build stops it will almost certainly be in
   `app/src/main/kotlin/ap/webland/ui/` — a parameter name or an import
   that this version of Compose spells differently. Android Studio
   offers the fix; take it and build again. `docs/STATUS.md` explains
   why that layer could not be compiled in advance.
6. **Run → Run 'app'** with the tablet plugged in, or
   **Build → Build Bundle(s) / APK(s) → Build APK(s)** for a file to
   copy across.

## Running the checks

The rules, the macro engine, the spreadsheet reader and the map readers
all run on a desktop, with no tablet and no Android SDK:

```
./gradlew :core:coreCheck
```

409 checks. They print what each one is about, so a failure says what
broke rather than which line number.

To check the spreadsheet reader against one of your own workbooks:

```
./gradlew :core:coreCheck -Dbwa.sample.xlsx=/path/to/NIVAGAM_ALL.xlsx
```

It prints the sheet names, the row and column counts, the headings and
the first row, so you can see with your own eyes that it read your file
the way Excel does.

With nothing but the Kotlin compiler, and no Gradle at all:

```
kotlinc core/src -d out
kotlin -cp out ap.webland.core.test.MainKt
```

## A release build

`release` is set to shrink and obfuscate, with `proguard-rules.pro`
keeping `ap.webland.core` and `ap.webland.data` whole — the macro engine
and Room both reach classes by name, and shrinking them away would break
a run in a way that only shows up on a tablet.

Signing: **Build → Generate Signed Bundle / APK**, make a keystore, and
keep it somewhere you will still have in two years. An app signed with a
new key cannot update one signed with the old.

## Where things are on the tablet

| | |
|---|---|
| the database | app-private; no other app can read it |
| exported reports | app-private `exports/`, shared out with the Share button or **Save to…** |
| screenshots of failures | app-private `shots/` |
| workbooks and macros you import | wherever they already are; the app asks the system for them and remembers permission |

Nothing is backed up to the cloud and nothing is copied in a device
transfer — `allowBackup` is off and the extraction rules exclude
everything. Land records leave the tablet only in a file you export.

## If something goes wrong

**Sync fails on the Gradle version.** Let Android Studio use its own
Gradle, or run `gradle wrapper` once with any Gradle 8.x to make the
wrapper files.

**The portal page is blank.** The pane asks for the desktop page,
because the macros were recorded against it and the box ids come from
it. If the portal refuses a desktop user agent, Settings → portal
address can point at another page; the user agent itself is in
`web/Page.kt` (`DESKTOP_AGENT`).

**A dropdown will not take its word.** That is the app working. The
record goes to **needs review** with the word it wanted and what the box
holds. Look at the portal's own list: this village probably calls that
land something else. Change the word in the land-nature table
(`core/Presets.kt`) only if the portal's list disagrees with the table
for every village — otherwise set a different kind of land on that
record.

**A run stops after five failures in a row.** On purpose, so the rest of
the file is not spent on the same problem. Fix the cause and press
**Retry the failed ones** — which touches the failed rows only, never
the ones waiting for review.
