# B WEBLAND DLR AUTO — Android Tablet Edition

## Architecture and implementation plan

Developed by Bhanu Pratap, Village Surveyor, Andhra Pradesh.
Rebuilt for Android tablets from `B_WEBLAND_AUTO_v17.1`.

---

## 1. The one decision everything else follows from

The Windows application is Python driving a real Chrome through a
debugging port. None of that exists on Android: there is no desktop
Chrome to attach to, no Python runtime, and no filesystem to walk.

So the port is not a translation. It is a split:

```
core/   plain Kotlin, no Android at all
        the DLR rules, the macro engine, the spreadsheet reader,
        the map reader, the report shapes
app/    Android: Compose screens, Room, and a WebView that IS the browser
```

Everything that can be got wrong quietly — a rights value, a khata rule,
an extent rounded instead of padded, a save treated as confirmed when it
was not — lives in `core`, which has no dependencies and therefore runs
and is tested on a desktop with nothing but the Kotlin compiler. The
Android half is the part that can only be judged on a tablet, and it is
kept as thin as it can be.

```
            ┌──────────────────────── app (Android) ───────────────────────┐
            │  Compose screens ──► AppModel ──► Repo ──► Room              │
            │                         │                                   │
            │                         ├──► AutomationRunner               │
            │                         │         │                         │
            │                         │         ▼                         │
            │                         │    PortalPage ──► WebView ──► the │
            │                         │   (PageHost)                portal│
            │                         ├──► FileKit (SAF)                  │
            │                         └──► Exports ──► Xlsx / PdfReport    │
            └──────────────────────────────┬───────────────────────────────┘
                                           │ calls into
            ┌──────────────────────── core (plain Kotlin) ─────────────────┐
            │  Presets (32 land types)   DlrRules (the 19 items)          │
            │  Khata   Extent            Validate                         │
            │  Macro (.bwa)  UiVision (UI.Vision JSON)                    │
            │  BwaRunner  UvRunner  AddFlow      ◄── PageHost interface    │
            │  Table / Csv / Xlsx        Reports                          │
            │  Kml / GeoJson / Dbf / Correlate                            │
            │  Json  Codes  Outcome                                       │
            └─────────────────────────────────────────────────────────────┘
```

`PageHost` is the whole interface between the two: eleven questions about
a page — does this box exist, put this in it, what does it hold now, what
is the portal saying. The runners ask; `PortalPage` answers out of a
WebView; a fake page answers in the tests. That is why the awkward cases
(a dropdown whose list arrives late, a Save the portal never answers) can
be arranged on purpose and checked, which a real portal will not do to
order.

---

## 2. Technology

| | |
|---|---|
| Language | Kotlin 2.0.21 |
| UI | Jetpack Compose, Material 3, landscape-first |
| Architecture | MVVM; `core` is the domain layer and has no Android in it |
| Database | Room 2.6.1 (KSP) |
| Background | coroutines; WorkManager is declared for file jobs |
| Browser | Android WebView with controlled JavaScript |
| Spreadsheets | this project's own reader/writer — no POI |
| PDF | `android.graphics.pdf.PdfDocument` |
| Maps | this project's own KML, GeoJSON and DBF readers |
| Min Android | 10 (API 29); compiled against 34 |

### Why no Apache POI

POI is the usual answer for .xlsx on the JVM and it is the wrong answer
here. It wants a large part of the desktop Java runtime, needs
desugaring to work on Android at all, and loads a whole workbook into
memory — which is the one thing a 4,000-row file on a tablet cannot
afford. An .xlsx is a zip of XML and both halves are in the Android
runtime already, so `core/Xlsx.kt` reads a sheet a row at a time and
writes one the same way. It is about 300 lines, it has no dependencies,
and — the real point — it is in `core`, so it is tested on a desktop
against workbooks this app did not write.

---

## 3. The modules

### core

| file | what it holds |
|---|---|
| `Presets.kt` | the 32 land-type rows, **generated** from the Windows app's own `webland_config.py` so not one value was retyped; the portal's field ids for all four pages |
| `DlrRules.kt` | the instruction sheet as checks: rule 19 rights, rule 11 sub-category, rule 13 LPM series, rule 17 SWLA khata, rules 14/15 endowment and wakf |
| `Khata.kt` | notional vs government khatas, khata suggestion, the name-merge rule, joint cultivation |
| `Extent.kt` | three decimals by adding zeros only; unit conversion; variation |
| `Codes.kt` | 27 named failures in both languages, with the invariant that a REVIEW may never recommend a retry — checked when the table is built |
| `Outcome.kt` | the six row states, the save outcomes, and how the portal's words are read |
| `Macro.kt` | the `.bwa` recording format, read through a gate |
| `UiVision.kt` | reads and writes the UI.Vision macros already in use |
| `BwaRunner.kt` / `UvRunner.kt` | the two players, both over `PageHost` |
| `AddFlow.kt` | the Add Record form built from the land-nature table |
| `Table.kt` / `Xlsx.kt` | spreadsheets, CSV, heading matching, `{{Column}}` binding |
| `Validate.kt` | everything asked before a run starts |
| `Geo.kt` | KML, GeoJSON and DBF attributes; correlation with confidence |
| `Reports.kt` | the shape of every report |
| `Json.kt` | a strict reader and writer, so nothing in a file can run |

### app

| file | what it does |
|---|---|
| `data/Database.kt` | Room entities and the DAO; the retry query is FAILED only |
| `data/Repo.kt` | the only writer; every change writes an audit row |
| `data/Local.kt` | preferences, and files through the system picker |
| `data/Exports.kt` | the eight reports, and what goes in which workbook |
| `web/Page.kt` | `PageHost` over a WebView: the JavaScript is written here, never taken from a file |
| `web/Recorder.kt` | records what the surveyor does, keeping several ways to find each box |
| `web/Runner.kt` | runs a macro, a recording, or the land type on each record; checkpoints after every row |
| `pdf/Report.kt` | the detailed PDF |
| `ui/` | the twelve screens, the theme, and every word in both languages |

---

## 4. The promises in the code

These are not aspirations; each one is a line you can point at.

**An extent is never rounded.** `Extent.pad` adds zeros and returns the
value untouched when it has more decimals than the portal takes. The
runner logs that and types it as it stands.

**A record that may be in the register is never entered twice.**
`SaveOutcome` tells a confirmed save, a refusal and *no answer* apart.
No answer, or a form that merely emptied, is `NEEDS_REVIEW`, and
`RowState.retryable` is true for `FAILED` alone. The DAO's retry query
asks for FAILED rows; `Codes` refuses at startup to hold a REVIEW
failure that recommends a retry.

**Nothing in a file is ever executed.** A `.bwa` step must name an
action from a fixed list. A UI.Vision `executeScript` is never run: five
script shapes these macros use are recognised by what they do and done
natively, and anything else is dropped and reported. Loops are refused.

**A dropdown's word comes from the office's own table, not from a
spreadsheet column.** This was learnt the hard way: a classification
written in one village's adangal is not the word another village's
dropdown holds, and a macro that reads the chain out of the file enters
nothing at all in the second village without saying so. `AddFlow` takes
the chain from `Presets`, and the runner reads every box back after
setting it — a word the list does not have leaves the box empty, is
written down, and sends the record to review rather than being saved
wrong.

**The source value is kept.** Importing stores the whole row as JSON;
every report puts the file's own value beside anything worked out; every
edit writes an audit row.

**No geometry is touched.** A map is read for its attributes. The `.shp`
is not opened at all, which is the simplest possible guarantee that
nothing moves a boundary.

---

## 5. What was done in what order

1. Read the reference application's rules, recorder model, replay states
   and save detection.
2. Generated the 32 presets and the 27 failures straight out of the
   Python, so the values and the Telugu are the application's own.
3. Built `core` and its checks, compiling and running them at every
   step: 409 checks.
4. Ran the surveyor's three real macros and their CSVs through the
   engine against a simulated portal.
5. Built the Android layer; type-checked `data`, `web` and `pdf` against
   stub Android APIs.
6. Wrote the twelve screens; checked them statically (see
   `docs/STATUS.md` for exactly what is and is not proved).

`docs/STATUS.md` says plainly what has been run and what has not. It is
worth reading before the first record goes in.
